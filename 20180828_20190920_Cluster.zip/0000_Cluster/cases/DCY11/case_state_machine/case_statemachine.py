import collections
import itertools
import logging
import openpyxl
import re
from openpyxl.styles import Alignment, Border, Side, Font, PatternFill
logger = logging.getLogger(__name__)

T_Mapping = {'Condition': 'Value1',
             'T0': '1.Car_Config::Number==10\n2.Car_Config::Value=2\n3.Car_Config::Send=1\n4.WAIT=1000\n5._AdditionalOutputs::VDDM::TrsmParkLockdSafe_UB=1\n6._AdditionalOutputs::VDDM::GearLvrIndcn_UpdateBitControl=1\n',
             'T1': '1._AdditionalOutputs::CEM::VehModMngtGlbSafe1_UpdateBitControl=1\n2._AdditionalOutputs::CEM::UsgModSts=13\n4.WAIT=10000',
             'T2': '1._AdditionalOutputs::CEM::VehModMngtGlbSafe1_UpdateBitControl=1\n2._AdditionalOutputs::CEM::UsgModSts=2\n4.WAIT=2000',
             'T3': '1._AdditionalOutputs::CEM::VehModMngtGlbSafe1_UpdateBitControl=1\n2._AdditionalOutputs::CEM::UsgModSts=13\n4.WAIT=2000',
             'T4': '1._AdditionalOutputs::CEM::VehModMngtGlbSafe1_UpdateBitControl=1\n2._AdditionalOutputs::CEM::UsgModSts=0\n3.WAIT=2000',
             'T5': '1._AdditionalOutputs::CEM::VehModMngtGlbSafe1_UpdateBitControl=1\n2._AdditionalOutputs::CEM::UsgModSts=1\n3.WAIT=2000\n3._AdditionalOutputs::VDDM::_E2E_TrsmParkLockdSafe::TrsmParkLockd=1\n4._AdditionalOutputs::VDDM::GearLvrIndcn=0\n',
             'T6': '1.WAIT=1000',
             'T7': '1.Car_Config::Number==10\n2.Car_Config::Value=1\n3.Car_Config::Send=1\n4.WAIT=1000',
             'T8': '1._AdditionalOutputs::CEM::UsgModSts=11\n2.WAIT=10000\n3._AdditionalOutputs::VDDM::GearLvrIndcn_UpdateBitControl=0\n4.WAIT=800',
             'T9': '1._AdditionalOutputs::VDDM::GearLvrIndcn_UpdateBitControl=1\n2.WAIT=800',
             'T10': '1._AdditionalOutputs::CEM::UsgModSts=11\n2.WAIT=10000'}

class CaseStateMachines(object):
    def __init__(self, file, sheet_name):
        print("init casestatemachines class")
        self.file = file
        self.sheet_name = sheet_name
        self.T_Mapping = dict()
        self.all_paths = list()
        self.all_cases = collections.OrderedDict()
        self.real_cases = dict()
        self.states = list()


    def get_all_availabe_paths(self,states):
        self.states = states
        for i in range(2,len(states)+1):
            iter = itertools.permutations(states, i) #permutations 排列　　（不放回抽样排列）
            self.all_paths.extend(list(iter))
        return self.all_paths

    def get_all_paths_cases(self,transitions):
        for path in self.all_paths:
            expect_condition =[]
            for i in range(0, len(path) - 1):
                for conditon in transitions:
                    if path[i] == conditon["source"] and path[i + 1] == conditon["dest"] :
                        expect_condition.append(conditon["trigger"])
                        self.all_cases[path] = expect_condition
        print(self.all_cases)
        return self.all_cases

    def get_positive_cases(self):
        negative =[]
        for key in self.all_cases:
            if len(self.all_cases[key]) < len(key)-1:
                negative.append(key)
            if not key[0].startswith(self.states[0]) and not key[0].startswith(self.states[-1]):
                negative.append(key)
        resp = list(set(negative))
        for n in resp:
            self.all_cases.pop(n)
        print("positive cases are %s"%self.all_cases)
        print(len(self.all_cases))
        return self.all_cases

    def mapping_cases_conditons(self):
        for key, value in self.all_cases.items():
            key = tuple(list(key)+value)
            conditon1 = []
            for item in value:
                if "+" in item:
                    resp = item.split("+")
                    add_condition =[]
                    for i in resp:
                        add_condition.append(self.T_Mapping[i])
                    conjection = "\n".join(add_condition)
                    conditon1.append(conjection)
                else:
                    conditon1.append(self.T_Mapping[item]+"\n")
            self.real_cases[key]=conditon1
        print(self.real_cases)
        return self.real_cases

    def wrtie_cases_xlxs(self):
        wb = openpyxl.load_workbook(self.file)
        if wb["report"]:
            wb.remove_sheet(wb["report"])
        ws_new = wb.create_sheet("report")
        datas =[]
        for key,value in self.real_cases.items():
            resp = "".join(value)
            resp1 = resp.split("\n")
            last = []
            for i in range(0, len(resp1)):
                if re.search("^\d+.", resp1[i]):
                    last.append(re.sub("^\d+", str(i + 1), resp1[i]))
            datas.append(["",("-".join(key)), "\n".join(last)])
        print(datas)
        ws_new.append(["ID","Comment","Steps","Verify","Result","Time","SRD"])
        ws_new.append(["TM1:%s"%self.sheet_name])
        for data in datas:
            ws_new.append(data)

        ws_new.column_dimensions['C'].width = 71# 设置列宽
        ws_new.column_dimensions['B'].width = 25  # 设置列宽
        align = Alignment(wrapText=True) #自动换行
        thin = Side(border_style="thin", color="000000")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        fill_blue = PatternFill(patternType="solid", start_color="FFC000")
        fill_org = PatternFill(patternType="solid", start_color="8DB4E2")
        wb.save(self.file)
        wb_new = openpyxl.load_workbook(self.file)
        ws_new2 = wb_new["report"]
        rows = ws_new2.max_row+1
        columns = ws_new2.max_column+1
        for i in range(1, rows):
            for j in range(1,columns):
                if i <= rows-2:
                    ws_new.cell(i+1, 1).value = str(i)
                if i == 1:
                    ws_new.cell(1, j).fill = fill_blue
                if i == 2:
                    ws_new.cell(2, j).fill = fill_org
                ws_new.cell(i, j).alignment = align
                ws_new.cell(i, j).border = border
        wb.save(self.file)

    def read_trigger_conditions(self):
        wb = openpyxl.load_workbook(self.file)
        ws = wb[self.sheet_name]
        rows = ws.max_row+1
        for i in range(1,rows):
            self.T_Mapping[ws.cell(i,1).value]=ws.cell(i,2).value
        print("Condition mapping is ")
        print(self.T_Mapping)
        return self.T_Mapping


if __name__ == "__main__":
    transitions =[
        {"trigger":"T7","source":"S5","dest":"S1"},
        {"trigger": "T9+T1", "source": "S5", "dest": "S2"},
        {"trigger": "T9+T2", "source": "S5", "dest": "S3"},
        {"trigger": "T0+T1", "source": "S1", "dest": "S2"},
        {"trigger": "T0+T2", "source": "S1", "dest": "S3"},
        {"trigger": "T3", "source": "S3", "dest": "S2"},
        {"trigger": "T4", "source": "S2", "dest": "S3"},
        {"trigger": "T5", "source": "S2", "dest": "S4"},
        {"trigger": "T6", "source": "S4", "dest": "S3"},
        {"trigger": "T10", "source": "S4", "dest": "S2"},
     ]
    test = CaseStateMachines("Gear.xlsx","Gear")
    test.read_trigger_conditions()
    states = ["S1", "S2", "S3", "S4", "S5"]
    test.get_all_availabe_paths(states)
    test.get_all_paths_cases(transitions)
    test.get_positive_cases()
    test.mapping_cases_conditons()
    test.wrtie_cases_xlxs()
