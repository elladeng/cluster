from cases.DCY11.case_state_machine.state import Ui_MainWindow
from cases.DCY11.case_state_machine.case_statemachine import CaseStateMachines
from PyQt5.QtWidgets import QApplication, QDesktopWidget,QMainWindow,QMessageBox,QFileDialog
from PyQt5 import QtCore,QtWidgets
import threading
import logging
import re
cases =dict()

class StateMachine(QMainWindow,Ui_MainWindow):
    def __init__(self, parent=None):
        super(StateMachine, self).__init__(parent)
        self.setupUi(self)
        self.tableWidget.resizeColumnsToContents()
        self.setWindowTitle("CaseStateMachine")
        self.center()
        self.pushButton.clicked.connect(self.start_thread_process)
        self.pushButton_2.clicked.connect(self.close_window)
        self.pushButton_condition_in.clicked.connect(self.load_xlsx)
        self.sheet_name = ""
        self.file_name = ""
        self.states = list()
        self.transitions = list()

    def load_xlsx(self):
        logger.info("step1 :choose xlsx file")
        self.textEdit.setPlainText("Step1: Choose original xlsx file")
        cfg_file_name = QFileDialog.getOpenFileName(self, "open xlsx file", filter="files(*.xlsx)")
        if cfg_file_name is not None:
            self.lineEdit_xlxs_in.setText(cfg_file_name[0])

    def get_cases_states(self):
        self.states_orignal=[self.S0, self.S1, self.S2, self.S3, self.S4, self.S5, self.S6, self.S7,\
                             self.S8, self.S9, self.S10, self.S11, self.S12]
        for state in self.states_orignal:
            if state.isChecked():
                self.states.append(state.text())
        return self.states
        logger.info("The cases states are %s " %self.states)

    def get_matrix(self):
        for row in range(0,20):
            try:
                if self.tableWidget.item(row, 0).text() is not None:
                    self.transitions.append({"trigger": self.tableWidget.item(row, 1).text(),\
                                             "source": self.tableWidget.item(row, 0).text(),\
                                             "dest": self.tableWidget.item(row,2).text()
                                             })
            except AttributeError:
                break
        logger.info("input transitions are %s" % self.transitions)
        return self.transitions

    def close_window(self):
        logger.info("Close the CASE state machine Application ")
        qApp = QApplication.instance()
        qApp.quit()
        sys.exit()

    def center(self):
        screen = QDesktopWidget().screenGeometry()
        size = self.geometry()
        self.move((screen.width() - size.width()) / 2, (screen.height() - size.height()) / 2)
        self.tableWidget.setColumnWidth(1, 70)
        self.tableWidget.setColumnWidth(0, 70)
        self.tableWidget.setColumnWidth(2, 70)

    def start_thread_process(self):
        self.sheet_name = self.lineEdit_sheet_name.text()
        self.textEdit.append("Step2 : sheet name is %s"%self.sheet_name)
        self.thread = threading.Thread(target=self.execute_process)
        self.thread.setDaemon(True)
        self.thread.start()
        self.thread.join()
        QMessageBox.information(None, "Finish", "Please check the report sheet in  %s "% self.file_name)

    def execute_process(self):
        self.file_name = re.sub("/", "\\\\", self.lineEdit_xlxs_in.text())
        self.context = CaseStateMachines(self.file_name, self.sheet_name)
        T_Mapping = self.context.read_trigger_conditions()  # step1 read cases condition from xlsx
        self.textEdit.append("Step3: Condition mapping are %s" % T_Mapping)
        self.states = self.get_cases_states() #step2 get cases states from UI
        self.textEdit.append("Step4: Cases have %s states"%self.states)
        all_available_cases = self.context.get_all_availabe_paths(self.states) # step3 get all available cases
        self.textEdit.append("Step5: All available case are %s"%all_available_cases)
        self.get_matrix() #step4 get cases transitions
        self.textEdit.append("Step6: All transitions are %s" % self.transitions)
        all_cases = self.context.get_all_paths_cases(self.transitions) #step5 get all paths cases
        self.textEdit.append("Step7: All cases are %s"% all_cases)
        positive_cases = self.context.get_positive_cases()# step 6 get all available positive cases
        self.textEdit.append("Step8: Positive case are %s"% positive_cases)
        actual_cases = self.context.mapping_cases_conditons() # mapping the condtion
        self.textEdit.append("Step9: Actual case are %s" % actual_cases)
        self.textEdit.append("Step10: Wrtie to excle")
        self.context.wrtie_cases_xlxs()


if __name__ == "__main__":
    import sys
    log_format = logging.Formatter("%(asctime)s-%(message)s")
    file_handler = logging.FileHandler("flashfirmware.log",mode="w")
    file_handler.setFormatter(fmt=log_format)
    stream_handle = logging.StreamHandler()
    stream_handle.setFormatter(fmt=log_format)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(stream_handle)
    logger.addHandler(file_handler)
    # logging.basicConfig(level=logging.INFO,format="%(asctime)s-%(message)s",filename="flashfirmware.log",filemode='w')
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_X11InitThreads)
    app = QApplication(sys.argv)
    ui = StateMachine()
    ui.show()
    sys.exit(app.exec_())













