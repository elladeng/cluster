from cases.DCY11.MTE_CASES.mte_modifiy import Ui_MTE_CASES
from cases.DCY11.MTE_CASES.change_MTE_value import *
from PyQt5.QtWidgets import QApplication, QDesktopWidget,QMainWindow,QMessageBox,QFileDialog
from PyQt5 import QtCore,QtWidgets,QtGui
import threading
import logging
import re


class StateMachine(QMainWindow,Ui_MTE_CASES):
    def __init__(self, parent=None):
        super(StateMachine, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle("MTE Formats")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("modify.ico"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.setWindowIcon(icon)
        self.center()
        self.pushButton_START.clicked.connect(self.start_thread_process)
        self.pushButton_xlsx.clicked.connect(self.load_xlsx)
        self.pushButton_STOP.clicked.connect(self.close_window)
        self.file_name = ""


    def load_xlsx(self):
        logger.info("step1 :choose xlsx file")
        self.textEdit.setPlainText("Step1: Choose original xlsx file")
        cfg_file_name = QFileDialog.getOpenFileName(self, "open xlsx file", filter="files(*.xlsx)")
        if cfg_file_name is not None:
            self.lineEdit_xlxs_in.setText(cfg_file_name[0])


    def center(self):
        screen = QDesktopWidget().screenGeometry()
        size = self.geometry()
        self.move((screen.width() - size.width()) / 2, (screen.height() - size.height()) / 2)



    def start_thread_process(self):
        self.thread = threading.Thread(target=self.execute_process)
        self.thread.setDaemon(True)
        self.thread.start()
        self.thread.join()
        QMessageBox.information(None, "Finish", "Please check the file in \n %s "% self.file_name)

    def execute_process(self):
        self.file_name = re.sub("/", "\\\\", self.lineEdit_xlsx.text())
        logger.info("update the steps column first")
        adjust_sequence_steps(self.file_name)
        logger.info("update the ID column second")
        adjust_sequence_id(self.file_name)
        if self.lineEdit_new_values.text() is not None and self.lineEdit_old_values.text() is not None:
            print("should change value")
            change_value(self.file_name,self.lineEdit_old_values.text() ,self.lineEdit_new_values.text())

    def close_window(self):
        logger.info("Close the  Application ")
        qApp = QApplication.instance()
        qApp.quit()
        sys.exit()


if __name__ == "__main__":
    import sys
    log_format = logging.Formatter("%(asctime)s-%(message)s")
    file_handler = logging.FileHandler("update.log",mode="w")
    file_handler.setFormatter(fmt=log_format)
    stream_handle = logging.StreamHandler()
    stream_handle.setFormatter(fmt=log_format)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(stream_handle)
    logger.addHandler(file_handler)
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_X11InitThreads)
    app = QApplication(sys.argv)
    ui = StateMachine()
    ui.show()
    sys.exit(app.exec_())