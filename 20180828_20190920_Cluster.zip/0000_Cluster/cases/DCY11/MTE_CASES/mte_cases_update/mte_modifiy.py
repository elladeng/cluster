# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mte_modifiy.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MTE_CASES(object):
    def setupUi(self, MTE_CASES):
        MTE_CASES.setObjectName("MTE_CASES")
        MTE_CASES.resize(219, 148)
        self.layoutWidget = QtWidgets.QWidget(MTE_CASES)
        self.layoutWidget.setGeometry(QtCore.QRect(0, 20, 216, 77))
        self.layoutWidget.setObjectName("layoutWidget")
        self.gridLayout = QtWidgets.QGridLayout(self.layoutWidget)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.pushButton_xlsx = QtWidgets.QPushButton(self.layoutWidget)
        self.pushButton_xlsx.setObjectName("pushButton_xlsx")
        self.gridLayout.addWidget(self.pushButton_xlsx, 0, 0, 1, 1)
        self.lineEdit_xlsx = QtWidgets.QLineEdit(self.layoutWidget)
        self.lineEdit_xlsx.setObjectName("lineEdit_xlsx")
        self.gridLayout.addWidget(self.lineEdit_xlsx, 0, 1, 1, 1)
        self.label = QtWidgets.QLabel(self.layoutWidget)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.lineEdit_old_values = QtWidgets.QLineEdit(self.layoutWidget)
        self.lineEdit_old_values.setObjectName("lineEdit_old_values")
        self.gridLayout.addWidget(self.lineEdit_old_values, 1, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.layoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.lineEdit_new_values = QtWidgets.QLineEdit(self.layoutWidget)
        self.lineEdit_new_values.setObjectName("lineEdit_new_values")
        self.gridLayout.addWidget(self.lineEdit_new_values, 2, 1, 1, 1)
        self.pushButton_START = QtWidgets.QPushButton(MTE_CASES)
        self.pushButton_START.setGeometry(QtCore.QRect(0, 110, 75, 23))
        self.pushButton_START.setObjectName("pushButton_START")
        self.pushButton_STOP = QtWidgets.QPushButton(MTE_CASES)
        self.pushButton_STOP.setGeometry(QtCore.QRect(140, 110, 75, 23))
        self.pushButton_STOP.setObjectName("pushButton_STOP")

        self.retranslateUi(MTE_CASES)
        QtCore.QMetaObject.connectSlotsByName(MTE_CASES)

    def retranslateUi(self, MTE_CASES):
        _translate = QtCore.QCoreApplication.translate
        MTE_CASES.setWindowTitle(_translate("MTE_CASES", "Form"))
        self.pushButton_xlsx.setText(_translate("MTE_CASES", "MTE_CASES"))
        self.label.setText(_translate("MTE_CASES", "Old_Values"))
        self.label_2.setText(_translate("MTE_CASES", "New_Values"))
        self.pushButton_START.setText(_translate("MTE_CASES", "START"))
        self.pushButton_STOP.setText(_translate("MTE_CASES", "STOP"))

