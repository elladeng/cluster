values = {'PM_ON': 'IGN=1', 'Power OFF Time': '5000'}
import re
for key in values:
    old_resp = '1.Singal_A=Initial\n2.PM_ON\n3.WAIT=Power OFF Time'
    a = re.sub(old_value, values[key], old_resp)
    print(2222222222222222222)
    print(old_resp)
