import openpyxl
import re


def change__multi_values(file,sheet_name= None,old_values=None,new_values=None):
    wb = openpyxl.load_workbook(file)
    sheets = wb.get_sheet_names()
    sheets = sheets[1:]
    print(sheets)
    values = dict(zip(old_values.split(","),new_values.split(",")))
    print(values)
    if sheet_name is not None:
        ws = wb[sheet_name]
        rows = ws.max_row + 1
        columns = ws.max_column+1
        for key in values:
            for i in range(1, rows):
                for j in range(1,columns):
                    if ws.cell(i,j).value is not None:
                        if key in str(ws.cell(i,j).value):
                            old_resp = str(ws.cell(i,j).value)
                            ws.cell(i, j).value = re.sub(key,values[key],old_resp)
    else:
        for sheet in sheets:
            ws = wb[sheet]
            rows = ws.max_row+1
            columns = ws.max_column + 1
            for key in values.keys:
                for i in range(1, rows):
                    for j in range(1, columns):
                        if ws.cell(i, j).value is not None:
                            if key in str(ws.cell(i, j).value):
                                old_resp = str(ws.cell(i, j).value)
                                ws.cell(i, j).value = re.sub(key, values[key], old_resp)
    wb.save(file)
def adjust_sequence_steps(file):
    wb = openpyxl.load_workbook(file)
    sheets = wb.get_sheet_names()
    sheets = sheets[1:]
    print(sheets)
    for sheet in sheets:
        ws = wb[sheet]
        rows = ws.max_row + 1
        for i in range(1, rows):
            resp = ws.cell(i, 3).value
            last = []
            if resp is not None:
                resp1 = resp.split("\n")
                for j in range(0, len(resp1)):
                    if re.search("^\d+.", resp1[j]):
                        last.append(re.sub("^\d+", str(j + 1), resp1[j]))
                ws.cell(i,3).value = "\n".join(last)
    wb.save(file)


def adjust_sequence_id(file):
    wb = openpyxl.load_workbook(file)
    sheets = wb.get_sheet_names()
    sheets = sheets[1:]
    print(sheets)
    for sheet in sheets:
        ws = wb[sheet]
        rows = ws.max_row + 1
        items =[]
        for i in range(1, rows):
            resp = ws.cell(i, 1).value
            items.append(resp)
        print(items)
        len_items = len(items)
        numbers = []
        for i in range(1, len_items):
            if items[i] is not None and isinstance(items[i], str):
                if re.search("TC\d+|TM\d+|TG\d+", items[i]):
                    numbers.append(i)
        print(numbers)

        len_numbers = len(numbers)
        for i in range(0, len_numbers - 1):
            gap = numbers[i + 1] - numbers[i]
            if gap == 1:
                continue
            for j in range(1, gap):
                # print(numbers[i] + j)
                if items[numbers[i] + j] == "N":
                    items[numbers[i] + j] = "N"
                else:
                    items[numbers[i] + j] = j
        print(items)

        for i in range(1, rows):
            ws.cell(i, 1).value = items[i-1]
    wb.save(file)

def group_rows(file):
    wb = openpyxl.load_workbook(file)
    sheets = wb.get_sheet_names()
    for sheet in sheets:
        ws = wb[sheet]
        rows = ws.max_row + 1
        items = []
        TG =[]
        TM =[]
        TC =[]

        for i in range(1, rows):
            resp = ws.cell(i, 1).value
            items.append(resp)
        print(items)
        len_items = len(items)
        for i in range(3,len_items):
            if items[i] is not None and isinstance(items[i], str):
                if re.match("TM\d+", items[i]):
                    TM.append(i)
                if re.match("TG\d+", items[i]):
                    TG.append(i)
                if re.match("TC\d+", items[i]):
                    TC.append(i)
        TM.append(ws.max_row)
        print(TM)
        print(TG)
        print(TC)
        total = TM+TG+TC
        all_sort = sorted(total)
        for i in range(0, len(all_sort) - 1):
            if all_sort[i+1] - all_sort[i] == 1:
                continue
            else:
                ws.row_dimensions.group(all_sort[i] + 2, all_sort[i + 1], outline_level=1)
    # TM[0]=0
    # for i in range(0, len(TM) - 1):
    #         ws.row_dimensions.group(TM[i] + 2, TM[i + 1], outline_level=2)
    wb.save(file)





    # len_numbers = len(numbers)
    # for i in range(0, len_numbers - 1):
    #     print(numbers[i]+2,numbers[i+1])
    #     ws.row_dimensions.group(numbers[i]+2, numbers[i+1])
    # wb.save(file)
if __name__ == "__main__":
    file = r"E:\000_CSharp_Project\cases\book2.xlsx"
    old_values = "PM_ON,Power OFF Time"
    new_values = "IGN=1,5000"
    change__multi_values(file,"Telltale (2)",old_values,new_values)
    # adjust_sequence_steps(file)
    # adjust_sequence_id(file)
    # group_rows(file)
