import sys
from PyQt5.QtWidgets import QApplication, QFileSystemModel, QTreeView, QWidget, QVBoxLayout,\
                             QDesktopWidget,QMainWindow,QMessageBox,QFileDialog,QAction
from PyQt5 import QtGui,QtCore
from PyQt5.QtCore import QSettings
from PyQt5.QtGui import QIcon,QImage,QPixmap
from cases.flashfirmware.UI import Ui_Form
import os
import cv2
import time
import pyautogui
from pywinauto.application import Application
import PIL
import datetime
import CANoe
import threading
import logging
import re
import subprocess
from cases.flashfirmware.UI.vision import Vision_Form
from pywinauto.findwindows import ElementAmbiguousError

logger = logging.getLogger(__name__)

class VISION(QWidget,Vision_Form):  # 创建子UI类
    def __init__(self):
        super(VISION, self).__init__()
        self.setupUi(self)


class FLASHAPP(QMainWindow,Ui_Form):
    def __init__(self,parent=None):
        super(FLASHAPP,self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle("DSA auto flash")
        self.center()
        self.port_check()
        self.comboBox_com.currentIndexChanged.connect(self.port_imf)
        self.web = 0
        self.vector_name = "CANalyzer.Application"
        self.init_settings()
        self.pushButton_start.clicked.connect(self.start_thread_process)
        self.pushButton_img_folder.clicked.connect(self.choose_folder)
        self.pushButton_cfgfile.clicked.connect(self.choose_cfg_file)
        self.pushButton_log_cfg.clicked.connect(self.choose_cfg_log_file)
        self.pushButton_vbf.clicked.connect(self.choose_vbf_folder)
        self.pushButton_eol.clicked.connect(self.choose_eol_folder)
        self.pushButton_stop.clicked.connect(self.close_window)
        self.radioButton_CANalyzer.setChecked(True)
        self.radioButton_CANalyzer.toggled.connect(lambda:self.choose_vector_tool(self.radioButton_CANalyzer))
        self.radioButton_CANalyzer.toggled.connect(lambda: self.choose_vector_tool(self.radioButton_CANoe))
        self.pushButton_save_ini.clicked.connect(self.save_settings)
        self.vision_window = VISION()
        self.menuvision.triggered[QAction].connect(self.show_vision_window)
        self.menuAbout.triggered[QAction].connect(self.show_version)
        self.timer_camera = QtCore.QTimer() #线程
        self.cap = cv2.VideoCapture() #不传参数


    def show_version(self,q):
        if q.text() == "version":
            QMessageBox.information(self, "version",
                                    "version:1.0.0\r\nauthor:ella\r\ncontact:mdeng4@yfve.com.cn", \
                                    QMessageBox.Yes | QMessageBox.No)

    def show_vision_window(self,q):
        if q.text() == "Video":
            self.vision_window.show()
            self.vision_window.label_image.setScaledContents(True)
            self.vision_window.pushButton_start_video.clicked.connect(self.show_video)
            self.vision_window.pushButton_stop_video.clicked.connect(self.close_video)

    def show_video(self):
        self.vision_window.pushButton_start_video.setEnabled(False)
        self.vision_window.pushButton_stop_video.setEnabled(True)
        if self.timer_camera.isActive() == False:
            flag = self.cap.open(self.web)
            self.cap.set(3,2046)
            self.cap.set(4,1024)
            if flag == False:
                QMessageBox.warning(self,"choose web","please choose the webcamer port")
            else:
                self.timer_camera.start(30)
                print("horizontal is %s"%self.cap.get(3))
                print("vertical is %s" % self.cap.get(4))
        self.timer_camera.timeout.connect(self.show_camera)

    def show_camera(self):
        ret, Im = self.cap.read()
        image_height, image_width, image_depth = Im.shape  # 获取图像的高，宽以及深度。
        QIm = cv2.cvtColor(Im, cv2.COLOR_BGR2RGB)  # opencv读图片是BGR，qt显示要RGB，所以需要转换一下
        QIm = QImage(QIm.data, image_width, image_height,  # 创建QImage格式的图像，并读入图像信息
                     image_width * image_depth,
                     QImage.Format_RGB888)
        self.vision_window.label_image.setPixmap(QPixmap.fromImage(QIm))

    def close_video(self):
        if self.cap.isOpened():
            print("close the cap ")
            self.cap.release()
        if self.timer_camera.isActive():
            print("close the threading ")
            self.timer_camera.stop()


        self.vision_window.label_image.clear()
        self.vision_window.pushButton_start_video.setEnabled(True)
        self.vision_window.pushButton_stop_video.setEnabled(False)

    def center(self):
        screen = QDesktopWidget().screenGeometry()
        size = self.geometry()
        self.move((screen.width() - size.width()) / 2, (screen.height() - size.height()) / 2)

    def init_settings(self):
        logger.info("init config ini ")
        settings = QSettings("config.ini", QSettings.IniFormat)  # 方法1：使用配置文件
        settings.beginGroup("Config")
        self.lineEdit_swdl.setText(settings.value("swdl_position"))
        self.lineEdit_add.setText(settings.value("add_position"))
        self.lineEdit_folder.setText(settings.value("folder_position"))
        self.lineEdit_ok.setText(settings.value("open_position"))
        self.lineEdit_download.setText(settings.value("download_position"))
        self.lineEdit_closeapp.setText(settings.value("close_position"))
        self.lineEdit_exit.setText(settings.value("exit_position"))
        self.lineEdit_cfg.setText(settings.value("cfg"))
        self.lineEdit_cycle.setText(settings.value("cycle"))
        self.lineEdit_flashing_duration.setText(settings.value("duration"))
        self.lineEdit_img_folder.setText(settings.value("img"))
        self.lineEdit_log_cfg.setText(settings.value("cfg_log"))
        self.lineEdit_vbf_firmware.setText(settings.value("vbf_file"))
        self.lineEdit_eol_firmware.setText(settings.value("eol_file"))

        settings.endGroup()

    def save_settings(self):
        logger.info("save settings")
        settings = QSettings("config.ini", QSettings.IniFormat)
        settings.beginGroup("Config")
        settings.setValue("swdl_position", self.lineEdit_swdl.text())
        settings.setValue("add_position", self.lineEdit_add.text())
        settings.setValue("folder_position", self.lineEdit_folder.text())
        settings.setValue("open_position", self.lineEdit_ok.text())
        settings.setValue("download_position", self.lineEdit_download.text())
        settings.setValue("close_position", self.lineEdit_closeapp.text())
        settings.setValue("exit_position", self.lineEdit_exit.text())
        settings.setValue("cycle",self.lineEdit_cycle.text())
        settings.setValue("duration",self.lineEdit_flashing_duration.text())
        settings.setValue("cfg",self.lineEdit_cfg.text())
        settings.setValue("cfg_log", self.lineEdit_log_cfg.text())
        settings.setValue("vbf_file", self.lineEdit_vbf_firmware.text())
        settings.setValue("eol_file", self.lineEdit_eol_firmware.text())
        settings.endGroup()





    def choose_folder(self):
        logger.info("choose folder")
        # if meet UI hang or can't work while opening file dialog ,please add options=QFileDialog.DontUseNativeDialog
        image_folder =QFileDialog.getExistingDirectory(self, "choose folder",options=QFileDialog.DontUseNativeDialog)
        if image_folder is not None:
            self.lineEdit_img_folder.setText(image_folder)

    def choose_cfg_file(self):
        logger.info("choose cfg file")
        cfg_file_name  = QFileDialog.getOpenFileName(self, "open cfg file", filter="cfgfiles(*.cfg)", options= QFileDialog.DontUseNativeDialog)
        if cfg_file_name is not None:
            self.lineEdit_cfg.setText(cfg_file_name[0])

    def choose_cfg_log_file(self):
        logger.info("choose cfg log file")
        cfg_file_name = QFileDialog.getOpenFileName(self, "open cfg log file", filter="cfgfiles(*.cfg)",
                                                    options=QFileDialog.DontUseNativeDialog)
        if cfg_file_name is not None:
            self.lineEdit_log_cfg.setText(cfg_file_name[0])

    def choose_vbf_folder(self):
        logger.info("select vbf folder")
        vbf_folder =QFileDialog.getExistingDirectory(self, "choose folder",options=QFileDialog.DontUseNativeDialog)
        if vbf_folder is not None:
            self.lineEdit_vbf_firmware.setText(vbf_folder)


    def choose_eol_folder(self):
        logger.info("select eol folder")
        eol_folder = QFileDialog.getExistingDirectory(self, "choose folder", options=QFileDialog.DontUseNativeDialog)
        if eol_folder is not None:
            self.lineEdit_eol_firmware.setText(eol_folder)

    def choose_vector_tool(self,btn):
        logger.info("choose vector tool")
        if btn.text() == "CANoe":
            if btn.isChecked():
                self.vector_name = "CANoe.Application"
            else:
                self.vector_name = ""
        if btn.text() == "CANalyzer":
            if btn.isChecked():
                self.vector_name = "CANalyzer.Application"
            else:
                self.vector_name = ""
        logger.info("vector tool is %s"%self.vector_name)



    def close_window(self):
        # self.thread.stop()
        logger.info("Close the DSA auto flash Application ")
        qApp = QApplication.instance()
        qApp.quit()
        sys.exit()


    def sync_vcm(self):
        """
        since the vcmsim.exe not support run in background ,so it should enable it by manual
        step1: run cmd enter to vcmsim.exe folder
        step2:title vcm
        step3:vcmsim.exe Prog
        :return:
        """

        pyautogui.hotkey("win", "r")
        pyautogui.typewrite("cmd")
        pyautogui.press("enter")
        time.sleep(1)
        pyautogui.typewrite("cd vcmsim")
        time.sleep(1)
        pyautogui.press("enter")
        pyautogui.typewrite("title vcm")
        pyautogui.press("enter")
        time.sleep(1)
        pyautogui.typewrite("vcmsim.exe Prog")
        pyautogui.press("enter")
        time.sleep(3)

        QMessageBox.information(self,"sync vcm", "step1: run cmd enter to vcmsim.exe folder\r\nstep2:title vcm\r\nstep3:vcmsim.exe Prog",\
                                QMessageBox.Yes|QMessageBox.No)

    def port_check(self):
        # # 检测所有存在的串口，将信息存储在字典中
        # self.Com_Dict = {}
        # port_list = list(serial.tools.list_ports.comports())
        # self.comboBox_com.clear()
        # for port in port_list:
        #     self.Com_Dict["%s" % port[0]] = "%s" % port[1]
        #     self.comboBox_com.addItem(port[0])
        # if len(self.Com_Dict) == 0:
        #     self.comboBox_com.setText(" 无串口")
        self.comboBox_com.addItem("0")
        self.comboBox_com.addItem("1")

    # 串口信息
    def port_imf(self):
        # 显示选定的串口的详细信息
        imf_s = self.comboBox_com.currentText()
        if imf_s != "":
            self.web = imf_s


    def connect_win_vcm_sync(self):
        logger.info("start to sync vcm flexray")
        pyautogui.hotkey("win","r")
        pyautogui.typewrite("cmd")
        pyautogui.press("enter")
        time.sleep(1)
        pyautogui.typewrite("cd vcmsim")
        time.sleep(1)
        pyautogui.press("enter")
        pyautogui.typewrite("title vcm")
        pyautogui.press("enter")
        time.sleep(1)
        pyautogui.typewrite("vcmsim.exe Prog")
        pyautogui.press("enter")
        time.sleep(3)

        # self.app_vcm = Application().connect(title_re=r"Administrator:  vcm")
        # self.diag_vcm = self.app_vcm.window(title=r"Administrator:  vcm")
        # self.diag_vcm.type_keys("{UP}")  # input last cmd steps (vcmsim.exe Prog)
        # time.sleep(5)
        # self.diag_vcm.type_keys("{ENTER}")  # execute vcmsim.exe
        # time.sleep(10)

    def connect_win_dsa(self):
        """
        step1: luanch the DSA.exe
        step2: acquire the DSA win app handle
        step3: press connect button through hot key
        :return:
        """
        logger.info("connect with dsa")
        try:
            self.app = Application().start("C:\Program Files (x86)\Volvo Car Corporation\DSA 0.22.2.0\DSA.exe")
            time.sleep(10)
            self.app = Application().connect(title_re=r"Diagnostic and Software Download Application")
            # time.sleep(5)
            self.diag = self.app.window(title="Diagnostic and Software Download Application")
            self.diag.maximize()
            time.sleep(5)
            self.diag.type_keys("%C")
            time.sleep(5)
        except ElementAmbiguousError:
            logger.info("open DSA Failed then kill it ")
            os.system("taskkill /im DSA.exe /f 2>nul >nul")
            resp_dsa = 0
            return resp_dsa
        else:
            resp_dsa = 1
            return resp_dsa   





    def load_firmware(self,cycle):
        logger.info("choose firmware files now ")
        swdl_button_position = self.lineEdit_swdl.text().split(",")
        pyautogui.click(int(swdl_button_position[0]), int(swdl_button_position[1]))  # clik swdl
        time.sleep(2)
        add_button_position = self.lineEdit_add.text().split(",")
        pyautogui.click(int(add_button_position[0]), int(add_button_position[1])) # click add
        time.sleep(2)

        if int(cycle) % 2 == 1:
            logger.info("Flash VBF firmware")
            vbf_firmware = re.sub("/", "\\\\", self.lineEdit_vbf_firmware.text())
            print(vbf_firmware)
            pyautogui.typewrite(vbf_firmware)
        else:
            logger.info("Flash EOL firmware")
            eol_firmware = re.sub("/", "\\\\", self.lineEdit_eol_firmware.text())
            print(eol_firmware)
            pyautogui.typewrite(eol_firmware)
        pyautogui.press("enter")
        time.sleep(2)
        folder_button_position = self.lineEdit_folder.text().split(",")
        pyautogui.click(int(folder_button_position[0]), int(folder_button_position[1]))  # click add
        time.sleep(2)
        pyautogui.hotkey("ctrlleft", "a")
        time.sleep(2)
        ok_button_position = self.lineEdit_ok.text().split(",")
        pyautogui.click(int(ok_button_position[0]), int(ok_button_position[1]))
        time.sleep(2)


    def flash_fireware(self,cycle):
        logging.info("download now ")
        duration = self.lineEdit_flashing_duration.text()
        download_button_position = self.lineEdit_download.text().split(",")
        pyautogui.click(int(download_button_position[0]), int(download_button_position[1]))
        self.start_logging()
        if int(cycle) % 2 == 0:
            time.sleep(120)
        else:
            time.sleep(int(duration))
        logger.info("close the logging vector tool")
        self.close_vector_tool()


    def capture_descktop_icon(self):
        logger.info("capture desktop_icon")
        im = PIL.ImageGrab.grab()
        name = os.path.join(re.sub("/","\\\\",self.lineEdit_img_folder.text()), datetime.datetime.now().strftime('%Y-%m-%d_%H_%M_%S'))
        logger.info("image name is %s",name)
        im.save(name+".jpg")


    def open_vector_tool(self):
        logger.info("open vector tool")
        print(self.vector_name)
        self.oe_app = CANoe.CANoe(name=self.vector_name)
        print("self  oe is %s", self.oe_app)
        print(re.sub("/","\\\\",self.lineEdit_cfg.text()))
        self.oe_app.open_simulation(re.sub("/","\\\\",self.lineEdit_cfg.text()))
        time.sleep(20)
        self.oe_app.start_Measurement()
        time.sleep(30)

    def capture_image(self):

        logger.info("web camera is working")
        if self.web == "":
            logger.info("web camera is not working,please make sure you have choose the webcamera")
            QMessageBox.warning(self,"choose web","please choose the webcamer port")
        name = os.path.join(re.sub("/","\\\\",self.lineEdit_img_folder.text()),datetime.datetime.now().strftime('%Y-%m-%d_%H_%M_%S'))
        logger.info("image name is %s",name)

        cap = cv2.VideoCapture(int(self.web),cv2.CAP_DSHOW)
        cap.set(3, 2040.0)
        cap.set(4, 1086.0)
        try:
            ret, frame = cap.read()
            print(cap.get(3))
            print(cap.get(4))
            cv2.imwrite(name+".jpg", frame)
        finally:
            cap.release()



    def close_vector_tool(self):
        """
        step1: close vector APP
        :return:
        """
        logger.info("close vector tool")
        print("self close oe is %s", self.oe_app)
        self.oe_app.close_simulation()
        time.sleep(40)

    def close_dsa_vcm_app(self):
        logger.info("close dsa and vcm app now")
        pyautogui.click(600,403)
        close_button = self.lineEdit_closeapp.text().split(",")
        pyautogui.click(int(close_button[0]), int(close_button[1]))
        time.sleep(5)
        confirm_button = self.lineEdit_exit.text().split(",")
        pyautogui.click(int(confirm_button[0]), int(confirm_button[1]))
        time.sleep(5)
        output = subprocess.check_output('tasklist', shell=True)
        if "DSA.exe" in str(output):
            logger.info("kill the process")
            os.system("taskkill /im DSA.exe /f 2>nul >nul")

        # close vcmsim
        os.system("taskkill /im VcmSim.exe /f")
        time.sleep(5)
        os.system("taskkill /im cmd.exe /f")

    def start_logging(self):
        logger.info("open logging vector tool")
        self.oe_app = CANoe.CANoe(name=self.vector_name)
        print("self lcfg oe is %s",self.oe_app)
        print(re.sub("/", "\\\\", self.lineEdit_log_cfg.text()))
        self.oe_app.open_simulation(re.sub("/", "\\\\", self.lineEdit_log_cfg.text()))
        time.sleep(5)
        self.oe_app.start_Measurement()
        time.sleep(5)



    def start_thread_process(self):
        self.repeat_cycle = int(self.lineEdit_cycle.text())
        logger.info("Total Cycle is %s",self.repeat_cycle)
        self.thread = threading.Thread(target=self.exectue_process)
        self.thread.setDaemon(True)
        self.thread.start()


    def exectue_process(self):
        """
        1.connect vcm sync window
        2.connect DSA appplication
        :return:
        """
        for cycle in range(1,self.repeat_cycle+1):
            logger.info("Current cycle is %s",cycle)
            self.lineEdit_status.setText("Current cycle %s starts to run" %cycle )
            self.connect_win_vcm_sync()
            resp = self.connect_win_dsa()
            if not resp:
                continue
            self.load_firmware(cycle)
            self.flash_fireware(cycle)
            self.capture_descktop_icon()
            self.close_dsa_vcm_app()
            self.open_vector_tool()
            self.capture_image()
            self.close_vector_tool()
            time.sleep(30)
            self.lineEdit_status.setText("cycle %s finished" % cycle)
            logging.info("Finish cycle is %s",cycle)







if __name__ == "__main__":
    import sys
    log_format = logging.Formatter("%(asctime)s-%(message)s")
    file_handler = logging.FileHandler("flashfirmware.log",mode="w")
    file_handler.setFormatter(fmt=log_format)


    stream_handle = logging.StreamHandler()
    stream_handle.setFormatter(fmt=log_format)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)


    logger.addHandler(stream_handle)
    logger.addHandler(file_handler)
    # logging.basicConfig(level=logging.INFO,format="%(asctime)s-%(message)s",filename="flashfirmware.log",filemode='w')
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_X11InitThreads)
    app = QApplication(sys.argv)
    ui = FLASHAPP()
    ui.show()
    sys.exit(app.exec_())

