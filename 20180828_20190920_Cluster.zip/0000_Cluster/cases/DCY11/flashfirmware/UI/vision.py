# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'vision.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Vision_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(587, 339)
        self.pushButton_start_video = QtWidgets.QPushButton(Form)
        self.pushButton_start_video.setGeometry(QtCore.QRect(10, 280, 75, 23))
        self.pushButton_start_video.setObjectName("pushButton_start_video")
        self.scrollArea = QtWidgets.QScrollArea(Form)
        self.scrollArea.setGeometry(QtCore.QRect(9, 19, 531, 251))
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QtWidgets.QWidget()
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 529, 249))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.label_image = QtWidgets.QLabel(self.scrollAreaWidgetContents)
        self.label_image.setGeometry(QtCore.QRect(10, 0, 501, 251))
        self.label_image.setText("")
        self.label_image.setObjectName("label_image")
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.pushButton_stop_video = QtWidgets.QPushButton(Form)
        self.pushButton_stop_video.setGeometry(QtCore.QRect(470, 280, 75, 23))
        self.pushButton_stop_video.setObjectName("pushButton_stop_video")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.pushButton_start_video.setText(_translate("Form", "start"))
        self.pushButton_stop_video.setText(_translate("Form", "stop"))

