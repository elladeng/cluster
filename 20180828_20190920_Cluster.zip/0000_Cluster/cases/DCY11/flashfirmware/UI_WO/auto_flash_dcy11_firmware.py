import pyautogui
from pywinauto.application import Application
import PIL
import subprocess
import time
import datetime
import CANoe
from equipment.webcam import OpenCVWebCam
import os
import logging


class WINFLASHFIRMWARE(object):
    def __init__(self,vcmsim_path,dsa_path,cycle):
        """
        1. run vcmsim  to sync flexray vector (should open cmd.exe--->title vcm---vcmsim.exe  Prog--->crtl+c )
        2. openDSA tool
        """
        # resp = subprocess.Popen(r'cmd /c "C:\vcmsim\VcmSim.exe Boot"', cwd=r"C:\vcmsim", close_fds=False,
        #                         shell=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        # time.sleep(30)
        self.app_vcm = Application().connect(title_re=r"Administrator:  vcm")
        self.diag_vcm = self.app_vcm.window(title=r"Administrator:  vcm")
        self.diag_vcm.type_keys("{UP}")
        time.sleep(2)
        self.diag_vcm.type_keys("{ENTER}")
        time.sleep(10)
        self.app = Application().start("C:\Program Files (x86)\Volvo Car Corporation\DSA 0.22.2.0\DSA.exe")
        time.sleep(30)
        self.app = Application().connect(title_re=r"Diagnostic and Software Download Application")
        # time.sleep(5)
        self.diag = self.app.window(title="Diagnostic and Software Download Application")
        self.diag.maximize()
        time.sleep(5)
        self.diag.type_keys("%C")
        time.sleep(5)
        self.cycle = cycle


    def load_firmware(self):
        pyautogui.click(473,90) #clik swdl
        time.sleep(2)
        pyautogui.click(1341,207)#click add
        time.sleep(2)
        pyautogui.click(648, 214)  # click add
        time.sleep(2)
        pyautogui.hotkey("ctrlleft","a")
        time.sleep(2)
        pyautogui.click(912, 454)
        time.sleep(2)

    def flash_firmware(self):
        pyautogui.click(1181,343)
        # time.sleep(5400)
        time.sleep(60)
        im = PIL.ImageGrab.grab()
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d_%H_%M_%S')
        name = os.path.join(r"c:\image",timestamp)
        im.save(name+".jpg")

    def get_cluster_image(self,cfg_file):
        """
        1.initial CANoe
        2.open cfgfile
        3.start app
        4.get gip version
        4.stop app
        """
        self.oe_app = CANoe.CANoe(name="CANalyzer.Application")
        # self.oe_app = CANoe.CANoe()
        self.oe_app.open_simulation(cfg_file)
        time.sleep(60)
        self.oe_app.start_Measurement()
        time.sleep(60)
        web = OpenCVWebCam(0)
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d_%H_%M_%S')
        name = os.path.join(r"c:\image", timestamp)
        web.capture_image(name+".png")
        # version = self.oe_app.get_SysVar("test_uds","DA09")
        # time.sleep(5)
        # print("----------------")
        # print(version)
        # logging.info("Current cycle is %s and version is %s"%(self.cycle,version))

        self.oe_app.close_simulation()
        time.sleep(30)

    def close_app(self):
        pyautogui.click(1345, 8)
        time.sleep(2)
        pyautogui.click(674, 419)
        time.sleep(5)
        #close vcmsim
        app = Application().connect(title_re=r"Administrator:  vcm - vcmsim.exe  Prog")
        diag = app.window(title=r"Administrator:  vcm - vcmsim.exe  Prog")
        diag.type_keys("%c")
        #os.system("taskkill /F /IM vcmsim.exe")

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s', filename="flash_firmware.log"
    )
    # vcmsim_path = r"C:\vcmsim"
    # dsa_path =r"C:\Program Files (x86)\Volvo Car Corporation\DSA 0.22.2.0\DSA.exe"
    # a_cfg_file = r"D:\00_project\03_DCY11\06_Project\new_for_automation\dcy11_auto.cfg"
    # oe= r"D:\00_project\01_CMA\04_CASES\10_Network\Cma_0322 - Copy\Cma_0322.cfg"
    # oe_app = CANoe.CANoe(name="CANoe.Application")
    # #
    # oe_app.open_simulation(oe)
    # time.sleep(20)
    # oe_app.start_Measurement()
    # web = OpenCVWebCam(0)
    # timestamp = datetime.datetime.now().strftime('%Y-%m-%d_%H_%M_%S')
    # name = os.path.join(r"c:\image", timestamp)
    # web.capture_image(name + ".png")
    # #
    # for i in range(0,2):
    #     app = WINFLASHFIRMWARE(vcmsim_path,dsa_path,i)
    #     print("current start  cycle is %s",i)
    #     app.load_firmware()
    #     app.flash_firmware()
    #     app.close_app()
    #     app.get_cluster_image(a_cfg_file)
    #     print("current finish cycle is %s",i)

    app = CANoe.CANoe(name="CANalyzer.Application")
    app.open_simulation(cfgname=r"E:\000_CSharp_Project\01_Project\new_for_automation_0622\dcy11_auto.cfg")
    app.start_Measurement()
    time.sleep(10)
    da09 = "40,03,00,03,22,DA,09,00"
    app.call_capl_diag_function("SendRawDiagnostic", da09)

