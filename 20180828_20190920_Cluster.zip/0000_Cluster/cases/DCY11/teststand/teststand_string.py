def t_string(a):
    return "Hello World %s"%a


if __name__ =="__main__":
    a= "ella"
    print((t_string(a)))