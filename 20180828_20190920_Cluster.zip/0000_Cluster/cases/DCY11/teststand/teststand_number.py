def sum(a,b):
    return a+b
def t_string(a):
    return "Hello World %s"%a

if __name__ =="__main__":
    a=5
    b=6
    sum(a,b)
    print(type(t_string(a)))
