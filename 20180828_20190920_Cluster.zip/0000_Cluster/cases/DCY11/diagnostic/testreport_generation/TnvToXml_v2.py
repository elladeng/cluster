import xml.etree.ElementTree as ET
import sys
import os


def convertVerdict(verdict):
	if verdict == "Passed":
		return "OK"
	elif verdict == "Failed":
		return "Not OK"
	elif verdict == "NotExecuted":
		return "Not run"
	elif verdict == "NA":
		return "Not Applicable"
	else:
		return "Unknown Result"

def insertVerdictInXml(id, verdict, xmlRoot):
	for testCase in xmlRoot.iter('TestCase'):
		if testCase.get('legacyId').endswith(id):
			testCase.find('Result').text = convertVerdict(verdict)
			return True
	return False

def transferToXml(tnvFile, xmlFile): 
	try:
		tnvRoot = ET.parse(tnvFile).getroot()
	except:
		print("Could not read tnv file: " + tnvFile)
		return
	try:
		xmlTree = ET.parse(xmlFile)
	except:
		print("Could not read xml file: " + xmlFile)
		return
	xmlRoot = xmlTree.getroot()
	
	for tnvTest in tnvRoot.iter('test_case'):
		if insertVerdictInXml(tnvTest.get('id'), tnvTest.get('verdict'), xmlRoot):
			print("Inserted " + tnvTest.get('id') + " in xml")
		else:
			print("Could not find test case with legacy id " + tnvTest.get('id') + " in xml")
	
	xmlTree.write(xmlFile, method='html')
	

	
if __name__ == "__main__":
	transferToXml(sys.argv[1], sys.argv[2])