import xml.etree.ElementTree as ET
import sys
import csv
import os


def convertVerdict(verdict):
	if verdict == "Passed":
		return "OK"
	elif verdict == "Failed":
		return "Not OK"
	elif verdict == "NotExecuted":
		return "Not run"
	elif verdict == "NA":
		return "Not Applicable"
	else:
		return "Unknown Result"

def insertVerdictInCsv(legacyIdCol, resultCol, row, tnvRoot):
	legacyId = row[legacyIdCol]
	print(legacyId)
	for testCase in tnvRoot.iter('test_case'):
		if legacyId.endswith(testCase.get('id')):
			row[resultCol] = convertVerdict(testCase.get('verdict'))
			print("Inserted " + testCase.get('id') + " in csv")
			return True
	return False

def transferToCsv(tnvFile, csvFile):
	try:
		tnvRoot = ET.parse(tnvFile).getroot()
		print(tnvRoot)
	except:
		print("Could not read tnv file: " + tnvFile)
		return

	addedIds = []
	try:
		with open(csvFile, 'r', encoding="utf-8") as inFile, open(csvFile + "temp", 'w', newline="\n", encoding="utf-8") as outFile:
			reader = csv.DictReader(inFile)
			print(reader)
			columns = reader.fieldnames
			print(columns)
			writer = csv.DictWriter(outFile, columns)
			print(writer)

			writer.writeheader()
			for row in reader:
				print(row)
				if insertVerdictInCsv('LegacyId', 'Result', row, tnvRoot):
					addedIds.append(row['LegacyId'])
				writer.writerow(row)

		for testCase in tnvRoot.iter('test_case'):
			def contains():
				for id in addedIds:
					if id.endswith(testCase.get('id')):
						return
				print("Could not find test case with legacy id " + testCase.get('id') + " in csv")
			contains()
		
		os.remove(csvFile)
		os.rename(csvFile + "temp", csvFile)
	except:
		print("Could not read csv file: " + csvFile)
		os.remove(csvFile + "temp")

if __name__ == "__main__":
	# transferToCsv(sys.argv[1], sys.argv[2])
	transferToCsv(r'E:\0000_Cluster\cases\DCY11\diagnostic\Tvn\DiagCom-FR_APP.tnv', r'E:\0000_Cluster\cases\DCY11\diagnostic\Tvn\testreport.csv')