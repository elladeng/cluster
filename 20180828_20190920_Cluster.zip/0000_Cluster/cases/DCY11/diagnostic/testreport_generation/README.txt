To use the scripts, run the following from command line:
	py TnvToCsv.py [Tnv File] [Csv File]
or
	py TnvToXml.py [Tnv File] [Xml File]

Where [Tnv File] should be replaced with the path to the tnv file, for example: "C:\Test Results\SWDL-CAN.tnv"
And [Xml File] or [Csv File] should be replaced with the path to the xml or csv file, for example: "C:\Test Results\AUD - Base technologies device tests.xml"
	
If a file name or path contain spaces, surround it with quotes: "My Tnv File.tnv"

If you get the message "'py' is not recognized as an internal or external command"
You'll either need to install python or set the python environment variables as described here: https://docs.python.org/2/using/windows.html#excursus-setting-environment-variables