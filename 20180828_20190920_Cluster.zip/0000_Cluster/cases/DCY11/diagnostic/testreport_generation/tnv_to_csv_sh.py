import xml.etree.ElementTree as ET
import sys
import csv
import os

def transferToCsv(tnvFile, csvFile):
    tnvRoot = ET.parse(tnvFile).getroot()
    headers = ['TestCaseName', 'id', 'rev', 'par', 'verdict']
    rows =[]
    for testCase in tnvRoot.iter('test_case'):
        rows.append((testCase.get('name'),testCase.get('id'),testCase.get("rev"),testCase.get("par"),testCase.get('verdict')))
    print(rows)
    if os.path.exists(csvFile):
        with open(csvFile,"a+",newline="" ) as f:
            f_csv = csv.writer(f)
            for row in rows:
                f_csv.writerow(row)
    else:
        with open(csvFile, "a+", newline="") as f:
            f_csv = csv.writer(f)
            f_csv.writerow(headers)
            for row in rows:
                f_csv.writerow(row)

if __name__ =="__main__":

    csvfile = r"E:\0000_Cluster\cases\DCY11\diagnostic\Tvn\report.csv"
    base_name=r"E:\0000_Cluster\cases\DCY11\diagnostic\Tvn"
    names = os.listdir(base_name)
    tnvfiles =[]
    for name in names:
        if name.endswith("tnv"):
            tnvfiles.append(name)
    print(tnvfiles)
    for tnvFile in tnvfiles:
        transferToCsv(os.path.join(base_name,tnvFile),csvfile)