import openpyxl
from collections import defaultdict
import xml.etree.ElementTree as ET
import re

DID_Geely = defaultdict(list)
def get_pn(excel_file,sheet_name):

    wb = openpyxl.load_workbook(filename=excel_file)
    ws = wb[sheet_name]
    lens = ws.max_row + 1
    sequence =["SWLM","SWCE","SWL2","SWP1\(Fuel Table 50L 1\)","SWP3","SWP4","SWP2","SWP5","0000000000",\
               "SWP6","SWP7","SWP8","SXBL2"]
    DID_Geely["F1AE"]=["0D"]
    DID_Geely["F12E"] = ["0D"]
    for seq in sequence:
        if seq == "0000000000":
            DID_Geely[ws.cell(i, 6).value].append("00000000000000000")
        for i in range(1,lens):
            if re.search(seq, str(ws.cell(i,2).value)):
                DID_Geely[ws.cell(i,6).value].append(str(ws.cell(i,8).value)
                +"20" + "20" + hex(ord(str(ws.cell(i,10).value)))[2:])
                break


    for seq in sequence:
        if seq == "0000000000":
            DID_Geely[ws.cell(i, 7).value].append("00000000000000")
        for i in range(1, lens):
            if re.search(seq, str(ws.cell(i, 2).value)):
                if str(ws.cell(i, 13).value) == "N/A":
                    DID_Geely[ws.cell(i, 7).value].append(str(ws.cell(i, 11).value)+"20")
                    break
                else:
                    DID_Geely[ws.cell(i, 7).value].append(str(ws.cell(i, 11).value)
                                                          + "20" + hex(ord(str(ws.cell(i, 13).value)[0]))[2:] +
                                                          hex(ord(str(ws.cell(i, 13).value)[1]))[2:])
                    break

    for i in range(1,lens):
        if re.search("55L|47L|40L|SBL|VCC",str(ws.cell(i,2).value)):
            pass

        else:
                if  re.search("F(\d+)",str(ws.cell(i,6).value)):
                    if re.search("F1AE",str(ws.cell(i,6).value)):
                        pass
                    else:
                        DID_Geely[ws.cell(i, 6).value].append(str(ws.cell(i,8).value)+"20"+"20"+
                                                           hex(ord(str(ws.cell(i,10).value)))[2:])
    for i in range(1, lens):
        if re.search("55L|47L|40L|SBL|VCC", str(ws.cell(i, 2).value)):
            pass
        else:
            if re.search("F(\d+)", str(ws.cell(i, 7).value)):
                if re.search("F12E", str(ws.cell(i, 7).value)):
                    pass
                else:
                    DID_Geely[ws.cell(i, 7).value].append(str(ws.cell(i, 11).value) + "20"+
                                                       hex(ord(str(ws.cell(i, 13).value)[0]))[2:]+
                                                       hex(ord(str(ws.cell(i, 13).value)[1]))[2:])
    print(DID_Geely)

def get_xml_pn(xml_file):
    ET.register_namespace("","http://www.vector-informatik.de/CANoe/TestModule/1.27")
    tree = ET.parse(xml_file)
    root = tree.getroot()
    ns = {"vector":"http://www.vector-informatik.de/CANoe/TestModule/1.27"}
    for testgroup_element in root.findall("./vector:testgroup[@title='Read part number DID']",ns):
        for testcase_element in testgroup_element:
            for key in DID_Geely.keys():
                if key in (testcase_element.attrib["title"]):
                    old_pn_value = ("").join(DID_Geely[key])
                    new_pn_value = ""
                    for i in range(0,len(old_pn_value)-1,2):
                        new_pn_value+=old_pn_value[i]+old_pn_value[i+1]+" "
                    DID_Geely[key] = new_pn_value # change the value with space between 2 chars.
                    # print(DID_Geely)
                    print(DID_Geely)
                    pn_elements = testcase_element.findall(".//vector:diagparam[@format='bytesequence']",ns)#.//vector 多重namespace
                    for pn_element in pn_elements:
                        if pn_element is not None:
                            if len(pn_element.text) > 10:
                                if re.match("[A-Z]+",pn_element.text):
                                    pn_element.text=pn_element.text[0:6]+DID_Geely[key].strip()
                                else:
                                    pn_element.text=DID_Geely[key].strip()
    tree.write('test.xml', encoding='UTF-8')


if __name__ == "__main__":
    file = r"D:\000_TMP\Worksheet in 2018_CEVT_CMA_RN.xlsx"
    sheet_name = "5.6.5"
    get_pn(file,sheet_name)
    xml_file = r"D:\000_TMP\tester_all.xml"
    get_xml_pn(xml_file)
    a = r"D:/000_TMP/tester_all.xml"
    import os.path

