# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'pn.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import sys
import openpyxl
from collections import defaultdict
import xml.dom.minidom
import xml.etree.ElementTree as ET
from lxml import etree
import re
import os.path

DID_Geely = defaultdict(list)
class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(801, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.buttonBox = QtWidgets.QDialogButtonBox(self.centralwidget)
        self.buttonBox.setGeometry(QtCore.QRect(20, 160, 156, 23))
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.excle_file_l = QtWidgets.QLineEdit(self.centralwidget)
        self.excle_file_l.setGeometry(QtCore.QRect(100, 20, 251, 31))
        self.excle_file_l.setObjectName("excle_file_l")
        self.excel_file = QtWidgets.QPushButton(self.centralwidget)
        self.excel_file.setGeometry(QtCore.QRect(10, 20, 81, 31))
        self.excel_file.setObjectName("excel_file")
        self.xml_file = QtWidgets.QPushButton(self.centralwidget)
        self.xml_file.setGeometry(QtCore.QRect(10, 60, 81, 31))
        self.xml_file.setObjectName("xml_file")
        self.xm_file_l = QtWidgets.QLineEdit(self.centralwidget)
        self.xm_file_l.setGeometry(QtCore.QRect(100, 60, 251, 31))
        self.xm_file_l.setObjectName("xm_file_l")
        self.Sheet_Name = QtWidgets.QLineEdit(self.centralwidget)
        self.Sheet_Name.setGeometry(QtCore.QRect(440, 20, 113, 31))
        self.Sheet_Name.setObjectName("Sheet_Name")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(360, 30, 71, 16))
        self.label.setObjectName("label")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 801, 21))
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(360, 70, 47, 13))
        self.label_2.setObjectName("label_2")
        self.Status = QtWidgets.QLineEdit(self.centralwidget)
        self.Status.setGeometry(QtCore.QRect(442, 69, 111, 21))
        self.Status.setObjectName("Status")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 801, 21))

        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.excel_file.clicked.connect(self.openfile_excel_file)
        self.xml_file.clicked.connect(self.openfile_xml_file)
        self.buttonBox.accepted.connect(self.get_pn)
        self.buttonBox.rejected.connect(self.close_window)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Generate_XML_PN"))
        self.excel_file.setText(_translate("MainWindow", "excel_file"))
        self.xml_file.setText(_translate("MainWindow", "xml_file"))
        self.label.setText(_translate("MainWindow", "Sheet_Name:"))
        self.label_2.setText(_translate("MainWindow", "Status"))


    def close_window(self):
        sys.exit()

    def openfile_excel_file(self):
        filelist = QtWidgets.QFileDialog.getOpenFileName(None, 'select file', '', 'Excel files(*.xlsx , *.xls)')
        OPEN_FILE_NAME = filelist[0]
        if OPEN_FILE_NAME is not None:
            self.excle_file_l.setText(OPEN_FILE_NAME)
        self.Status.setText("Running")

    def openfile_xml_file(self):
        filelist = QtWidgets.QFileDialog.getOpenFileName(None, 'select file', '', 'Excel files(*.xml)')
        OPEN_FILE_NAME = filelist[0]
        if OPEN_FILE_NAME is not None:
            self.xm_file_l.setText(OPEN_FILE_NAME)

    def get_pn(self):
        wb = openpyxl.load_workbook(filename=self.excle_file_l.text())
        print(self.Sheet_Name.text())
        ws = wb[str(self.Sheet_Name.text())]
        lens = ws.max_row + 1
        sequence = ["SWLM", "SWCE", "SWL2", "SWP1\(Fuel Table 50L 1\)", "SWP3", "SWP4", "SWP2", "SWP5", "0000000000", \
                    "SWP6", "SWP7", "SWP8", "SXBL2"]
        DID_Geely["F1AE"] = ["0C"]
        DID_Geely["F12E"] = ["0C"]
        for seq in sequence:
            if seq == "0000000000":
                DID_Geely[ws.cell(i, 6).value].append("0000000000000000")
            for i in range(1, lens):
                if re.search(seq, str(ws.cell(i, 2).value)):
                    DID_Geely[ws.cell(i, 6).value].append(str(ws.cell(i, 8).value)
                                                          + "20" + "20" + hex(ord(str(ws.cell(i, 10).value)))[2:])
                    break
        for seq in sequence:
            if seq == "0000000000":
                DID_Geely[ws.cell(i, 7).value].append("00000000000000")
            for i in range(1, lens):
                if re.search(seq, str(ws.cell(i, 2).value)):
                    if str(ws.cell(i, 13).value) == "N/A":
                        DID_Geely[ws.cell(i, 7).value].append(str(ws.cell(i, 11).value) + "20")
                        break
                    else:
                        DID_Geely[ws.cell(i, 7).value].append(str(ws.cell(i, 11).value)
                                                              + "20" + hex(ord(str(ws.cell(i, 13).value)[0]))[2:] +
                                                              hex(ord(str(ws.cell(i, 13).value)[1]))[2:])
                        break

        for i in range(1, lens):
            if re.search("55L|47L|40L|SBL|VCC", str(ws.cell(i, 2).value)):
                pass
            else:
                if re.search("F(\d+)", str(ws.cell(i, 6).value)):
                    if re.search("F1AE", str(ws.cell(i, 6).value)):
                        pass
                    else:
                        DID_Geely[ws.cell(i, 6).value].append(str(ws.cell(i, 8).value) + "20" + "20" +
                                                              hex(ord(str(ws.cell(i, 10).value)))[2:])
        for i in range(1, lens):
            if re.search("55L|47L|40L|SBL|VCC", str(ws.cell(i, 2).value)):
                pass
            else:
                if re.search("F(\d+)", str(ws.cell(i, 7).value)):
                    if re.search("F12E", str(ws.cell(i, 7).value)):
                        pass
                    else:
                        DID_Geely[ws.cell(i, 7).value].append(str(ws.cell(i, 11).value) + "20" +
                                                              hex(ord(str(ws.cell(i, 13).value)[0]))[2:] +
                                                              hex(ord(str(ws.cell(i, 13).value)[1]))[2:])
        print(DID_Geely)
        self.get_xml_pn()

    def get_xml_pn(self):
        ET.register_namespace("", "http://www.vector-informatik.de/CANoe/TestModule/1.27")
        print(self.xm_file_l.text())
        tree = ET.parse(self.xm_file_l.text())
        root = tree.getroot()
        ns = {"vector": "http://www.vector-informatik.de/CANoe/TestModule/1.27"}
        for testgroup_element in root.findall("./vector:testgroup[@title='Read part number DID']", ns):
            for testcase_element in testgroup_element:
                for key in DID_Geely.keys():
                    if key in (testcase_element.attrib["title"]):
                        old_pn_value = ("").join(DID_Geely[key])
                        new_pn_value = ""
                        for i in range(0, len(old_pn_value) - 1, 2):
                            new_pn_value += old_pn_value[i] + old_pn_value[i + 1] + " "
                        DID_Geely[key] = new_pn_value  # change the value with space between 2 chars.
                        # print(DID_Geely)
                        pn_elements = testcase_element.findall(".//vector:diagparam[@format='bytesequence']",
                                                               ns)  # .//vector 多重namespace
                        for pn_element in pn_elements:
                            if pn_element is not None:
                                if len(pn_element.text) > 10:
                                    if re.match("[A-Z]+", pn_element.text):
                                        pn_element.text = pn_element.text[0:6] + DID_Geely[key].strip()

                                    else:
                                        pn_element.text = DID_Geely[key].strip()

        basename = os.path.dirname(self.xm_file_l.text())
        new_name = basename+"/"+"test.xml"
        print(new_name)

        tree.write(new_name, encoding='UTF-8')

        self.Status.setText("Done")

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

