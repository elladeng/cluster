import sys
import os.path
import re
import time
import logging
try:
    from xmlrpclib import ServerProxy
except ImportError:
    from xmlrpc.client import ServerProxy
LIB_DIR = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
print(LIB_DIR)
sys.path.insert(0, os.path.abspath(os.path.dirname(LIB_DIR)))


print(11111111)
print(sys.path)
logger = logging.getLogger(__name__)
from testlink_dbc import TestlinkSQL
from testlink_api import *
import cv2
from socket_client_mte import MTEClient


Failure_cases = list()

class ExecutionCases(object):
    def __init__(self,api_key, testlink_url, project_name, plan_name, build,mte_add,testlink_ip):
        self.api_key = api_key
        self.testlink_url = testlink_url
        self.project_name = project_name
        self.plan_name = plan_name
        self.build = build
        self.mte_ip = mte_add
        self.testlink_ip = testlink_ip
        self.tlclient = TestLinkClient(self.testlink_url, self.api_key)
        self.notes = "Executed by %s in %s" % (os.getenv('USERNAME'), os.getenv('COMPUTERNAME'))
        self.mte_client = MTEClient(self.mte_ip,8888)
        self.dbc = TestlinkSQL(self.testlink_ip, "root", "", "testlink")

    def format_step_mte(self,steps):
        """
          :param steps:[['TG1:TT_Left', '', '26264', '#'],
                            ['TC0:Preconditon', '', '26265', '#'],
                            ['1._AdditionalOutputs::CEM::IndcrDisp1WdSts_UpdateBitControl=1<br />\n2._AdditionalOutputs::All_TT_OFF=1<br />\n3.WAIT=500', 'N', '26266', '#'],
                            ['TC1:TT_Left  ON_OFF_Active Mode', '', '26267', '#'],
        return:
        TG1:TT_Left||26264|
        #TC0:Preconditon||26265|
        #1._AdditionalOutputs::CEM::IndcrDisp1WdSts_UpdateBitControl=1
         2._AdditionalOutputs::All_TT_OFF=1
         3.WAIT=500|N|26266|
         #TC1:TT_Left  ON_OFF_Active Mode||26267|
        """
        case_data = ""
        for item in steps:
            case_data += "|".join(item)
        s = re.sub(r"<br />", "", case_data)
        s = re.sub(r"<p>", "", s)
        s = re.sub(r"</p>", "", s)
        return s[0:-1]

    def format_result_mte(self,steps):
        """

        :param steps: ||26264#||26265#N||26266#||26267#N||26268#Failed|0;Link|26269#Passed|0|26270<EOF>
        :return: {'step_number': 1, 'result': 'm', 'notes': '', 'id': '26264', 'pic': ''},
         {},
         {'step_number': 3, 'result': 'n', 'notes': '', 'id': '26266', 'pic': ''},
         {}, {'step_number': 5, 'result': 'n', 'notes': '', 'id': '26268', 'pic': ''},
          {'step_number': 6, 'result': 'f', 'notes': '0;Link', 'id': '26269', 'pic': ''},
          {'step_number': 7, 'result': 'p', 'notes': '0', 'id': '26270', 'pic': ''}]
        """
        data = steps[0:-5]
        new = re.sub("\|", ",", data)
        result = new.split("#")
        datas = []
        for resp in result:
            datas.append(resp.split(","))
        case_step_lens = len(datas)
        result_step = list()
        for i in range(0, case_step_lens):
            case_step_result = dict()
            resp = datas[i]
            for content in resp:
                if resp[0] == "":
                    break
                else:
                    case_step_result["step_number"] = i + 1
                    case_step_result['result'] = resp[0][0].lower()
                    case_step_result["notes"] = resp[1]
                    case_step_result["id"] = resp[2]
                    try:
                        case_step_result["pic"] = resp[3]
                    except IndexError:
                        case_step_result["pcc"]=""
            result_step.extend([case_step_result])
        return result_step

    def execute_case_steps_mte(self, datas):
        self.mte_client.send(datas)

    def receive_result_mte(self):
        resp = self.mte_client.recv_until()
        return resp

    def run_build_cases_steps(self):
        """
        Call TestLink API: getTestCase({'devKey': '647072b1d35cdf643086b28ed593b648',
         'testcaseid': '26262'}),
          Response: [{'updater_login': 'admin', 'author_login': 'admin', 'name': 'TT_Direction_Left', 'node_order': '0', 'testsuite_id': '26261', 'testcase_id': '26262', 'id': '26263', 'tc_external_id': '74', 'version': '1', 'layout': '1', 'status': '1', 'summary': 'TM1:TT_Direction_Left(SRD:107938_[App] - DCY11 _ 4.9.3 Direction indication)--Automatic create', 'preconditions': '', 'importance': '2', 'author_id': '1', 'creation_ts': '2019-08-26 15:42:43', 'updater_id': '1', 'modification_ts': '2019-08-26 15:44:55', 'active': '1', 'is_open': '1', 'execution_type': '1', 'estimated_exec_duration': '', 'author_first_name': 'Testlink', 'author_last_name': 'Administrator', 'updater_first_name': 'Testlink', 'updater_last_name': 'Administrator',
           'steps': [{'id': '26264', 'step_number': '1', 'actions': 'TG1:TT_Left', 'expected_results': '', 'active': '1', 'execution_type': '1'},
                     {'id': '26265', 'step_number': '2', 'actions': 'TC0:Preconditon', 'expected_results': '', 'active': '1', 'execution_type': '1'},
                     {'id': '26266', 'step_number': '3', 'actions': '1._AdditionalOutputs::CEM::IndcrDisp1WdSts_UpdateBitControl=1<br />\n2._AdditionalOutputs::All_TT_OFF=1<br />\n3.WAIT=500', 'expected_results': 'N', 'active': '1', 'execution_type': '1'},
                     {'id': '26267', 'step_number': '4', 'actions': 'TC1:TT_Left  ON_OFF_Active Mode', 'expected_results': '', 'active': '1', 'execution_type': '1'},
                     {'id': '26268', 'step_number': '5', 'actions': '1._AdditionalOutputs::CEM::UsgModSts=11<br />\n2. WAIT=3000', 'expected_results': 'N', 'active': '1', 'execution_type': '1'}, {'id': '26269', 'step_number': '6', 'actions': '1._AdditionalOutputs::CEM::IndcrDisp1WdSts=1<br />\n2.WAIT=1000', 'expected_results': 'TT_Left_ON=90', 'active': '1', 'execution_type': '1'}, {'id': '26270', 'step_number': '7', 'actions': '1._AdditionalOutputs::CEM::IndcrDisp1WdSts=0<br />\n2.WAIT=1000', 'expected_results': 'TT_Left_ON=0', 'active': '1', 'execution_type': '1'}], 'full_tc_external_id': '006-74'}]


        feedback result are " [{'step_number': 6, 'notes': '[65]', 'result': 'f', 'pic': 'E:\\0000_Cluster\\cases\\testlink\\1568078850.5303428.jpeg', 'id': '26287'},
                               {'step_number': 7, 'notes': '0', 'result': 'p', 'id': '26288'},
                               {'step_number': 9, 'notes': '[70]', 'result': 'f', 'pic': 'E:\\0000_Cluster\\cases\\testlink\\1568078855.9702942.jpeg', 'id': '26290'}]

        """

        objProject = self.tlclient.getTestProjectByName(self.project_name)
        objTestPlan = objProject.getTestPlanByName(self.plan_name)
        build = objTestPlan.getBuildByName(self.build)
        cases = objTestPlan.getTestCases()
        for case in cases:
            case_status = ""
            case_steps = case.getSteps()
            current_case_steps = []
            for step in case_steps:
                current_case_steps.append([step["actions"],step['expected_results'],step["id"],"#"]) # vector_steps,first value: case_steps,second:expected result, last:step_id
            logger.info("Current cases steps are %s", current_case_steps)
            case_mte_datas = self.format_step_mte(current_case_steps)
            logger.info("Current mte cases steps are %s", case_mte_datas)
            self.execute_case_steps_mte(case_mte_datas)
            resp = self.receive_result_mte()
            steps_result = self.format_result_mte(resp)
            for step_result in steps_result:
                if "f" in step_result.values():
                    case_status = "f"
                    break
                else:
                    case_status = "p"
            case_result_params = {"devKey":self.api_key,
                                  "testcaseid":case.getId(),
                                  "testplanid":objTestPlan.getId(),\
                                   "status": case_status,
                                  "buildid" :build.getId(),
                                  "notes":self.notes,
                                  "overwrite":False,
                                 "steps":[]
                                  } # overwrite = True ,will not update the datas to testlink databases first time .\
                                    # only update to database on second time.
            case_result_params["steps"].extend(steps_result)
            resp = self.tlclient.server.tl.reportTCResult(case_result_params)
            logger.debug("Call TestLink API: reportTCResult(%s), Response: %s", case_result_params, resp)
            # below for update picture
            execution_id = resp[0]['id']
            logger.info("case execution id is %s",execution_id)
            time.sleep(10)
            for step_result in steps_result:
                if "f" in step_result.values():
                    resp = "SELECT id FROM execution_tcsteps WHERE execution_id='%s' and tcstep_id='%s'" % (
                    execution_id, step_result['id'])
                    logger.info("sql program is %s",resp)
                    self.dbc.cursor.execute(resp)
                    id = self.dbc.cursor.fetchone()[0]  # get the sql program result through cursor.fetchone()[0]
                    logger.info("Current execution id  is %s" % (id))
                    if step_result['pic']:
                        pic = cv2.imread(step_result['pic'])
                        res = cv2.resize(pic, (640, 480))
                        cv2.imwrite(step_result['pic'], res)
                        pic_addr = re.sub("\\\\", "/", step_result['pic'])
                        self.tlclient.uploadAttachment(int(id), os.path.basename(step_result['pic']), pic_addr)

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s'
    )

    # api_key = "647072b1d35cdf643086b28ed593b648"
    # url = "http://localhost/testlink/lib/api/xmlrpc/v1/xmlrpc.php"

    url = "http://136.17.78.90:8089/testlink/lib/api/xmlrpc/v1/xmlrpc.php"
    api_key = "879ea395c5e347802c70d327d8bcd79d"
    # project_name = "DCY11"
    # build = "V1.0"
    # plan_name = "Smoke"
    # mte_addr = "136.17.77.28"
    # testlink_ip = "136.17.78.90"
    # action = ExecutionCases(api_key,url,project_name,plan_name,build, mte_addr,testlink_ip)
    # action.run_build_cases_steps()

    import argparse
    parser = argparse.ArgumentParser(description="Update build ID cases result to testlink")
    parser.add_argument('--project', help="please input the project name",type=str)
    parser.add_argument('--build', help="please input the build version",type=str)
    parser.add_argument('--plan',help="please input the plan name",type=str)
    parser.add_argument("--mte",help="please input the mte server ip",type=str)
    parser.add_argument("--ip",help="please input the testlink dbc ip",type=str)
    args = parser.parse_args()
    action = ExecutionCases(api_key, url, args.project, args.plan, args.build, args.mte, args.ip)
    action.run_build_cases_steps()





