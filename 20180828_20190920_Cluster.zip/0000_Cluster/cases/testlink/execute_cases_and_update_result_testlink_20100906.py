import sys
import os.path
import re
import time
import logging
import subprocess
from cases.testlink.testlink_dbc import TestlinkSQL
from win32com.client.connect import *
from cases.testlink import *
from equipment.ea_ps_2042 import PSUEA
try:
    from xmlrpclib import ServerProxy
except ImportError:
    from xmlrpc.client import ServerProxy


LIB_DIR = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, os.path.abspath(os.path.dirname(LIB_DIR)))
logger = logging.getLogger(__name__)

Failure_cases = list()


class CANoe:
    def __init__(self,name="CANoe.Application"):
        self.application = None
        output = subprocess.check_output('tasklist', shell=True)
        if "CANoe32.exe" or "CANw64.exe" in str(output):
            os.system("taskkill /im CANoe32.exe /f 2>nul >nul")
        # re-dispatch object for CANoe Application
        self.application = win32com.client.DispatchEx(name)
        self.ver = self.application.Version
        print('Loaded CANoe version ',
            self.ver.major, '.',
            self.ver.minor, '.',
            self.ver.Build, '...')#, sep,''
        self.Measurement = self.application.Measurement.Running
        print(self.Measurement)

    def open_simulation(self, cfgname):
        # open CANoe simulation
        if (self.application != None):
            # check for valid file and it is *.cfg file
            if os.path.isfile(cfgname) and (os.path.splitext(cfgname)[1] == ".cfg"):
                self.application.Open(cfgname)
            else:
                raise RuntimeError("Can't find CANoe cfg file")
        else:
            raise RuntimeError("CANoe Application is missing,unable to open simulation")

    def close_simulation(self):
        # close CANoe simulation
        if (self.application != None):
            self.stop_Measurement()
            self.application.Quit()

        # make sure the CANoe is close properly, otherwise enforce taskkill
        output = subprocess.check_output('tasklist', shell=True)

        if "CANoe32.exe" in str(output):
            os.system("taskkill /im CANoe32.exe /f 2>nul >nul")

        if "CANw64.exe" in str(output):
            os.system("taskkill /im CANw64.exe /f 2>nul >nul")

        self.application = None

    def start_Measurement(self):
        retry = 0
        retry_counter = 15
        # try to establish measurement within 20s timeout
        while not self.application.Measurement.Running and (retry < retry_counter):
            self.application.Measurement.Start()
            time.sleep(1)
            retry += 1
        if (retry == retry_counter):
            raise RuntimeWarning("CANoe start measuremet failed, Please Check Connection!")

    def stop_Measurement(self):
        if self.application.Measurement.Running:
            self.application.Measurement.Stop()
        else:
            pass

    def get_EnvVar(self, var):

        if (self.application != None):
            result = self.application.Environment.GetVariable(var)
            return result.Value
        else:
            raise RuntimeError("CANoe is not open,unable to GetVariable")

    def set_EnvVar(self, var, value):
        result = None

        if (self.application != None):
            # set the environment varible
            result = self.application.Environment.GetVariable(var)
            result.Value = value

            checker = self.get_EnvVar(var)
            # check the environment varible is set properly?
            while (checker != value):
                checker = self.get_EnvVar(var)
        else:
            raise RuntimeError("CANoe is not open,unable to SetVariable")

    def get_SigVal(self, channel_num, msg_name, sig_name, bus_type="CAN"):
        """
        @summary Get the value of a raw CAN signal on the CAN simulation bus
        @param channel_num - Integer value to indicate from which channel we will read the signal, usually start from 1,
                             Check with CANoe can channel setup.
        @param msg_name - String value that indicate the message name to which the signal belong. Check DBC setup.
        @param sig_name - String value of the signal to be read
        @param bus_type - String value of the bus type - e.g. "CAN", "LIN" and etc.
        @return The CAN signal value in floating point value.
                Even if the signal is of integer type, we will still return by
                floating point value.
        @exception None
        """
        if (self.application != None):
            result = self.application.GetBus(bus_type).GetSignal(channel_num, msg_name, sig_name)
            return result.Value
        else:
            raise RuntimeError("CANoe is not open,unable to GetVariable")

    def call_capl_diag_function(self,function,da09):
        self.func = self.application.CAPL.GetFunction(function)
        return self.func.Call(*da09)


    def get_SysVar(self, ns_name, sysvar_name):

        if (self.application != None):
            systemCAN = self.application.System.Namespaces
            sys_namespace = systemCAN(ns_name)
            sys_value = sys_namespace.Variables(sysvar_name)
            return sys_value.Value
        else:
            raise RuntimeError("CANoe is not open,unable to GetVariable")

    def set_SysVar(self, ns_name, sysvar_name, var):

        if (self.application != None):
            systemCAN = self.application.System.Namespaces
            sys_namespace = systemCAN(ns_name)
            sys_value = sys_namespace.Variables(sysvar_name)
            sys_value.Value = var
        else:
            raise RuntimeError("CANoe is not open,unable to GetVariable")

    def get_all_SysVar(self, ns_name):

        if (self.application != None):
            sysvars=[]
            systemCAN = self.application.System.Namespaces
            sys_namespace = systemCAN(ns_name)
            sys_value = sys_namespace.Variables
            for sys in sys_value:
                sysvars.append(sys.Name)
                sysvars.append(sys.Value)
            return sysvars
        else:
            raise RuntimeError("CANoe is not open,unable to GetVariable")


class ExecutionCases(object):
    def __init__(self,api_key, testlink_url, project_name, plan_name, build, vector_cfg, vector_tool="CANalyzer.Application"):
        self.api_key = api_key
        self.testlink_url = testlink_url
        self.project_name = project_name
        self.plan_name = plan_name
        self.build = build
        self.vector_cfg = vector_cfg
        self.vector_tool = vector_tool
        self.app = CANoe(name="CANalyzer.Application")
        self.app.open_simulation(cfgname=self.vector_cfg)
        self.app.start_Measurement()  # start vector tool
        time.sleep(30)
        self.tlclient = TestLinkClient(self.testlink_url, self.api_key)
        self.notes = "Executed by %s in %s" % (os.getenv('USERNAME'), os.getenv('COMPUTERNAME'))
        self.ps = PSUEA("COM9")
        self.dbc = TestlinkSQL("localhost", "root", "", "testlink")

    def run_build_cases_steps(self):
        """
        steps=['TC2:WiprSysFailrDetdSafe_UB missing _Drv', '']
              ['1.FDiag=40 03 00 03 19 02 0F', 'Fdiag:Diag_Response=0E 80 18 01 40 07 00 07 59 02 FF 91 31 87']
        explain: steps[0:-1]:execute steps ,steps[-1]: expected result


        params = {"devKey": api_key,"testcaseid": case.getId(),"testplanid": testplan.getId(),"status": "", "buildid": build_id,"notes": "", "overwrite": True,
                  "steps": [{'step_number':1, 'result':'p', 'notes':"ella"},
                            {'step_number': 2, 'result': 'p', 'notes': "ella"}]

        """
        objProject = self.tlclient.getTestProjectByName(self.project_name)
        objTestPlan = objProject.getTestPlanByName(self.plan_name)
        build = objTestPlan.getBuildByName(self.build)
        cases = objTestPlan.getTestCases()
        for case in cases:
            case_status = ""
            case_steps = case.getSteps()
            current_case_steps = []
            for step in case_steps:
                vector_steps = []
                if re.search("\n",step["actions"]):
                    step_action = step['actions'].split("\n")[0:-1]
                    for item in step_action:
                        s = re.sub(r"<br />", "", item)
                        s = re.sub(r"<p>", "", s)
                        s = re.sub(r"</p>", "", s)
                        vector_steps.append(s)
                else:
                    step_action = step["actions"]
                    vector_steps.append(step_action)
                resp = step['expected_results']
                logger.info("Ella step expected reuslt is %s",resp)
                s = re.sub(r"<br />", "", resp)
                s = re.sub(r"<p>", "", s)
                s = re.sub(r"</p>", "", s)
                vector_steps.append(s)
                vector_steps.append(step["id"]) # vector_steps,first value: case_steps,second:expected result, last:step_id
                current_case_steps.append(vector_steps)
            logger.info("Current cases steps are %s", current_case_steps)
            steps_result = self.execute_case_steps(current_case_steps)
            logger.info("Current cases results are %s",steps_result)
            for step_result in steps_result:
                if "f" in step_result.values():
                    case_status = "f"
                    break
                else:
                    case_status = "p"
            case_result_params = {"devKey":self.api_key,
                                  "testcaseid":case.getId(),
                                  "testplanid":objTestPlan.getId(),\
                                   "status": case_status,
                                  "buildid" :build.getId(),
                                  "notes":self.notes,
                                  "overwrite":False,
                                 "steps":[]
                                  } # overwrite = True ,will not update the datas to testlink databases first time .\
                                    # only update to database on second time.
            failed_step_id =[]
            for step_result in steps_result:
                if "f" in step_result.values():
                    failed_step_id.append([step_result['id'],step_result['pic']])
                    # step_result.pop("pic")
                # step_result.pop("id")

            case_result_params["steps"].extend(steps_result)
            resp = self.tlclient.server.tl.reportTCResult(case_result_params)
            logger.debug("Call TestLink API: reportTCResult(%s), Response: %s", case_result_params, resp)
            execution_id = resp[0]['id']
            logger.info("case execution id is %s",execution_id)

            # Failure_cases.append({"id":execution_id,"steps":failed_step_id})
            for step_result in steps_result:
                logging.info("Ella111111111111111 step result is %s",step_result)
                logging.info("Ella1222222222222222222 execution id is %s",execution_id)
                if "f" in step_result.values():
                    resp = "SELECT id FROM execution_tcsteps WHERE execution_id='%s' and tcstep_id='%s'" % (execution_id, step_result['id'])
                    print(resp)
                    self.dbc.cursor.execute(resp)
                    print(self.dbc)
                    self.id = self.dbc.cursor.fetchone()[0]  # get the sql program result through cursor.fetchone()[0]
                    logger.info("Current execution id  is %s" % (self.id))
                    pic_addr = re.sub("\\\\", "/", step_result['pic'])
                    self.tlclient.uploadAttachment(int(self.id), os.path.basename(step_result['pic']), pic_addr)


    def execute_case_steps(self,steps):
        total_steps = len(steps)
        steps_result = []
        for i in range(0, total_steps):
            step_result = dict()
            step_result["step_number"] = int(i) + 1
            step_result["notes"] = self.notes
            for j in range(0, len(steps[i]) - 1):
                item = steps[i][j]
                if re.search("TG|TC\d+", item):
                    pass
                else:
                    if re.search("WAIT", item):
                        time_gap = item.partition("=")[2]
                        time.sleep((int(time_gap) / 1000))
                    elif re.search("::", item):
                        value = item.partition("=")[2]
                        namespace = item.rpartition("=")[0].rpartition("::")[0].partition(".")[2]
                        key = item.rpartition("=")[0].rpartition("::")[2]
                        print(namespace, key, value)
                        self.call_vector(namespace, key, value)
                    # elif re.search("FDiag", item):
                    #     value = item.partition("=")[2]
                    elif re.search("VOLT",item):
                        value = item.partiton("=")[2]
                        self.ps.set_voltate(value)
                    elif re.search("MA",item):
                        pass
            expected_result = steps[i][-2]

            logger.info("expected result is %s",expected_result)
            if expected_result == ""or expected_result == "N" :
                step_result["result"] = "p"
            else:
                if re.search("=\d{1,2}", expected_result):
                    web = OpenCVWebCam(0)
                    result,pic= web.match_folder_pictures(os.path.join(golden_picture_folder,expected_result.partition("=")[0]))
                    logger.info("Ella result is %s",result)
                    if(int(expected_result.partition("=")[2])) == 0:
                        if min(result) <80:
                            step_result["result"] = "p"
                            step_result["notes"] = str(0)
                            # os.remove(pic)
                    else:
                        if min(result) < int(expected_result.partition("=")[2]):
                            step_result["result"] = "f"
                            step_result["notes"] = str(result)
                            step_result["pic"] = pic
                        else:
                            step_result["result"] = "p"
                            step_result["notes"] = str(result)
                            # os.remove(pic)
                step_result["id"] = steps[i][-1]
                steps_result.append(step_result)
        print(steps_result)
        return steps_result

    def call_vector(self,namespace,key, value):
        self.app.set_SysVar(namespace, key, int(value))


class UpdateAttachment(object):
    def __init__(self,api_key, testlink_url):
        self.api_key = api_key
        self.testlink_url = testlink_url
        self.tlclient = TestLinkClient(self.testlink_url, self.api_key)
        self.notes = "Executed by %s in %s" % (os.getenv('USERNAME'), os.getenv('COMPUTERNAME'))
        self.dbc = TestlinkSQL("localhost", "root", "", "testlink")
        # self.dbc = TestlinkSQL("136.17.78.218", "root", "", "testlink")

    def update_execution_steps_pic(self):
        for fail_case in Failure_cases:
            execution_id = fail_case["id"]
            for step_id in fail_case["steps"]:
                resp = "SELECT id FROM execution_tcsteps WHERE execution_id='%s' and tcstep_id='%s'" % (execution_id,step_id[0])
                print(resp)
                self.dbc.cursor.execute(resp)
                print(self.dbc)
                self.id  = self.dbc.cursor.fetchone()[0]  # get the sql program result through cursor.fetchone()[0]
                logger.info("Current execution id  is %s" % (self.id))
                pic_addr = re.sub("\\\\","/",step_id[1])
                self.tlclient.uploadAttachment(int(self.id),os.path.basename(step_id[1]),pic_addr)
        self.dbc.close()


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s'
    )
    vector_cfg = r"E:\000_CSharp_Project\01_Project\new_for_automation_0813\dcy11_auto_08013.cfg"
    vector_tool = "CANalyzer.Application"
    golden_picture_folder = r"E:\000_CSharp_Project\dcy11_temp"

    api_key = "647072b1d35cdf643086b28ed593b648"
    url = "http://localhost/testlink/lib/api/xmlrpc/v1/xmlrpc.php"
    project_name = "PMA"
    build = "V5.7.6"
    plan_name = "DCY11_TT_NT"

    # url = "http://136.17.78.218:8089/testlink/lib/api/xmlrpc/v1/xmlrpc.php"
    # api_key = "879ea395c5e347802c70d327d8bcd79d"
    # project_name = "FPKG"
    # build = "V3.0"
    # plan_name = "Smoke"

    # Failure_cases=[{'id': 59, 'steps': [['26287', 'E:\\0000_Cluster\\cases\\testlink\\1567490831.4637423.jpeg']]}]
    try:
        action = ExecutionCases(api_key,url,project_name,plan_name,build, vector_cfg, vector_tool)
        action.run_build_cases_steps()
        # upload = UpdateAttachment(api_key,url)
        # upload.update_execution_steps_pic()
    finally:
        action.ps.disconnect()
        action.app.close_simulation()

    # import argparse
    # parser = argparse.ArgumentParser(description="Update build ID cases result to testlink")
    # parser.add_argument('--project', help="please input the project name",type=str)
    # parser.add_argument('--build', help="please input the build version",type=str)
    # parser.add_argument('--plan',help="please input the plan name",type=str)
    # parser.add_argument("--cfg",help="please input the vector cfg file",type=str)
    # parser.add_argument("--tool",help="please input the CANalyzer.Applicaton or CANoe.Application",type=str)
    # args = parser.parse_args()
    # action = ExecutionCases(api_key, url, args.project, args.plan, args.build, args.cfg, args.tool)
    # action.run_build_cases_steps()
    #


