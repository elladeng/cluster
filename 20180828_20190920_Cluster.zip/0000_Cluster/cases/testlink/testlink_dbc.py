import pymysql
import logging

logger = logging.getLogger(__name__)


class TestlinkSQL(object):
    def __init__(self, host, user, password, database):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.conn = None
        self.cursor = None
        self.conn = pymysql.connect(self.host, self.user, self.password, self.database)
        self.cursor = self.conn.cursor()
        self.plan_id = ""
        self.build_id = ""
        self.project_id = ""
        self.suites = []
        self.cases_version=[]
        self.totals = [] #first:project id ,second:suite_id, third:case_id,fourth:case_version_id,fifth:case_step_id,sixth:_detail_steps
        self.full_cases = dict()

    def connect(self):
        self.conn = pymysql.connect(self.host, self.user, self.password, self.database)
        self.cursor = self.conn.cursor()

    def close(self):
        self.cursor.close()
        self.conn.commit()
        self.conn.close()

    def get_testplan_index(self,testplan_api):
        resp = "SELECT id FROM testplans WHERE api_key='%s'"%testplan_api
        self.cursor.execute(resp)
        self.plan_id=self.cursor.fetchall()[0]# get the sql program result through cursor.fetchone()[0]
        logger.info("Current plan id is %s"%(self.plan_id)) # Current project id is 4


    def get_testbuild_index(self,build):
        resp = "SELECT id FROM builds WHERE testplan_id='%s' and name='%s'" %(self.plan_id,build)
        self.cursor.execute(resp)
        self.build_id = self.cursor.fetchone()[0]  # get the sql program result through cursor.fetchone()[0]
        logger.info("Current build id is %s" % (self.build_id)) # build id is 14

    def get_testproject_index(self,project_name):
        resp = "SELECT id FROM  nodes_hierarchy WHERE name='%s'" % project_name
        self.cursor.execute(resp)
        self.project_id = self.cursor.fetchone()[0]
        logger.info("Current project id is %s",self.project_id)


    def get_suite_id(self):
        """reps :((26260, 'NT', 25356, 2, 1), (26273, 'Clock_Door_EngineCoolant', 25356, 2, 2))
           resp[0]:"nodes_hierarchy id ,name,parent_id",node_type_id(2 :testsuite id,5: testplan id,6:requirement),node_order)
         """
        resp = "SELECT * FROM nodes_hierarchy WHERE parent_id='%s' and node_type_id=2"%self.project_id
        self.cursor.execute(resp)
        suite_tier_1 = self.cursor.fetchall()
        logger.info("suite tier 1 has %s and values is %s"%(len(suite_tier_1),suite_tier_1)) #((25352, 'TM1_AM', 4, 2, 1), (26278, 'NT', 4, 2, 2))
        self.suites.extend(suite_tier_1)
        for i in range(0,len(self.suites)):
            self.full_cases["suite_%s"%i]=[self.suites[i][0]]
        logger.info("Ella Test  suite are %s",self.full_cases)
        resp2 = "SELECT * FROM nodes_hierarchy WHERE node_type_id=2 and parent_id in \
                (SELECT id FROM nodes_hierarchy WHERE node_type_id=2 and parent_id='%s')"%self.project_id
        self.cursor.execute(resp2)
        suite_tier_2 = self.cursor.fetchall()
        logger.info("suite tier 2 has %s and values is %s" % (len(suite_tier_2), suite_tier_2)) #((26279, 'Direction', 26278, 2, 0),)
        self.suites.extend(suite_tier_2)
        return self.suites

    def get_cases_id_and_version(self):
        cases = list()
        for suite in self.suites:
            suite_parent_id = suite[0]
            resp = "SELECT * FROM nodes_hierarchy WHERE node_type_id=3 and parent_id='%s'" %suite_parent_id
            self.cursor.execute(resp)
            case = self.cursor.fetchall()
            if case:
                cases.extend(case)
        logger.info("CASE are %s",cases)
        self.cases_version = []
        for case in cases:
            case_parent_id = case[0]
            resp = "SELECT * FROM nodes_hierarchy WHERE node_type_id=4 and parent_id='%s'" % case_parent_id
            self.cursor.execute(resp)
            case_version = self.cursor.fetchall()
            self.cases_version.extend(case_version)
        logger.info("case versions are %s",self.cases_version) #((26263, '', 26262, 4, 0),) cases_version, name,case_id, node_typ_id, node_order
        return self.cases_version

    def get_case_steps(self):
        cases_detail = []
        detail = {"case_step_id":"","case_name":"","case_id":""}
        steps_id = []
        for case_version in self.cases_version:
            case_version_id = case_version[0]
            resp = "SELECT * FROM nodes_hierarchy WHERE node_type_id=9 and parent_id='%s'" % case_version_id
            self.cursor.execute(resp)
            case_steps = self.cursor.fetchall()
            steps_id.extend(case_steps)
            logger.info("CASE steps are %s",case_steps)
        for case_step in steps_id:
            resp = "SELECT * FROM  tcsteps WHERE id='%s'"% case_step[0]
            self.cursor.execute(resp)
            case_detail_steps = self.cursor.fetchall()
            logger.info("CASE detail steps are %s",case_detail_steps)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s'
    )
    dbc = TestlinkSQL("localhost","root","","testlink")
    # testplan_api = '4ecd011a3c697c98a197ceb9ad7076941fa00783204a6917d4c2725ee59f217c'
    build = "V5.7.5"
    plan_name = "DCY11_TT_NT"
    dbc.get_testproject_index("PMA")
    # dbc.get_testplan_index(testplan_api)
    # dbc.get_testbuild_index(build)
    dbc.get_suite_id()
    dbc.get_cases_id_and_version()
    dbc.get_case_steps()

    # dbc = TestlinkSQL("136.17.78.218","root","","testlink")
