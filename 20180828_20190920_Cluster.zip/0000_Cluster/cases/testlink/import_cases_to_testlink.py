"""
This import cases  format is just for MTE 's format
"""
import re
import openpyxl
import logging
from cases.testlink import testlink_api
logger = logging.getLogger(__name__)

class UpLoadCases(object):
    def __init__(self,file,api_key, testlink_url, project_name,suite_name):
        self.file = file
        self.api_key = api_key
        self.testlink_url = testlink_url
        self.project_name = project_name
        self.suite_name = suite_name

    def get_sheet_cases_format(self,sheet_name):
        """
        [
        {'name': 'TT_Direction_Left', 'summary': '',
        steps':
        [{'step_number': 1, 'actions': 'TG1:TT_Left', 'expected_results': '', 'execution_type': 0},
        {'step_number': 2, 'actions': 'TC1:TT_Left  ON_OFF_Active Mode', 'expected_results': '', 'execution_type': 0},
        {'step_number': 3, 'actions': '1._AdditionalOutputs::CEM::UsgModSts=11<br />\n2. WAIT=3000', 'expected_results': 'N', 'execution_type': 0},
        {'step_number': 4, 'actions': '1._AdditionalOutputs::CEM::IndcrDisp1WdSts=1<br />\n2.WAIT=1000', 'expected_results': 'TT_Left_ON=90', 'execution_type': 0}
        ]},

        {'name': 'TT_Direction_Right', 'summary': '', 'steps': [{'step_number': 1, 'actions': 'TG7:Voltage', 'expected_results': '', 'execution_type': 0},
         {'step_number': 2, 'actions': 'TC1:TT_Right  ON_OFF_Drive Mode_with High Voltage', 'expected_results': '', 'execution_type': 0},
         {'step_number': 3, 'actions': '1.VOLT=17.8<br />\n2.WAIT=5000<br />\n3.MA=1', 'expected_results': 'ID_OFF3=90', 'execution_type': 0},
         {'step_number': 4, 'actions': '1.VOLT=6.4<br />\n2.WAIT=5000', 'expected_results': 'ID_OFF3=90', 'execution_type': 0}
         }
         ]

        """
        cases = list()
        wb = openpyxl.load_workbook(self.file)
        ws = wb.get_sheet_by_name(sheet_name)
        TM = list()
        rows = ws.max_row + 1
        for i in range(1, rows):
            if isinstance(ws.cell(i, 1).value, str):
                if re.search("TM\d+", ws.cell(i, 1).value):
                    TM.append(i)
        TM.append(rows)
        logger.debug("Current sheet has %s Module", len(TM))
        logger.debug("TM is %s", TM)
        for i in range(0, len(TM) - 1):
            contexts = {"name": "", "summary": "", "steps": []}
            resp = ws.cell(TM[i], 1).value.split(":")[1]
            contexts["summary"] = ws.cell(TM[i], 1).value
            if re.search("\(", resp):
                resp = resp.split("(")[0]
            logger.info("summary is %s", contexts["summary"])
            logger.info("name is %s", resp)
            contexts["name"] = resp

            steps = []
            counter = 0
            for k in range(TM[i] + 1, TM[i + 1]):
                detail_steps = {"step_number": "", "actions": "", "expected_results": "", 'execution_type': 0}
                counter = counter + 1
                detail_steps["step_number"] = counter
                if ws.cell(k, 2).value is not None:
                    new_steps_value = re.sub("\n", "<br />\n", ws.cell(k, 3).value)
                    detail_steps["actions"] = new_steps_value
                    detail_steps["expected_results"] = ws.cell(k, 4).value
                else:
                    detail_steps["actions"] = ws.cell(k, 1).value
                steps.append(detail_steps)
                # print(steps)
            contexts["steps"] = steps
            cases.append(contexts)
        logger.info("Current cases is %s", cases)
        wb.close()
        return cases

    def upload_cases_to_testlink(self):
        wb = openpyxl.load_workbook(self.file)
        sheet_names = wb.get_sheet_names()[1:]
        logger.info(sheet_names)
        wb.close()
        for sheet_name in sheet_names:
            cases = self.get_sheet_cases_format(sheet_name)
            struct = [
                {
                    "name": self.suite_name,
                    "subsuites":  [{"name": sheet_name,  "cases": cases}]
                }
            ]

            tlclient = testlink_api.TestLinkClient(self.testlink_url, self.api_key)
            tlclient.impSuiteAndCases(self.project_name, struct)


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s'
    )
    # file = r"E:\000_CSharp_Project\cases\TT_MET_Direction.xlsx"
    # api_key = "647072b1d35cdf643086b28ed593b648"
    # url = "http://localhost/testlink/lib/api/xmlrpc/v1/xmlrpc.php"
    # project_name = "DCY11"
    # suite_name = "NT"
    # tl_client = UpLoadCases(file, api_key, url, project_name, suite_name)
    # tl_client.upload_cases_to_testlink()


    file = r"E:\000_CSharp_Project\cases\TT_MET_Direction.xlsx"
    api_key = "879ea395c5e347802c70d327d8bcd79d"
    url = "http://136.17.78.90:8089/testlink/lib/api/xmlrpc/v1/xmlrpc.php"
    project_name = "DCY11"
    suite_name = "NT"
    tl_client = UpLoadCases(file, api_key, url, project_name, suite_name)
    tl_client.upload_cases_to_testlink()
