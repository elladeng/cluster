import argparse
def output(str1,str2):
    print(str1)
    print(str2)


if __name__ =="__main__":
    import argparse

    parser = argparse.ArgumentParser(description="please input web num")
    parser.add_argument('--step', help="please input the step",type=str)
    parser.add_argument('--result', help="please input the expected result",type=str)
    args = parser.parse_args()
    output(args.step,args.result)
