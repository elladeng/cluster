import openpyxl
import re
import time
import logging
logger = logging.getLogger(__name__)
from cases.testlink import testlink_api
import CANoe
import time


def execute_case_steps(steps):
    app = CANoe(name="CANalyzer.Application")
    app.open_simulation(cfgname=r"E:\000_CSharp_Project\01_Project\new_for_automation_0813\dcy11_auto_08013.cfg")
    app.start_Measurement()
    vector_steps = steps[0:-1]
    expect_result = steps[-1]
    for step in steps:
        if re.seach("WAIT" in step):
            time_gap = step.partition("=")[1]
            time.sleep(time_gap)

        else:
                value = step.partition("=")[2]
                namespace = step.rpartition("=")[0].rpartition("::")[0].partition(".")[2]
                key = step.rpartition("=")[0].rpartition("::")[2]
                print(namespace, key, value)
                app.set_SysVar(namespace, key, value)
                result = vector_steps[-1]
                if re.search("FDiag", result):
                    return_value = app.get_SysVar("test_uds", "Diag_Response")
                    if result.partition("=")(2) in return_value:
                        return 1
                    else:
                        return 0

def transfer_cases_xml_tetslink(file,sheet_name):
    """
    [
    {'name': 'TT_Direction_Left', 'summary': '',
    steps':
    [{'step_number': 1, 'actions': 'TG1:TT_Left', 'expected_results': '', 'execution_type': 0},
    {'step_number': 2, 'actions': 'TC1:TT_Left  ON_OFF_Active Mode', 'expected_results': '', 'execution_type': 0},
    {'step_number': 3, 'actions': '1._AdditionalOutputs::CEM::UsgModSts=11<br />\n2. WAIT=3000', 'expected_results': 'N', 'execution_type': 0},
    {'step_number': 4, 'actions': '1._AdditionalOutputs::CEM::IndcrDisp1WdSts=1<br />\n2.WAIT=1000', 'expected_results': 'TT_Left_ON=90', 'execution_type': 0}
    ]},

    {'name': 'TT_Direction_Right', 'summary': '', 'steps': [{'step_number': 1, 'actions': 'TG7:Voltage', 'expected_results': '', 'execution_type': 0},
     {'step_number': 2, 'actions': 'TC1:TT_Right  ON_OFF_Drive Mode_with High Voltage', 'expected_results': '', 'execution_type': 0},
     {'step_number': 3, 'actions': '1.VOLT=17.8<br />\n2.WAIT=5000<br />\n3.MA=1', 'expected_results': 'ID_OFF3=90', 'execution_type': 0},
     {'step_number': 4, 'actions': '1.VOLT=6.4<br />\n2.WAIT=5000', 'expected_results': 'ID_OFF3=90', 'execution_type': 0}
     }
     ]

    """
    cases = list()
    wb = openpyxl.load_workbook(file)
    ws = wb.get_sheet_by_name(sheet_name)
    TM = list()
    rows = ws.max_row + 1
    for i in range(1,rows):
        if isinstance(ws.cell(i, 1).value, str):
            if re.search("TM\d+", ws.cell(i, 1).value):
                TM.append(i)
    TM.append(rows)
    logger.debug("Current sheet has %s Module",len(TM))
    logger.debug("TM is %s",TM)
    for i in range(0,len(TM)-1):
        contexts = {"name": "", "summary": "", "steps": []}
        resp = ws.cell(TM[i], 1).value.split(":")[1]
        contexts["summary"] = ws.cell(TM[i], 1).value
        if re.search("\(",resp):
            resp = resp.split("(")[0]
        logger.info("summary is %s",contexts["summary"] )
        logger.info("name is %s", resp)
        contexts["name"] = resp

        steps = [ ]
        counter =0
        for k in range(TM[i]+1,TM[i+1]):
            detail_steps = {"step_number": "", "actions": "", "expected_results": "", 'execution_type': 0}
            counter = counter+1
            detail_steps["step_number"]= counter
            if ws.cell(k,2).value is not None:
                new_steps_value = re.sub("\n", "<br />\n",ws.cell(k,3).value )
                detail_steps["actions"]= new_steps_value
                detail_steps["expected_results"] = ws.cell(k, 4).value
            else:
                detail_steps["actions"]=ws.cell(k,1).value
            steps.append(detail_steps)
            # print(steps)
        contexts["steps"]=steps
        cases.append(contexts)
    logger.info("Current cases is %s",cases)
    wb.close()
    return cases


def update_result_testlink(url,api_key,project_name):
    tlclient = testlink_api.TestLinkClient(url, api_key)
    objProject = tlclient.getTestProjectByName(project_name)
    objTestPlan = objProject.getTestPlanByName("Smoke")
    objtestcase = objTestPlan.getTestCases()
    objTestExecution = objTestPlan.getTestExecutionByBuildName("V5.7.5")
    for case in objtestcase:
        objTestExecution.setCaseExecResult(case,"","p")

    time.sleep(30)
    # for case in objtestcase:
    #     objTestExecution.getCaseExecResult(case)

def get_and_execute_cases(url,api_key,project_name,plan_name,build):
    tlclient = testlink_api.TestLinkClient(url, api_key)
    objProject = tlclient.getTestProjectByName(project_name)
    objTestPlan = objProject.getTestPlanByName(plan_name)
    objtestcase = objTestPlan.getTestCases()
    objTestExecution = objTestPlan.getTestExecutionByBuildName(build)
    build = objTestPlan.getBuildByName("v2.0")
    cases = objTestPlan.getTestCases()
    # print("case are %s" % cases)
    for case in cases:
        case_result = {"dev_key": api_key, "testcasesid": case.getId(), "testplanid": objTestPlan.getId(), "status": "",
                        "build": build.getId(), "notes": "", "steps": []}
        case_steps = case.getSteps()
        for step in case_steps:
            step_action = step['actions'].split("\n")[0:-1]
            step_expected_result = step['expected_results']
            vector_steps = []
            for item in step_action:
                s = re.sub(r"<br />", "", item)
                s = re.sub(r"<p>", "", s)
                s = re.sub(r"</p>", "", s)
                vector_steps.append(s)
            resp = step_expected_result[0:-3]
            s = re.sub(r"<br />", "", resp)
            s = re.sub(r"<p>", "", s)
            s = re.sub(r"</p>", "", s)
            vector_steps.append(s)


            print(vector_steps)



if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s'
    )
    file = r"E:\000_CSharp_Project\cases\MTE_TEST_Testlink.xlsx"
    api_key = "dc4f41574825e88a45d2b15cc439980a"
    url = "http://localhost/testlink/lib/api/xmlrpc/v1/xmlrpc.php"
    project_name = "PMA"
    # get_and_execute_cases(url,api_key,project_name,"jenkins","v2.0")




    #     cases_result["steps"] = case.getValue("steps")
    # print("case_result is %s"%cases_result)


    # execution = testplan.getTestExecutionByBuildName("v2.0")
    # for case in cases:
    #
    #     params = {"devKey": api_key,
    #               "testcaseid": case.getId(),
    #               "testplanid": testplan.getId(),
    #               "status": "p",
    #               "buildid": build_id,
    #               "notes": "",
    #               "overwrite": True,
    #               "steps": [{'step_number':1, 'result':'p', 'notes':"ella"},
    #                         {'step_number': 2, 'result': 'p', 'notes': "ella"},
    #                         {'step_number': 3, 'result': 'p', 'notes': "ella"},
    #                         {'step_number': 4, 'result': 'p', 'notes': "ella"},
    #                         {'step_number': 5, 'result': 'p', 'notes': "ella"},
    #                         {'step_number': 5, 'result': 'p', 'notes': "ella"}
    #                    ]
    #
    #               }
    #     resp = link.server.tl.reportTCResult(params)
    #
    # logger.debug("Call TestLink API: reportTCResult(%s), Response: %s", params, resp)
    # update_result_testlink(url,api_key, project_name)

    # sheet_name = "Direction"
    # wb = openpyxl.load_workbook(file)
    # sheet_names = wb.get_sheet_names()[1:]
    # print(sheet_names)
    # wb.close()
    # for sheet_name in sheet_names:
    #     cases = transfer_cases_xml_tetslink(file,sheet_name)
    #     struct = [
    #         {
    #             "name": "NT_TT",
    #             "subsuites":  [{"name": sheet_name,  "cases": cases}]
    #         }
    #     ]
    #
    #     tlclient = testlink.TestLinkClient(url, api_key)
    #     projectName = "DCY11"
    #     tlclient.impSuiteAndCases(projectName, struct)




# cases = transfer_cases_xml_tetslink(file,sheet_name)
    # struct = [
    #     {
    #         "name": "NT_TT",
    #         "subsuites":  [{"name": sheet_name,  "cases": cases}]
    #     }
    # ]
    #
    # tlclient = testlink.TestLinkClient(url, api_key)
    # projectName = "DCY11"
    # tlclient.impSuiteAndCases(projectName, struct)


