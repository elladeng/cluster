import nidaqmx
import time
import datetime
import collections
import logging
logger = logging.getLogger(__name__)
def get_voltage(port, duration):
    values = collections.OrderedDict()
    with nidaqmx.Task() as task: #open nidaqmx device
        # task.ai_channels.add_ai_current_chan(port)
        task.ai_channels.add_ai_voltage_chan(port)#choose ai channel and choose defined port
        resp = task.read(number_of_samples_per_channel=10)
        print(resp)
        start_time = time.time()
        while True:
            resp = task.read(number_of_samples_per_channel=5) #   parameters terminal_config=TerminalConfiguration.RSE, min_val=-5.0,max_val=10.0,
            timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
            values[timestamp] = resp
            logger.info(resp)
            time.sleep(1)
            end_time = time.time()
            print(values)
            if end_time - start_time > duration:
                break
            else:
                continue
    return values

# def write_txt(filename, contents, point=None):
#     with open (filename,"a+")as f:
#         for item in contents:
#             if point is not None:
#                 if int(contents[item]) < point:
#                     f.writelines([item,";",contents[item],"\r\n"])
#             else:
#                 f.writelines([item,":",str(contents[item]),"\r\n"])

if __name__ == "__main__":
    voltages = get_voltage("Dev1/ai0",60.0)
    log_format = "%(asctime)s-%(message)s"
    file_handler = logging.FileHandler("flashfirmware.log", mode="w")
    file_handler.setFormatter(fmt=log_format)
    stream_handle = logging.StreamHandler()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(stream_handle)
    logger.addHandler(file_handler)

    # print(voltages)
    # write_txt("result.txt",voltages)


