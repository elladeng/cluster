import re
oo = [['TG1:TT_Left', '', '26293', '#'], ['TC0:Preconditon', '', '26294', '#'], ['1._AdditionalOutputs::CEM::IndcrDisp1WdSts_UpdateBitControl=1<br />\n2._AdditionalOutputs::All_TT_OFF=1<br />\n3.WAIT=500', 'N', '26295', '#'], ['TC1:TT_Left  ON_OFF_Active Mode', '', '26296', '#'], ['1._AdditionalOutputs::CEM::UsgModSts=11<br />\n2. WAIT=3000', 'N', '26297', '#'], ['<p>1._AdditionalOutputs::CEM::IndcrDisp1WdSts=1<br />\n2.WAIT=1000</p>\n', '<p>TT_Right_ON=90</p>\n', '26298', '#'], ['', '', '26302', '#'], ['1._AdditionalOutputs::CEM::IndcrDisp1WdSts=0<br />\n2.WAIT=1000', 'TT_Left_ON=0', '26299', '#'], ['TC2:TT_Left  ON_OFF_ Cnvinc Mode', '', '26300', '#'], ['<p>1._AdditionalOutputs::CEM::IndcrDisp1WdSts=1<br />\n2.WAIT=1000</p>\n', '<p>TT_Left_ON=90</p>\n', '26301', '#']]
c1 = [['TG1:TT_Left', '', '26293', '#'], ['TC0:Preconditon', '', '26294', '#'], ['1._AdditionalOutputs::CEM::IndcrDisp1WdSts_UpdateBitControl=1<br />\n2._AdditionalOutputs::All_TT_OFF=1<br />\n3.WAIT=500', 'N', '26295', '#'], ['TC1:TT_Left  ON_OFF_Active Mode', '', '26296', '#'], ['1._AdditionalOutputs::CEM::UsgModSts=11<br />\n2. WAIT=3000', 'N', '26297', '#'], ['<p>1._AdditionalOutputs::CEM::IndcrDisp1WdSts=1<br />\n2.WAIT=1000</p>\n', '<p>TT_Right_ON=90</p>\n', '26298', '#'], ['', '', '26302', '#'], ['1._AdditionalOutputs::CEM::IndcrDisp1WdSts=0<br />\n2.WAIT=1000', 'TT_Left_ON=0', '26299', '#'], ['TC2:TT_Left  ON_OFF_ Cnvinc Mode', '', '26300', '#'], ['<p>1._AdditionalOutputs::CEM::IndcrDisp1WdSts=1<br />\n2.WAIT=1000</p>\n', '<p>TT_Left_ON=90</p>\n', '26301', '#']]
c = [['TG1:Normal Test For ABS TT', '', '26708', '#'], ['1.WAIT=1000', 'ABS_ON=95', '26709', '#'], ['1.MA=1<br />\n2.WAIT=1000', 'ABS_ON=95', '26710', '#'], ['1.MA=2<br />\n2.WAIT=1000', 'ABS_ON=95', '26711', '#'], ['1.MA=3<br />\n2.WAIT=1000', 'ABS_ON=95', '26712', '#'], ['1.WAIT=1000', 'ABS_ON=95', '26713', '#'], ['1.WAIT=1000', 'ABS_ON=95', '26714', '#']]
# data = ""
# for item in c:
#     data += "|".join(item)
# print(repr(data))
# s = re.sub(r"<br />", "", data)
# s = re.sub(r"<p>", "", s)
# s = re.sub(r"</p>", "", s)
# print(repr(s[0:-1]))
# s = 'TG1:TT_Left||26293|#TC0:Preconditon||26294|#1._AdditionalOutputs::CEM::IndcrDisp1WdSts_UpdateBitControl=1\n2._AdditionalOutputs::All_TT_OFF=1\n3.WAIT=500|N|26295|#TC1:TT_Left  ON_OFF_Active Mode||26296|#1._AdditionalOutputs::CEM::UsgModSts=11\n2. WAIT=3000|N|26297|#1._AdditionalOutputs::CEM::IndcrDisp1WdSts=1\n2.WAIT=1000\n|TT_Right_ON=90\n|26298|#||26302|#1._AdditionalOutputs::CEM::IndcrDisp1WdSts=0\n2.WAIT=1000|TT_Left_ON=0|26299|#TC2:TT_Left  ON_OFF_ Cnvinc Mode||26300|#1._AdditionalOutputs::CEM::IndcrDisp1WdSts=1\n2.WAIT=1000\n|TT_Left_ON=90\n|26301|#'
test =  [{'step_number': 6, 'notes': '[65]', 'result': 'f', 'pic': 'E:\\0000_Cluster\\cases\\testlink\\1568078850.5303428.jpeg', 'id': '26287'},
             {'step_number': 7, 'notes': '0', 'result': 'p', 'id': '26288'},
            {'step_number': 9, 'notes': '[70]', 'result': 'f', 'pic': 'E:\\0000_Cluster\\cases\\testlink\\1568078855.9702942.jpeg', 'id': '26290'}]
data = "||26264#||26265#N||26266#||26267#N||26268#Failed|0;Link|26269#Passed|0|26270<EOF>"
data =data[0:-5]
new = re.sub("\|",",",data)
result = new.split("#")
print(result)
datas = []
for resp in result:
    datas.append(resp.split(","))
print(datas)

case_step_lens = len(datas)
result_step = list()
for i in range(0,case_step_lens):
    case_step_result = dict()
    resp = datas[i]
    for content in resp:
        if resp[0] == "":
            break
        else:
            case_step_result["step_number"]=i+1
            case_step_result['result']=resp[0][0].lower()
            case_step_result["notes"]=resp[1]
            case_step_result["id"]= resp[2]
    result_step.extend([case_step_result])

    # for j in range(0,len(datas[i])):
    #     item = datas[i][j]
    #     print(item)
    #     if item == "":
    #         continue
    #     else:
    #         case_step_result["step_number"]=i+1
    #         case_step_result['result']=item[0][0]
    #         case_step_result["notes"]=item[1]
    #         case_step_result["id"]= item[2]
    # result_step.append([case_step_result])
print(result_step)
