import socket
import logging

logger = logging.getLogger(__name__)

class MTEServer(object):
    def __init__(self):
        self.sock = socket.socket()
        self.sock.bind(("localhost", 8888))
        self.sock.listen(5)
        self.conn = None

    def start(self):
        while True:
            logger.info("Sever waiting..........")
            self.conn, addr = self.sock.accept()
            receive_client_data = self.conn.recv(4096)
            datas = eval(receive_client_data.decode())
            print(type(datas))
            logger.info("Server side receive client data is %s",datas)
            feeback_values= [["p"],["f"],["TT_LEFT_ON=90"]]
            self.conn.sendall(bytes(str(feeback_values),'utf8'))

    def stop(self):
        self.conn.close()



if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s'
    )
    ser = MTEServer()
    ser.start()