import socket
import logging
import time
logger = logging.getLogger(__name__)


class MTEClient(object):
    def __init__(self, addr, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((addr, port))
        print("Connect to SocketU2(%s:%s)" % (addr, port))
        self.sock.setblocking(0)

    def recv_until(self, end="<EOF>"):
        data = ""
        while True:
            try:
                new_data = self.sock.recv(4096).decode()
                logger.debug("recv: %s", new_data)
                data += new_data
                if "<EOF>" in data:
                    break
            except socket.error:
                pass
        return data

    def send(self,value):
        self.sock.send(bytes(str(value),"utf8"))



if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s'
    )
    addr = "136.17.77.157 "
    port = 8888
    con = MTEClient(addr,port)
    value = "TG1:1ormal I1put||26721|#TC1:BRAKE! i1 IG1=o1 state||26722|#1.DIAG:0x7C0 =02 10 03|DIAG:msg_0x7C8=06 50 03 00 32 01 F4|26723|#1.DIAG:0x7C0 =05 2E 20 01 80 80|DIAG:msg_0x7C8=7F 2E 78 00 00 00 00 6E 20 01|26724|#1.WAIT=3000|DIAG:msg_0x7C8=03 6E 20 01|26725|#1.DIAG:0x7C0 =04 2E 20 02 01 |DIAG:msg_0x7C8=03 6E 20 02 |26726|"
    con.send(value)
    time.sleep(2)
    receive_server_datas = con.recv_until()
    logger.info("receive server datas are %s",receive_server_datas)
