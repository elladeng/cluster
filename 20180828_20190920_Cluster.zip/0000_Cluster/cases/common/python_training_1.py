# 类型讲解
a = 5
b = 6.0
c = "A"
print("%s is type %s" % (a, type(a)))
print("%s is type %s" % (b, type(b)))
print("%s is type %s" % (c, type(c)))
print(ord("A"))
print(chr(65))

#运算符讲解
year = 2000
if year % 4 == 0 and year % 100 !=0 or year % 400 ==0:
    print("%s 是闰年"% year)
else:
    print("%s 不是闰年" % year)

# if 语句使用
a = 5
b = 5
if a == b:
    print("a is equal to b")
else:
    print("a is not equal to b")

from random import randint
face = randint(1, 6)
if face == 1:
    result = '唱首歌'
elif face == 2:
    result = '跳个舞'
elif face == 3:
    result = '学狗叫'
elif face == 4:
    result = '做俯卧撑'
elif face == 5:
    result = '念绕口令'
else:
    result = '讲冷笑话'
print(result)

# for in  案列
resp = ["s1", "s2", "s3", "s4"]
resp_len = len(resp)
for i in range(0, resp_len):
    print(resp[i])

# while Ture
# import random
#
# answer = random.randint(1, 10)
# counter = 0
# while True:
#     counter += 1
#     number = int(input('请输入: '))
#     if number < answer:
#         print('再大一点')
#     elif number > answer:
#         print('再小一点')
#     else:
#         print('恭喜你猜对了!')
#         break
# print('你总共猜了%d次' % counter)

str1 = 'hello, world!'# 通过len函数计算字符串的长度
print(len(str1))  # 13# 获得字符串首字母大写的拷贝
print(str1.capitalize())  # Hello, world!# 获得字符串变大写后的拷贝
print(str1.upper())  # HELLO, WORLD!# 从字符串中查找子串所在位置
print(str1.find('or'))  # 8
print(str1.find('shit'))  # -1
print(str1.startswith('He'))  # False # 检查字符串是否以指定的字符串开头
print(str1.endswith('!'))  # True # 检查字符串是否以指定的字符串结尾
str2 = 'abc123456'
print(str2[2])  # c # 从字符串中取出指定位置的字符(下标运算)
# 字符串切片(从指定的开始索引到指定的结束索引)
print(str2[2:5])  # c12
print(str2[2:])  # c123456
print(str2[2::2])  # c246
print(str2[::2])  # ac246
print(str2[::-1])  # 654321cba
print(str2[-3:-1])  # 45
print(str2.strip())# 获得字符串修剪左右两侧空格的拷贝

list1 = [1, 3, 5, 7, 100] #列表的格式
list2 = ['hello'] * 5  # 列表的复制
print(len(list1))  # 计算列表长度(元素个数)
print(list1[0])    # 下标(索引)运算
#print(list1[5])  # IndexError: list index out of range
print(list1[-1]) # 列表的最后一个值
print(list1[-3]) #列表倒数第三个值
list1[2] = 300 # 列表第二个值重新赋值
print(list1)
# 添加元素
list1.append(200) #末尾追加
list1.insert(1, 400) # 第一位插入400
list1 += [1000, 2000] # 列表相加
print(list1)
print(len(list1))
list1.remove(3)# 删除元素
if 1234 in list1:
    list1.remove(1234)
del list1[0]
print(list1)
list1.clear()# 清空列表元素
print(list1)

# 斐波拉切列数 ,yeild生成器
def fib(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
        yield a
def main():
    for val in fib(20):
        print(val)
# main()
# 斐波拉切列数 ,递归
sum = 0
def fib1(n):
    if n <= 1:
        return 1
    else:
        return fib1(n-1)+fib1(n-2)
for i in range(0,20):
    print(fib1(i))
    sum+=fib1(i)
print(sum)


set1 = {1, 2, 3, 3, 3, 2}
print(set1)

#求阶成


def factorial(num):
    result=1
    for n in range(1,num+1):
        result *=n
    return result


print(factorial(5))

def add(*args):
    total = 0
    for val in args:
        total += val
    return total
print(add())
print(add(1))
print(add(1, 2))
print(add(1, 2, 3))
print(add(1, 3, 5, 7, 9))

import cv2
import time
import numpy as np
import os
import datetime

import logging
logger = logging.getLogger(__name__)


class OpenCVWebCam(object):
    def __init__(self, devnum):          #初始化类的对象，相对于C#构造函数
        self.__devnum = int(devnum)

    def capture_image(self,name, scale=False):   #定义类方法 拍照方法
        cap = cv2.VideoCapture(self.__devnum)
        try:
            ret, frame = cap.read()
            # Display the resulting frame+
            # cv2.imshow('frame', frame)
            cv2.imwrite(name, frame)
        finally:
            cap.release()
            if scale:
                pic = cv2.imread(name)
                res=cv2.resize(pic, (160, 90))
                cv2.imwrite(name,res)
            time.sleep(3)

    def capture_video(self, duration_time=60,interval=60): #定义类方法 ,拍视频
        mins  = int(duration_time /int(interval)) # capture image per 10 mins
        for i in range(0,mins):
            cap = cv2.VideoCapture(self.__devnum)
            print('output_%s_%s.avi'%(i,self.__devnum))
            # Define the codec and create VideoWriter object
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
            out = cv2.VideoWriter('output_%s_%s.avi'%(i,self.__devnum), fourcc, 20.0, (640, 480))
            start_time = end_time = time.time()
            font = cv2.FONT_HERSHEY_SIMPLEX
            while cap.isOpened():
                ret, frame = cap.read()
                if ret == True:
                    frame = cv2.resize(frame, (640, 480)) # this for 2 webcamers
                    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
                    cv2.putText(frame, str(timestamp), (400, 460), \
                                font, 0.5, (0, 0, 255), 1)
                    # write the flipped frame
                    out.write(frame)
                    end_time = time.time()
                    if end_time - start_time >= int(interval):
                        break
                else:
                    break
         # Release everything if job is finished
            cap.release()
            out.release()

            cap.release()

    def get_images_from_video(self,video_files,image_dir=r"E:\husky_new\lib\simg\equipment\temp_image\\"): # 从视频中获取图片
        cap = cv2.VideoCapture(video_files)
        flash_rate = 0
        while True:
            ret, frame = cap.read()
            if ret:
                cv2.imwrite(os.path.join(image_dir, str(time.time())) + ".png", frame)
            else:
                break
        print(flash_rate)

    def __str__(self):
        return "web_num_%s" % self.__devnum

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s'
    )
    import threading
    import argparse
    import sys
    # parser = argparse.ArgumentParser(description="please input web num")
    # parser.add_argument('--web1', help="please input the web num 1",type=str)
    # parser.add_argument('--duration', help="please input durationt time",type=int)
    # parser.add_argument('--interval', help="please input durationt time", type=int)
    # args = parser.parse_args()

    # web_1 = WebCam(args.web1)
    # print("Start to record the video")
    # try:
    #     web_1.capture_video(args.duration,args.interval)
    # except KeyboardInterrupt:
    #     sys.exit()

    name_1 = "test1.jpeg"
    name_2 = "test2.jpeg"
    web_1 = OpenCVWebCam("0")
    web_1.capture_image(name_1)
    web_2 = OpenCVWebCam("1")
    web_2.capture_video(name_2)
    # a = threading.Thread(target=web_1.capture_video, args=(args.duration,))
    # print(a)
    # b = threading.Thread(target=web_2.capture_one_image, args=(args.duration,))
    # print(b)
    # a.start()
    # b.start()
    # a.join()
    # b.join()

    # # web_1.capture_continued_iamge()
    # web_1.capture_image(name_test)
    # web_1.capture_one__image()
    # web_1.capture_image(name_golden)

