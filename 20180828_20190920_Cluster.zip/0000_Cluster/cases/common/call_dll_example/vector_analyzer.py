import clr
import time
import os
import subprocess
from clr import System
a = clr.AddReference("test")
# from ClassLibrary import *
# a = 16
# b = 2
# c = TestDll.Add(a,b)
# print(c)

b = clr.AddReference("Vector")
print(b)
from  CANalyzer import *

class CANalyzerClass(object):
    def __init__(self,cfg_name):
        self.application = Application()
        self.cfg_name = cfg_name
        self.Measurement = self.application.Measurement.Running

    def open_simulation(self):
        if (self.application != None):
            # check for valid file and it is *.cfg file
            if os.path.isfile(self.cfg_name) and (os.path.splitext(self.cfg_name)[1] == ".cfg"):
                self.application.Open(self.cfg_name,False,False)
            else:
                raise RuntimeError("Can't find CANaylzer cfg file")
        else:
            raise RuntimeError("CANalyzer Application is missing,unable to open simulation")

    def close_simulation(self):
        # close CANalyzer simulation
        if (self.application != None):
            self.stop_Measurement()
            self.application.Quit()
    # make sure the CANalyzer is close properly, otherwise enforce taskkill
        output = subprocess.check_output('tasklist', shell=True)
        if "CANw64.exe" in str(output):
            os.system("taskkill /im CANw64.exe /f 2>nul >nul")
        self.application = None

    def start_Measurement(self):
        retry = 0
        retry_counter = 5
        # try to establish measurement within 20s timeout
        while not self.application.Measurement.Running and (retry < retry_counter):
            self.application.Measurement.Start()
            time.sleep(1)
            retry += 1
        if (retry == retry_counter):
            raise RuntimeWarning("CANoe start measuremet failed, Please Check Connection!")

    def stop_Measurement(self):
        if self.application.Measurement.Running:
            self.application.Measurement.Stop()
        else:
            pass

    def call_capl_diag_function(self,function,params):
        func = self.application.CAPL.GetFunction(function)
        print(func)
        # func.Call(*resp)

    def get_SysVar(self, ns_name, sysvar_name):

        if (self.application != None):
            a = self.application.System
            print(a)
            print(dir(a))
            systemCAN = a.Namespaces
            print(systemCAN)

            sys_namespace = systemCAN(ns_name)
            sys_value = sys_namespace.Variables(sysvar_name)
            return sys_value.Value
        else:
            raise RuntimeError("CANoe is not open,unable to GetVariable")

    def set_SysVar(self, ns_name, sysvar_name, var):

        if (self.application != None):
            systemCAN = self.application.System.Namespaces
            sys_namespace = systemCAN(ns_name)
            sys_value = sys_namespace.Variables(sysvar_name)
            sys_value.Value = var
            # print(sys_value)
            # result = sys_value(sys_name)
            #
            # result = var
        else:
            raise RuntimeError("CANoe is not open,unable to GetVariable")


if __name__ =="__main__":
    cfgname = r"E:\000_CSharp_Project\01_Project\new_for_automation_0813\dcy11_auto_08013.cfg"
    app = CANalyzerClass(cfgname)
    try:
        app.open_simulation()
        app.start_Measurement()
        time.sleep(10)
        name_space = "_AdditionalOutputs::CEM::"
        sysvar= "UsgModSts"
        value = app.get_SysVar(name_space,sysvar)
        print(value)

        # da09 = [0x40,0x03,0x00,0x03,0x22,0xDA,0x09,0x00]
        # app.call_capl_diag_function("SendRawDiagnostic",da09)
    except ArithmeticError:
        pass
    finally:
        pass
        # app.stop_Measurement()
        # app.close_simulation()

