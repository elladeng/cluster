# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'refer.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(427, 178)
        self.groupBox = QtWidgets.QGroupBox(Form)
        self.groupBox.setGeometry(QtCore.QRect(0, 0, 201, 171))
        self.groupBox.setObjectName("groupBox")
        self.label = QtWidgets.QLabel(self.groupBox)
        self.label.setGeometry(QtCore.QRect(10, 20, 71, 21))
        self.label.setLineWidth(9)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(10, 50, 47, 13))
        self.label_2.setObjectName("label_2")
        self.lineEdit_refer = QtWidgets.QLineEdit(self.groupBox)
        self.lineEdit_refer.setGeometry(QtCore.QRect(80, 20, 113, 20))
        self.lineEdit_refer.setObjectName("lineEdit_refer")
        self.textEdit_refer = QtWidgets.QTextEdit(self.groupBox)
        self.textEdit_refer.setGeometry(QtCore.QRect(10, 80, 191, 91))
        self.textEdit_refer.setObjectName("textEdit_refer")
        self.pushButton_refer = QtWidgets.QPushButton(self.groupBox)
        self.pushButton_refer.setGeometry(QtCore.QRect(120, 50, 75, 23))
        self.pushButton_refer.setObjectName("pushButton_refer")
        self.groupBox_2 = QtWidgets.QGroupBox(Form)
        self.groupBox_2.setGeometry(QtCore.QRect(220, 0, 201, 171))
        self.groupBox_2.setObjectName("groupBox_2")
        self.label_4 = QtWidgets.QLabel(self.groupBox_2)
        self.label_4.setGeometry(QtCore.QRect(10, 20, 71, 21))
        self.label_4.setLineWidth(9)
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.groupBox_2)
        self.label_5.setGeometry(QtCore.QRect(10, 50, 47, 13))
        self.label_5.setObjectName("label_5")
        self.lineEdit_add = QtWidgets.QLineEdit(self.groupBox_2)
        self.lineEdit_add.setGeometry(QtCore.QRect(80, 20, 113, 20))
        self.lineEdit_add.setObjectName("lineEdit_add")
        self.textEdit_add = QtWidgets.QTextEdit(self.groupBox_2)
        self.textEdit_add.setGeometry(QtCore.QRect(0, 80, 201, 91))
        self.textEdit_add.setObjectName("textEdit_add")
        self.pushButton_add = QtWidgets.QPushButton(self.groupBox_2)
        self.pushButton_add.setGeometry(QtCore.QRect(120, 50, 75, 23))
        self.pushButton_add.setObjectName("pushButton_add")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.groupBox.setTitle(_translate("Form", "refer"))
        self.label.setText(_translate("Form", "abbreviation:"))
        self.label_2.setText(_translate("Form", "details:"))
        self.pushButton_refer.setText(_translate("Form", "OK"))
        self.groupBox_2.setTitle(_translate("Form", "add"))
        self.label_4.setText(_translate("Form", "abbreviation:"))
        self.label_5.setText(_translate("Form", "details:"))
        self.pushButton_add.setText(_translate("Form", "OK"))

