import sys
from PyQt5.QtWidgets import QApplication, QFileSystemModel, QTreeView, QWidget, QVBoxLayout,\
                             QDesktopWidget,QMainWindow,QMessageBox,QFileDialog,QAction
from PyQt5 import QtGui,QtCore
from PyQt5.QtCore import QSettings
from cases.common.name_explain.refer import Ui_Form
import time

import datetime

import threading
import logging
import re
import subprocess

logger = logging.getLogger(__name__)


class NAMEEXPLAINTATION(QMainWindow,Ui_Form):
    def __init__(self,parent=None):
        super(NAMEEXPLAINTATION,self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle("Name_Explain")
        self.center()
        self.key = ""
        self.pushButton_refer.clicked.connect(self.start_thread_process_refer)
        self.pushButton_add.clicked.connect(self.start_thread_process_add)



    def center(self):
        screen = QDesktopWidget().screenGeometry()
        size = self.geometry()
        self.move((screen.width() - size.width()) / 2, (screen.height() - size.height()) / 2)



    def start_thread_process_refer(self):
        self.textEdit_refer.setText("")
        logger.info("refer key is %s",self.key)
        self.thread = threading.Thread(target=self.exectue_process)
        self.thread.setDaemon(True)
        self.thread.start()

    def exectue_process(self):
        self.key = self.lineEdit_refer.text()
        self.textEdit_refer.setReadOnly(True)
        settings = QSettings("database.ini", QSettings.IniFormat)
        settings.setIniCodec("utf8")
        settings.beginGroup("Config")
        if self.key in settings.allKeys():
            values = settings.value(self.key)

            self.textEdit_refer.append(values)

        else:
            self.textEdit_refer.append("not find in current database")
        settings.endGroup()


    def start_thread_process_add(self):
        self.values = self.textEdit_add.toPlainText()
        self.key = self.lineEdit_add.text()
        self.textEdit_add.setText("")
        logger.info("add key is %s",self.key)
        self.thread = threading.Thread(target=self.exectue_process_add,args=(self.values,))
        self.thread.setDaemon(True)
        self.thread.start()

    def exectue_process_add(self,values):
        self.key_new = self.lineEdit_add.text().upper()
        settings = QSettings("database.ini", QSettings.IniFormat)
        settings.setIniCodec("utf8");
        settings.beginGroup("config")
        if self.key_new in settings.allKeys():
            self.textEdit_add.append("Already include it in  database")
        else:
            print(values)
            settings.setValue(self.key_new, values)
        settings.endGroup()






if __name__ == "__main__":
    import sys
    log_format = logging.Formatter("%(asctime)s-%(message)s")
    file_handler = logging.FileHandler("refer.log",mode="w")
    file_handler.setFormatter(fmt=log_format)

    stream_handle = logging.StreamHandler()
    stream_handle.setFormatter(fmt=log_format)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(stream_handle)
    logger.addHandler(file_handler)
    # logging.basicConfig(level=logging.INFO,format="%(asctime)s-%(message)s",filename="flashfirmware.log",filemode='w')
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_X11InitThreads)
    app = QApplication(sys.argv)
    ui = NAMEEXPLAINTATION()
    ui.show()
    sys.exit(app.exec_())


