import openpyxl
from cases.common.repeat_excel_cases.repeat_cycle import Ui_RepeatWindow
from PyQt5.QtWidgets import QApplication,QMessageBox,\
                             QDesktopWidget,QMainWindow,QFileDialog
from PyQt5 import QtCore
import logging
import threading
import re
import time
from openpyxl.styles import Border,Side,Alignment
border = Border(left=Side(border_style='thin', color='000000'),
                right=Side(border_style='thin', color='000000'),
                top=Side(border_style='thin', color='000000'),
                bottom=Side(border_style='thin', color='000000')
                )
align = Alignment(wrapText=True)  # 自动换行


class RepeatExcelContent(QMainWindow, Ui_RepeatWindow):
    def __init__(self):
        super(RepeatExcelContent, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("Repeat Cases ")
        self.center()
        self.file = self.pushButton_excel_file.clicked.connect(self.get_excel_file)
        self.pushButton_2.clicked.connect(self.close_window)
        self.pushButton.clicked.connect(self.start_thread_process)

    def start_thread_process(self):
        self.thread = threading.Thread(target=self.generate_repeat_contents)
        self.thread.setDaemon(True)
        self.thread.start()
        self.thread.join()
        QMessageBox.information(None, "Finish", "Please check the %s"%self.file)

    def get_excel_file(self):
        logger.info("choose cfg file")
        # file_name  = QFileDialog.getOpenFileName(self, "open original excel file", filter="excel files(*.xlsx)", options= QFileDialog.DontUseNativeDialog)
        file_name = QFileDialog.getOpenFileName(self, "open original excel file", filter="excel files(*.xlsx)")

        if file_name is not None:
            self.lineEdit_excel_file.setText(file_name[0])
        logger.info("file name is %s"%self.lineEdit_excel_file.text())

    def generate_repeat_contents(self):
        self.sheet = self.lineEdit_sheetname.text()
        self.start_row = self.lineEdit_start_row.text()
        self.end_row = self.lineEdit_stop_row.text()
        self.repeat_cycle = self.lineEdit_repeat_cycle.text()
        logger.info("genrate repeat contents")
        self.file = re.sub("/","\\\\",self.lineEdit_excel_file.text())
        self.wb = openpyxl.load_workbook(self.file)
        self.ws = self.wb[self.sheet]
        self.rows = self.ws.max_row
        self.columns = self.ws.max_column
        orignal_contents = []
        for i in range(2, self.rows + 1):
            row_contest = []
            for j in range(1, self.columns + 1):
                row_contest.append(self.ws.cell(i, j).value)
            orignal_contents.append(row_contest)
        new_contents = orignal_contents[int(self.start_row)-3:int(self.end_row)+1]
        new_repeat_contents =[]
        for k in range(0,int(self.repeat_cycle)):
            new_repeat_contents.append(new_contents[1:])
        print(new_repeat_contents)
        for value in new_repeat_contents:
            for item in value:
                self.ws.append(item)  #写入excel
        self.wb.save(self.file)
        time.sleep(5)
        new_wb = openpyxl.load_workbook(self.file)
        new_ws= new_wb[self.sheet]
        new_rows = new_ws.max_row
        print(new_rows)

        for i in range(int(self.start_row),new_rows+1):
            for j in range(1,self.columns+1):
                new_ws.cell(row=i, column=1, value=str(i+1-int(self.start_row)))
                new_ws.cell(row=i, column=j).border = border
                new_ws.cell(row=i, column=j).alignment = align
        new_wb.save(self.file)
        time.sleep(10)

    def center(self):
        screen = QDesktopWidget().screenGeometry()
        size = self.geometry()
        self.move((screen.width() - size.width()) / 2, (screen.height() - size.height()) / 2)

    def close_window(self):
        # self.thread.stop()
        logger.info("Close this Application ")
        qApp = QApplication.instance()
        qApp.quit()
        sys.exit()

if __name__ == "__main__":
    import sys
    log_format = "%(asctime)s-%(message)s"
    file_handler = logging.FileHandler("flashfirmware.log", mode="w")
    stream_handle = logging.StreamHandler()
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(stream_handle)
    logger.addHandler(file_handler)
    # logging.basicConfig(level=logging.INFO,format="%(asctime)s-%(message)s",filename="flashfirmware.log",filemode='w')
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_X11InitThreads)
    app = QApplication(sys.argv)
    ui = RepeatExcelContent()
    ui.show()
    sys.exit(app.exec_())