# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'repeat_cycle.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_RepeatWindow(object):
    def setupUi(self, RepeatWindow):
        RepeatWindow.setObjectName("RepeatWindow")
        RepeatWindow.resize(244, 219)
        self.centralwidget = QtWidgets.QWidget(RepeatWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(10, 10, 221, 171))
        self.widget.setObjectName("widget")
        self.widget1 = QtWidgets.QWidget(self.widget)
        self.widget1.setGeometry(QtCore.QRect(0, 10, 216, 158))
        self.widget1.setObjectName("widget1")
        self.gridLayout = QtWidgets.QGridLayout(self.widget1)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.pushButton_excel_file = QtWidgets.QPushButton(self.widget1)
        self.pushButton_excel_file.setObjectName("pushButton_excel_file")
        self.gridLayout.addWidget(self.pushButton_excel_file, 0, 0, 1, 1)
        self.lineEdit_excel_file = QtWidgets.QLineEdit(self.widget1)
        self.lineEdit_excel_file.setObjectName("lineEdit_excel_file")
        self.gridLayout.addWidget(self.lineEdit_excel_file, 0, 1, 1, 1)
        self.label_4 = QtWidgets.QLabel(self.widget1)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 1, 0, 1, 1)
        self.lineEdit_sheetname = QtWidgets.QLineEdit(self.widget1)
        self.lineEdit_sheetname.setObjectName("lineEdit_sheetname")
        self.gridLayout.addWidget(self.lineEdit_sheetname, 1, 1, 1, 1)
        self.label = QtWidgets.QLabel(self.widget1)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 2, 0, 1, 1)
        self.lineEdit_start_row = QtWidgets.QLineEdit(self.widget1)
        self.lineEdit_start_row.setObjectName("lineEdit_start_row")
        self.gridLayout.addWidget(self.lineEdit_start_row, 2, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.widget1)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 3, 0, 1, 1)
        self.lineEdit_stop_row = QtWidgets.QLineEdit(self.widget1)
        self.lineEdit_stop_row.setObjectName("lineEdit_stop_row")
        self.gridLayout.addWidget(self.lineEdit_stop_row, 3, 1, 1, 1)
        self.label_3 = QtWidgets.QLabel(self.widget1)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 4, 0, 1, 1)
        self.lineEdit_repeat_cycle = QtWidgets.QLineEdit(self.widget1)
        self.lineEdit_repeat_cycle.setObjectName("lineEdit_repeat_cycle")
        self.gridLayout.addWidget(self.lineEdit_repeat_cycle, 4, 1, 1, 1)
        self.pushButton = QtWidgets.QPushButton(self.widget1)
        self.pushButton.setObjectName("pushButton")
        self.gridLayout.addWidget(self.pushButton, 5, 0, 1, 1)
        self.pushButton_2 = QtWidgets.QPushButton(self.widget1)
        self.pushButton_2.setObjectName("pushButton_2")
        self.gridLayout.addWidget(self.pushButton_2, 5, 1, 1, 1)
        RepeatWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(RepeatWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 244, 21))
        self.menubar.setObjectName("menubar")
        RepeatWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(RepeatWindow)
        self.statusbar.setObjectName("statusbar")
        RepeatWindow.setStatusBar(self.statusbar)

        self.retranslateUi(RepeatWindow)
        QtCore.QMetaObject.connectSlotsByName(RepeatWindow)

    def retranslateUi(self, RepeatWindow):
        _translate = QtCore.QCoreApplication.translate
        RepeatWindow.setWindowTitle(_translate("RepeatWindow", "MainWindow"))
        self.pushButton_excel_file.setText(_translate("RepeatWindow", "original_excel"))
        self.label_4.setText(_translate("RepeatWindow", "sheet_name"))
        self.label.setText(_translate("RepeatWindow", "start_row"))
        self.label_2.setText(_translate("RepeatWindow", "stop_row"))
        self.label_3.setText(_translate("RepeatWindow", "repeat_cycle"))
        self.pushButton.setText(_translate("RepeatWindow", "generate"))
        self.pushButton_2.setText(_translate("RepeatWindow", "cancel"))

