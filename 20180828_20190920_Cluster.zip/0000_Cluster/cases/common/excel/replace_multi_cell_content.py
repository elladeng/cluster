import re
import openpyxl
import logging
logger = logging.getLogger(__name__)


def change__multi_values(file,sheet_name= None,old_values=None,new_values=None):
    wb = openpyxl.load_workbook(file)
    sheets = wb.get_sheet_names()
    sheets = sheets[1:]
    logger.inof("change the sheets are %s",sheets)

    values = dict(zip(old_values.split(","),new_values.split(",")))
    logger.info("change the dictionary are %s",values)
    if sheet_name is not None:
        ws = wb[sheet_name]
        rows = ws.max_row + 1
        columns = ws.max_column+1
        for key in values:
            for i in range(1, rows):
                for j in range(1,columns):
                    if ws.cell(i,j).value is not None:
                        if key in str(ws.cell(i,j).value):
                            old_resp = str(ws.cell(i,j).value)
                            ws.cell(i, j).value = re.sub(key,values[key],old_resp)
    else:
        for sheet in sheets:
            ws = wb[sheet]
            rows = ws.max_row+1
            columns = ws.max_column + 1
            for key in values.keys:
                for i in range(1, rows):
                    for j in range(1, columns):
                        if ws.cell(i, j).value is not None:
                            if key in str(ws.cell(i, j).value):
                                old_resp = str(ws.cell(i, j).value)
                                ws.cell(i, j).value = re.sub(key, values[key], old_resp)
    wb.save(file)