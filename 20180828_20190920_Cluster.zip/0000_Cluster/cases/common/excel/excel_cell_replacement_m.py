# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'excel_cell_replacement_m.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(389, 342)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.widget = QtWidgets.QWidget(self.centralwidget)
        self.widget.setGeometry(QtCore.QRect(0, 0, 341, 311))
        self.widget.setObjectName("widget")
        self.lineEdit = QtWidgets.QLineEdit(self.widget)
        self.lineEdit.setGeometry(QtCore.QRect(110, 10, 161, 21))
        self.lineEdit.setObjectName("lineEdit")
        self.pushButton_start = QtWidgets.QPushButton(self.widget)
        self.pushButton_start.setGeometry(QtCore.QRect(280, 10, 51, 23))
        self.pushButton_start.setObjectName("pushButton_start")
        self.label = QtWidgets.QLabel(self.widget)
        self.label.setGeometry(QtCore.QRect(20, 50, 81, 16))
        self.label.setObjectName("label")
        self.textEdit_old_values = QtWidgets.QTextEdit(self.widget)
        self.textEdit_old_values.setGeometry(QtCore.QRect(20, 70, 301, 101))
        self.textEdit_old_values.setObjectName("textEdit_old_values")
        self.textEdit_new_values = QtWidgets.QTextEdit(self.widget)
        self.textEdit_new_values.setGeometry(QtCore.QRect(20, 190, 301, 101))
        self.textEdit_new_values.setObjectName("textEdit_new_values")
        self.pushButton_load_xlsx = QtWidgets.QPushButton(self.widget)
        self.pushButton_load_xlsx.setGeometry(QtCore.QRect(20, 10, 75, 23))
        self.pushButton_load_xlsx.setObjectName("pushButton_load_xlsx")
        self.label_2 = QtWidgets.QLabel(self.widget)
        self.label_2.setGeometry(QtCore.QRect(20, 170, 81, 16))
        self.label_2.setObjectName("label_2")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 389, 21))
        self.menubar.setObjectName("menubar")
        self.menuHelp = QtWidgets.QMenu(self.menubar)
        self.menuHelp.setObjectName("menuHelp")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.toolBar = QtWidgets.QToolBar(MainWindow)
        self.toolBar.setObjectName("toolBar")
        MainWindow.addToolBar(QtCore.Qt.TopToolBarArea, self.toolBar)
        self.actionHow_to = QtWidgets.QAction(MainWindow)
        self.actionHow_to.setObjectName("actionHow_to")
        self.menuHelp.addAction(self.actionHow_to)
        self.menubar.addAction(self.menuHelp.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton_start.setText(_translate("MainWindow", "Start"))
        self.label.setText(_translate("MainWindow", "old_values"))
        self.pushButton_load_xlsx.setText(_translate("MainWindow", "load_xlsx"))
        self.label_2.setText(_translate("MainWindow", "new_values"))
        self.menuHelp.setTitle(_translate("MainWindow", "Help"))
        self.toolBar.setWindowTitle(_translate("MainWindow", "toolBar"))
        self.actionHow_to.setText(_translate("MainWindow", "How to "))

