# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'excel_cell_replacement.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MTE_CASES_Replacement(object):
    def setupUi(self, MTE_CASES_Replacement):
        MTE_CASES_Replacement.setObjectName("MTE_CASES_Replacement")
        MTE_CASES_Replacement.resize(321, 314)
        self.textEdit_old_values = QtWidgets.QTextEdit(MTE_CASES_Replacement)
        self.textEdit_old_values.setGeometry(QtCore.QRect(10, 80, 301, 101))
        self.textEdit_old_values.setObjectName("textEdit_old_values")
        self.label = QtWidgets.QLabel(MTE_CASES_Replacement)
        self.label.setGeometry(QtCore.QRect(10, 60, 81, 16))
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(MTE_CASES_Replacement)
        self.label_2.setGeometry(QtCore.QRect(10, 180, 81, 16))
        self.label_2.setObjectName("label_2")
        self.textEdit_new_values = QtWidgets.QTextEdit(MTE_CASES_Replacement)
        self.textEdit_new_values.setGeometry(QtCore.QRect(10, 200, 301, 101))
        self.textEdit_new_values.setObjectName("textEdit_new_values")
        self.pushButton_start = QtWidgets.QPushButton(MTE_CASES_Replacement)
        self.pushButton_start.setGeometry(QtCore.QRect(240, 20, 75, 23))
        self.pushButton_start.setObjectName("pushButton_start")
        self.lineEdit = QtWidgets.QLineEdit(MTE_CASES_Replacement)
        self.lineEdit.setGeometry(QtCore.QRect(80, 20, 161, 21))
        self.lineEdit.setObjectName("lineEdit")
        self.pushButton_load_xlsx = QtWidgets.QPushButton(MTE_CASES_Replacement)
        self.pushButton_load_xlsx.setGeometry(QtCore.QRect(0, 20, 75, 23))
        self.pushButton_load_xlsx.setObjectName("pushButton_load_xlsx")

        self.retranslateUi(MTE_CASES_Replacement)
        QtCore.QMetaObject.connectSlotsByName(MTE_CASES_Replacement)

    def retranslateUi(self, MTE_CASES_Replacement):
        _translate = QtCore.QCoreApplication.translate
        MTE_CASES_Replacement.setWindowTitle(_translate("MTE_CASES_Replacement", "Form"))
        self.label.setText(_translate("MTE_CASES_Replacement", "old_values"))
        self.label_2.setText(_translate("MTE_CASES_Replacement", "new_values"))
        self.pushButton_start.setText(_translate("MTE_CASES_Replacement", "Start"))
        self.pushButton_load_xlsx.setText(_translate("MTE_CASES_Replacement", "load_xlsx"))

