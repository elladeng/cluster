# from cases.common.excel.excel_cell_replacement import Ui_MTE_CASES_Replacement
from cases.common.excel.excel_cell_replacement_m import Ui_MainWindow
from PyQt5.QtWidgets import QApplication, QDesktopWidget,QMainWindow,QMessageBox,QFileDialog,QAction
from PyQt5 import QtCore,QtWidgets,QtGui
import threading
import logging
import re
import openpyxl


def change__multi_values(file,old_values=None,new_values=None,sheet_name= None):
    wb = openpyxl.load_workbook(file)
    sheets = wb.get_sheet_names()
    sheets = sheets[1:]
    logger.info("change the sheets are %s",sheets)
    values = dict(zip(old_values.split(","),new_values.split(",")))
    print(old_values)
    print(new_values)
    logger.info("change the dictionary are %s",values)
    if sheet_name is not None:
        ws = wb[sheet_name]
        rows = ws.max_row + 1
        columns = ws.max_column+1
        for key in values:
            for i in range(1, rows):
                for j in range(1,columns):
                    if ws.cell(i,j).value is not None:
                        if key in str(ws.cell(i,j).value):
                            old_resp = str(ws.cell(i,j).value)
                            ws.cell(i, j).value = re.sub(key,values[key],old_resp)
    else:
        for sheet in sheets:
            ws = wb[sheet]
            rows = ws.max_row+1
            columns = ws.max_column + 1
            for key in values:
                for i in range(1, rows):
                    for j in range(1, columns):
                        if ws.cell(i, j).value is not None:
                            if key in str(ws.cell(i, j).value):
                                old_resp = str(ws.cell(i, j).value)
                                ws.cell(i, j).value = re.sub(key, values[key], old_resp)
    wb.save(file)


class REPLACEMENT(QMainWindow,Ui_MainWindow):
    def __init__(self, parent=None):
        super(REPLACEMENT, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle("Excel Cell Replacement")
        # icon = QtGui.QIcon()
        # icon.addPixmap(QtGui.QPixmap("modify.ico"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        # self.setWindowIcon(icon)
        self.center()
        self.pushButton_start.clicked.connect(self.start_thread_process)
        self.pushButton_load_xlsx.clicked.connect(self.load_xlsx)
        self.filename = ""
        # self.actionHow_to.trigger.connect(self.openMsg)
        self.menuHelp.triggered[QAction].connect(self.processtrigger)


    def processtrigger(self,q):
        if q.text() == "How to ":
            QMessageBox.information(self, "How_To","old value and new values \nshould be string and split \nwith dot ",QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)


    def center(self):
        screen = QDesktopWidget().screenGeometry()
        size = self.geometry()
        self.move((screen.width() - size.width()) / 2, (screen.height() - size.height()) / 2)

    def load_xlsx(self):
        logger.info("step1 :choose xlsx file")
        cfg_file_name = QFileDialog.getOpenFileName(self, "open xlsx file", filter="files(*.xlsx)")
        if cfg_file_name is not None:
            self.lineEdit.setText(cfg_file_name[0])




    def start_thread_process(self):
        self.thread = threading.Thread(target=self.execute_process)
        self.thread.setDaemon(True)
        self.thread.start()
        self.thread.join()
        # QMessageBox.information(None, "Finish", "Please check the file in \n %s "% self.file_name)
        self.statusBar().showMessage("check the file in  %s "% self.file_name)

    def execute_process(self):
        self.file_name = re.sub("/", "\\\\", self.lineEdit.text())
        logger.info("update the steps column first")
        old_values = self.textEdit_old_values.toPlainText()
        new_values = self.textEdit_new_values.toPlainText()
        change__multi_values(self.file_name,old_values,new_values)


    def close_window(self):
        logger.info("Close the  Application ")
        qApp = QApplication.instance()
        qApp.quit()
        sys.exit()


if __name__ == "__main__":
    import sys
    log_format = logging.Formatter("%(asctime)s-%(message)s")
    file_handler = logging.FileHandler("update.log",mode="w")
    file_handler.setFormatter(fmt=log_format)
    stream_handle = logging.StreamHandler()
    stream_handle.setFormatter(fmt=log_format)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(stream_handle)
    logger.addHandler(file_handler)
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_X11InitThreads)
    app = QApplication(sys.argv)
    ui = REPLACEMENT()
    ui.show()
    sys.exit(app.exec_())