import openpyxl
import argparse
import re
from datetime import datetime
from copy import copy


def copyRange(startCol, startRow, endCol, endRow, sheet):
    rangeSelected = []
    for i in range(startRow, endRow + 1, 1):
        rowSelected = []
        for j in range(startCol, endCol + 1, 1):
            rowSelected.append(sheet.cell(row=i, column=j).value)
            rowSelected.append(sheet.cell(row=i, column=j).font)
            rowSelected.append(sheet.cell(row=i, column=j).border)
            rowSelected.append(sheet.cell(row=i, column=j).fill)
            rowSelected.append(sheet.cell(row=i, column=j).number_format)
            rowSelected.append(sheet.cell(row=i, column=j).protection)
            rowSelected.append(sheet.cell(row=i, column=j).alignment)
        rangeSelected.append(rowSelected)

    return rangeSelected


def pasteRange(startCol, startRow, endCol, endRow, sheetReceiving, copiedData, newdata):
    countRow = 0
    datacount = 1
    for i in range(startRow, endRow + 1, 1):
        for j in range(startCol, endCol + 1, 1):
            if copiedData[countRow][0]:
                    sheetReceiving.cell(row=i, column=j).value = newdata[datacount]
                    datacount += 1
                    sheetReceiving.cell(row=i, column=j).font = copy(copiedData[countRow][1])
                    sheetReceiving.cell(row=i, column=j).border = copy(copiedData[countRow][2])
                    sheetReceiving.cell(row=i, column=j).fill = copy(copiedData[countRow][3])
                    sheetReceiving.cell(row=i, column=j).number_format = copy(copiedData[countRow][4])
                    sheetReceiving.cell(row=i, column=j).protection = copy(copiedData[countRow][5])
                    sheetReceiving.cell(row=i, column=j).alignment = copy(copiedData[countRow][6])
        countRow += 1


def perfParser(perffile):
    pattern = "FPGA BitStream:\\t\\t\\t(\d+)\\n"
    pattern1 = "Software Revision:\\t\\t0.0.0.0-(\d+)\\n"
    pattern2 = "Disk Capacity:\\t\\t\\t(\d+) GB\\n"
    pattern3 = "seq_write_128k_j1_q256:    \\t(\d+)MiB/s \\n"
    pattern4 = "seq_read_128k_j1_q256: \\t(\d+)MiB/s \\n"
    pattern5 = "rand_read_4k_j8_q32:     \\t(\d+)k\\n"
    pattern6 = "rand_write_4k_j4_q64:             (\d+)k\n"
    pattern7 = "randread-w0_b4k_j1_q1 \d+\.?\d* \d+\.?\d* (\d+\.?\d*)"
    pattern8 = "randwrite-r0_b4k_j1_q1 \d+\.?\d* \d+\.?\d* (\d+\.?\d*)"
    date = f"{datetime.now().year}/{datetime.now().month}/{datetime.now().day}"
    data = [None] * 9
    with open(perffile, "r") as f:
        lines = f.readlines()
        for line in lines:
            FPGA = re.findall(pattern, line)
            Revision = re.findall(pattern1, line)
            Capacity = re.findall(pattern2, line)
            seq_write = re.findall(pattern3, line)
            seq_read = re.findall(pattern4, line)
            rand_read= re.findall(pattern5, line)
            rand_write = re.findall(pattern6, line)
            randread_lat = re.findall(pattern7, line)
            randwrite_lat = re.findall(pattern8, line)
            if Capacity:
                if Capacity[0] == '3200':
                    data[0] = "BICS3_3.2T"
                if Capacity[0] == '6400':
                    data[0] = "BICS3_6.4T"
                if Capacity[0] == '1600':
                    data[0] = "BICS3_1.6T"
            if FPGA:
                data[1] = f"FPGA {FPGA[0]}"
            if Revision:
                data[2] = f"trunkr{Revision[0]}\n{date}"
            if seq_write:
                data[3] = int(seq_write[0])
            if seq_read:
                data[4] = int(seq_read[0])
            if rand_write:
                data[5] = int(rand_write[0])
            if rand_read:
                data[6] = int(rand_read[0])
            if randread_lat:
                data[7] = float(randread_lat[0])
            if randwrite_lat:
                data[8] = float(randwrite_lat[0])
    return data


def updateExcel(excelfile, perffile):
    data = perfParser(perffile)
    sheetname = data[0]
    wb = openpyxl.load_workbook(filename=excelfile)
    ws = wb.get_sheet_by_name(sheetname)
    latest = ws.max_column
    new = latest + 1
    copy_data = copyRange(latest, 1, latest, 20, ws)
    pasteRange(new, 1, new, 20, ws, copy_data, data)
    wb.save("Performance_Daliy.xlsx")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-excel', type=str, help='input excel file')
    parser.add_argument('-perf', type=str, help='input perf file')
    args = parser.parse_args()
    updateExcel(args.excel, args.perf)


