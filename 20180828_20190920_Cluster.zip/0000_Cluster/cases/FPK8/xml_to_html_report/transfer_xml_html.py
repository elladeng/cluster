# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'xml_to_html.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import lxml.etree as ET
import sys
import os.path


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(261, 193)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.layoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget.setGeometry(QtCore.QRect(20, 20, 216, 109))
        self.layoutWidget.setObjectName("layoutWidget")
        self.gridLayout = QtWidgets.QGridLayout(self.layoutWidget)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.xml_file = QtWidgets.QPushButton(self.layoutWidget)
        self.xml_file.setObjectName("xml_file")
        self.gridLayout.addWidget(self.xml_file, 0, 0, 1, 1)
        self.xml_file_e = QtWidgets.QLineEdit(self.layoutWidget)
        self.xml_file_e.setObjectName("xml_file_e")
        self.gridLayout.addWidget(self.xml_file_e, 0, 1, 1, 1)
        self.xsl_file = QtWidgets.QPushButton(self.layoutWidget)
        self.xsl_file.setObjectName("xsl_file")
        self.gridLayout.addWidget(self.xsl_file, 1, 0, 1, 1)
        self.xsl_file_e = QtWidgets.QLineEdit(self.layoutWidget)
        self.xsl_file_e.setObjectName("xsl_file_e")
        self.gridLayout.addWidget(self.xsl_file_e, 1, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.layoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.Status = QtWidgets.QLineEdit(self.layoutWidget)
        self.Status.setObjectName("Status")
        self.gridLayout.addWidget(self.Status, 2, 1, 1, 1)
        self.buttonBox = QtWidgets.QDialogButtonBox(self.layoutWidget)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel | QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.gridLayout.addWidget(self.buttonBox, 3, 0, 1, 2)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 261, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.xml_file.clicked.connect(self.open_xml_file)
        self.xsl_file.clicked.connect(self.open_xsl_file)

        self.buttonBox.accepted.connect(self.xml_to_html)
        self.buttonBox.rejected.connect(self.close_window)


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "XML_TO_HTML"))
        self.xsl_file.setText(_translate("MainWindow", "xsl_file"))
        self.xml_file.setText(_translate("MainWindow", "xml_file"))
        self.label_2.setText(_translate("MainWindow", "Status"))

    def open_xml_file(self):
        filelist = QtWidgets.QFileDialog.getOpenFileName(None, 'select file', '', 'Excel files(*.xml)')
        OPEN_FILE_NAME = filelist[0]
        if OPEN_FILE_NAME is not None:
          self.xml_file_e.setText(OPEN_FILE_NAME)

    def open_xsl_file(self):
        filelist = QtWidgets.QFileDialog.getOpenFileName(None, 'select file', '', 'xsl files(*.xsl)')
        OPEN_FILE_NAME = filelist[0]
        if OPEN_FILE_NAME is not None:
          self.xsl_file_e.setText(OPEN_FILE_NAME)

    def xml_to_html(self):
        xml_filename = self.xml_file_e.text()
        print(xml_filename)
        xsl_filename = self.xsl_file_e.text()
        print(xsl_filename)
        basename = os.path.dirname(xml_filename)
        print(basename)
        dom = ET.parse(xml_filename)
        xslt = ET.parse(xsl_filename)
        transform = ET.XSLT(xslt)
        newdom = transform(dom)
        infile = ET.tostring(newdom, pretty_print=True)
        outfile = open(os.path.join(basename,"result.html"),'w')
        outfile.write(infile.decode())
        self.Status.setText("Done")

    def close_window(self):
        sys.exit()



if __name__ == '__main__':

    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

