# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'xml_to_html.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(261, 193)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.layoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.layoutWidget.setGeometry(QtCore.QRect(20, 20, 216, 109))
        self.layoutWidget.setObjectName("layoutWidget")
        self.gridLayout = QtWidgets.QGridLayout(self.layoutWidget)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.gridLayout.setObjectName("gridLayout")
        self.xml_file = QtWidgets.QPushButton(self.layoutWidget)
        self.xml_file.setObjectName("xml_file")
        self.gridLayout.addWidget(self.xml_file, 0, 0, 1, 1)
        self.xml_file_e = QtWidgets.QLineEdit(self.layoutWidget)
        self.xml_file_e.setObjectName("xml_file_e")
        self.gridLayout.addWidget(self.xml_file_e, 0, 1, 1, 1)
        self.xsl_file = QtWidgets.QPushButton(self.layoutWidget)
        self.xsl_file.setObjectName("xsl_file")
        self.gridLayout.addWidget(self.xsl_file, 1, 0, 1, 1)
        self.xsl_file_e = QtWidgets.QLineEdit(self.layoutWidget)
        self.xsl_file_e.setObjectName("xsl_file_e")
        self.gridLayout.addWidget(self.xsl_file_e, 1, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.layoutWidget)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.Status = QtWidgets.QLineEdit(self.layoutWidget)
        self.Status.setObjectName("Status")
        self.gridLayout.addWidget(self.Status, 2, 1, 1, 1)
        self.buttonBox = QtWidgets.QDialogButtonBox(self.layoutWidget)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.gridLayout.addWidget(self.buttonBox, 3, 0, 1, 2)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 261, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.xml_file.setText(_translate("MainWindow", "xml_file"))
        self.xsl_file.setText(_translate("MainWindow", "xsl_file"))
        self.label_2.setText(_translate("MainWindow", "Status"))

