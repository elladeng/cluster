from cases.video_capture.webcamera import Ui_MainWindow
import sys
import threading
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton,QMainWindow,QDesktopWidget,QAction,QMessageBox,QFileDialog,QLabel
from cases.video_capture.webcam import OpenCVWebCam
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QIcon,QFont,QImage,QPixmap,QPainter,QPen
import cv2
from cases.video_capture.vision import Ui_Form
import numpy as np
from PyQt5.QtCore import *
import os.path

class MyLabel(QLabel):
    x0 = 0
    y0 = 0
    x1 = 0
    y1 = 0
    flag = False
    #鼠标点击事件
    def mousePressEvent(self,event):
        self.flag = True
        self.x0 = event.x()
        self.y0 = event.y()
    #鼠标释放事件
    def mouseReleaseEvent(self,event):
        self.flag = False
    #鼠标移动事件
    def mouseMoveEvent(self,event):
        if self.flag:
            self.x1 = event.x()
            self.y1 = event.y()
            self.update()
    #绘制事件
    def paintEvent(self, event):
        super().paintEvent(event)
        rect =QRect(self.x0, self.y0, abs(self.x1-self.x0), abs(self.y1-self.y0))
        painter = QPainter(self)
        painter.setPen(QPen(Qt.red,2,Qt.SolidLine))
        painter.drawRect(rect)

class VIDEOTHREAD(threading.Thread):
    def __init__(self,webport,duration,interval,path):
        super(VIDEOTHREAD, self).__init__()
        self.should_stop = threading.Event()
        self.webport=webport
        self.duration = duration
        self.interval = interval
        self.path = path



    def run(self):
        while not self.should_stop.is_set():
            self.web = OpenCVWebCam(self.webport)
            state = self.web.capture_video(self.duration,self.interval,self.path)
            if state == 1:
                self.should_stop.set()
    def stop(self):
        # self.should_stop.set()
        pass

class Video():
    def __init__(self,capture):
        self.capture = capture
        self.currentFrame = np.array([])

    def captureFrame(self):
        ret, readFrame = self.capture.read()
        return readFrame

    def catpureNextFrame(self):
        ret, readFrame = self.capture.read()
        if (ret==True):
            cv2.imshow("test",readFrame)
            cv2.waitKey()
            self.currenFrame = cv2.cvtColor(readFrame, cv2.COLOR_BGR2RGB)
            print(self.currenFrame)

    def convertFrame(self):
        image_height,image_width,image_depth = self.currenFrame.shape[:3]
        print(image_height,image_width,image_depth)
        QIm = QImage(self.currentFrame.data, image_width, image_height,image_width *image_depth,  # 创建QImage格式的图像，并读入图像信息
                     QImage.Format_RGB888)
        img = QPixmap.fromImage(QIm)
        self.previousFrame = self.currentFrame
        return img





class secondwindow(QtWidgets.QWidget, Ui_Form):  # 创建子UI类

    def __init__(self):
        super(secondwindow, self).__init__()
        self.setupUi(self)


    def initUI(self):
        self.label = MyLabel(self)
        self.setWindowTitle('Choose ROI')
        self.label.setGeometry(QRect(30, 30, 511, 541))


class MainWindow(QMainWindow,Ui_MainWindow):
    def __init__(self,parent=None):
        super(MainWindow, self).__init__(parent)  # inherit the Ui_MainWindow Class
        self.setupUi(self)  # run the setupUi
        desktop_geometry = QtWidgets.QApplication.desktop()  # 获取屏幕大小
        main_window_width = desktop_geometry.width()  # 屏幕的宽
        main_window_height = desktop_geometry.height()  # 屏幕的高
        rect = self.geometry()  # 获取窗口界面大小
        window_width = rect.width()  # 窗口界面的宽
        window_height = rect.height()  # 窗口界面的高
        x = (main_window_width - window_width) // 2  # 计算窗口左上角点横坐标
        y = (main_window_height - window_height) // 2  # 计算窗口左上角点纵坐标
        self.setGeometry(x, y, window_width, window_height)  # 设置窗口界面在屏幕上的位置
        self.thread = None
        self.web = self.comboBox.currentText()
        self.buttonBox.rejected.connect(self.close_window)
        self.buttonBox.accepted.connect(self.capture_videos)
        self.menuAbout.triggered[QAction].connect(self.processtrigger)
        self.pushButton.clicked.connect(self.open_file)
        # self.pushButton_2.clicked.connect(self.capture_videos)
        self.secondwindow = secondwindow()
        self.menuvision.triggered[QAction].connect(self.show_secondwindow)
        # self.pushButton_record.clicked.connect(self.show_video)
        # self.timer_camera = QTimer(self)
        # self.timer_camera.timeout.connect(self.show_video)

        # self.cap = cv2.VideoCapture(0)
        # self.pushButton_stop.clicked.connect(self.close_web)


    def show_video(self):
        # self.timer_camera.start(10)
        self.pushButton_record.setEnabled(False)
        self.pushButton_stop.setEnabled(True)
        ret, Im = self.cap.read()
        image_height, image_width, image_depth = Im.shape  # 获取图像的高，宽以及深度。
        QIm = cv2.cvtColor(Im, cv2.COLOR_BGR2RGB)  # opencv读图片是BGR，qt显示要RGB，所以需要转换一下
        QIm = QImage(QIm.data, image_width, image_height,  # 创建QImage格式的图像，并读入图像信息
                     image_width * image_depth,
                     QImage.Format_RGB888)
        self.label_4.setPixmap(QPixmap.fromImage(QIm))

    def close_web(self):
        # self.cap.release()
        self.timer_camera.stop()
        self.pushButton_record.setEnabled(True)
        self.pushButton_stop.setEnabled(False)


        # self.label_4.setScaledContents(True)


    def open_file(self):
        # self.cap.release()/=
        OPEN_FILE_NAME = QFileDialog.getExistingDirectory(self,"choose folder")
        if OPEN_FILE_NAME is not None:
            self.lineEdit_3.setText(OPEN_FILE_NAME)
    def processtrigger(self,q):
        if q.text() == "version":
            QMessageBox.information(self, "version","v1.0.0 \r\nelladeng@163.com",QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)

    def capture_videos(self):
        self.duration = self.lineEdit.text()
        self.interval = self.lineEdit_2.text()
        self.video_path = self.lineEdit_3.text()
        self.web_cur = self.comboBox.currentText()
        self.thread = VIDEOTHREAD(self.web_cur,int(self.duration),int(self.interval),self.video_path)
        self.thread.setDaemon(True)
        self.thread.start()
        #diable start button
        if not self.thread.is_alive():
            self.pushButton_2.setEnabled(True)


    def show_secondwindow(self,q):
        if q.text() == "image":
            self.secondwindow.show()
            self.secondwindow.label.setScaledContents(True)
            self.secondwindow.load_image.clicked.connect(self.show_image)
            self.secondwindow.pushButton.clicked.connect(self.save_image)


    def show_image(self):
        OPEN_FILE_NAME = QFileDialog.getOpenFileName(self, "open file",filter="Imagefiles (*.jpg)")
        print(OPEN_FILE_NAME)
        Im = cv2.imread(OPEN_FILE_NAME[0])  # 通过Opencv读入一张图片
        image_height, image_width, image_depth = Im.shape  # 获取图像的高，宽以及深度。
        QIm = cv2.cvtColor(Im, cv2.COLOR_BGR2RGB)  # opencv读图片是BGR，qt显示要RGB，所以需要转换一下
        QIm = QImage(QIm.data, image_width, image_height,  # 创建QImage格式的图像，并读入图像信息
                     image_width * image_depth,
                     QImage.Format_RGB888)
        self.secondwindow.label.setPixmap(QPixmap.fromImage(QIm))
        self.secondwindow.label.setCursor(Qt.CrossCursor)
        self.secondwindow.show()
        # r = cv2.selectROIs(self.secondwindow.label, Im, showCrosshair=False, fromCenter=False)
        # self.imCrop = Im[int(r[1]):int(r[1] + r[3]), int(r[0]):int(r[0] + r[2])]
        # folder = QFileDialog.getExistingDirectory(self, "choose folder")
        # if folder is not None:
        #     self.secondwindow.lineEdit.setText(folder)
        # image_name = self.secondwindow.lineEdit.text()
        # self.full_name = os.path.join(folder, image_name)



    def save_image(self):

        cv2.imwrite(self.full_name+".jpg",self.imCrop)




    def close_window(self):
        # self.thread.stop()
        qApp = QApplication.instance()
        qApp.quit()
        sys.exit()


if __name__ == '__main__':
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_X11InitThreads)
    app = QApplication(sys.argv)
    ui = MainWindow()
    ui.show()
    sys.exit(app.exec_())


