from cases.video_capture.codec.web.webcamera import Ui_MainWindow
import sys
import threading
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton,QMainWindow,QDesktopWidget,QAction,QMessageBox
from cases.video_capture.codec.web.webcam import OpenCVWebCam
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QIcon,QFont


class VIDEOTHREAD(threading.Thread):
    def __init__(self,webport,duration,interval,path):
        super(VIDEOTHREAD, self).__init__()
        self.should_stop = threading.Event()
        self.webport=webport
        self.duration = duration
        self.interval = interval
        self.path = path

    def run(self):
        while not self.should_stop.is_set():
            self.web = OpenCVWebCam(self.webport)
            self.web.capture_video(self.duration,self.interval,self.path)
    def stop(self):
        self.should_stop.set()

class MainWindow(QMainWindow,Ui_MainWindow):
    def __init__(self,parent=None):
        super(MainWindow, self).__init__(parent)  # inherit the Ui_MainWindow Class
        self.setupUi(self)  # run the setupUi
        self.thread = None
        self.web = self.comboBox.currentText()
        self.buttonBox.rejected.connect(self.close_window)
        self.buttonBox.accepted.connect(self.capture_videos)
        self.menuAbout.triggered[QAction].connect(self.processtrigger)



    def processtrigger(self,q):
        if q.text() == "version":
            QMessageBox.information(self, "version","v1.0.0 \r\nelladeng@163.com",QMessageBox.Yes|QMessageBox.No,QMessageBox.Yes)

    def capture_videos(self):
        self.duration = self.lineEdit.text()
        self.interval = self.lineEdit_2.text()
        self.video_path = self.lineEdit_3.text()
        self.thread = VIDEOTHREAD(self.web,int(self.duration),int(self.interval),self.video_path)
        self.thread.setDaemon(True)
        self.thread.start()

    def close_window(self):
        # self.thread.stop()
        qApp = QApplication.instance()
        qApp.quit()
        sys.exit()


if __name__ == '__main__':
    QtCore.QCoreApplication.setAttribute(QtCore.Qt.AA_X11InitThreads)
    app = QApplication(sys.argv)
    ui = MainWindow()
    ui.show()
    sys.exit(app.exec_())


