import collections
import itertools
cases = collections.OrderedDict()

states =["S1:Gear Lever Indcn Not available:Gear Lever Indcn Not available:Gear Lever Indcn Not available","S2:Gear Lever Indcn Active:Gear Lever Indcn Active","S3:Gear Lever Indcn NotActive:Gear Lever Indcn NotActive","S4:Gear Lever Indcn Active Timer:Gear Lever Indcn Active Timer",\
         "S5:Gear Lever Indcn Error"]

transitions =[
    {"trigger":"T1","source":" ", "dest":"S2:Gear Lever Indcn Active"},
    {"trigger": "T2", "source": " ", "dest": "S3:Gear Lever Indcn NotActive"},
    {"trigger": "T3", "source": "S3:Gear Lever Indcn NotActive", "dest": "S2:Gear Lever Indcn Active"},
    {"trigger": "T4", "source": "S2:Gear Lever Indcn Active", "dest": "S3:Gear Lever Indcn NotActive"},
    {"trigger": "T5", "source": "S3:Gear Lever Indcn NotActive", "dest": "S1:Gear Lever Indcn Not available"},]
all_paths =[]

for i in range(2,len(states)+1):
  iter = itertools.permutations(states,i) #permutations 排列　　（不放回抽样排列）
  all_paths.extend(list(iter))
print("Total has %s paths"%len(all_paths))
print(all_paths)

for path in all_paths:
    expect_condition =[]
    path_break = False
    for i in range(0, len(path) - 1):
        for conditon in transitions:
            if path[i] == conditon["source"] and path[i + 1] == conditon["dest"] :
                # print(path[i],path[i+1])
                expect_condition.append(conditon["trigger"])
                cases[path] = expect_condition

negative =[]
for key in cases:
    if len(cases[key]) <len(key)-1 :
        negative.append(key)
    if not key[0].startswith(states[0]) and not key[0].startswith(states[-1]):
        negative.append(key)
resp = list(set(negative))
for key in resp:
    cases.pop(key)
print(cases)
print(len(cases))





