# import cv2
#
#
# global img
# global point1,point2
# def on_mouse(event, x, y, flags, param):
#     global img, point1, point2
#     img2 = img.copy()
#     if event ==cv2.EVENT_LBUTTONDOWN:
#         point1 = (x,y)
#         cv2.circle(img2,point1,2,(0,255,0),2) #green
#         cv2.imshow("image",img2)
#     if event == cv2.EVENT_LBUTTONDOWN and cv2.EVENT_FLAG_LBUTTON:
#         cv2.rectangle(img2,point1,(x,y),(255,0,0),5) #red
#         cv2.imshow("image",img2)
#     elif event == cv2.EVENT_LBUTTONUP:
#         point2 = (x,y)
#         cv2.rectangle(img2,point1,point2,(0,0,255),5)  #blue
#         cv2.imshow("image",img2)
#         min_x = min(point1[0],point1[0])
#         min_y = min(point1[1],point2[1])
#         width = abs(point1[0]-point1[1])
#         height = abs(point2[0] - point2[1])
#         cut_img = img[min_y: min_y+height, min_x:min_x+width]
#         cv2.imwrite("lena3.jpg",cut_img)
#         roi_image = cv2.imread("lena3.jpg")
#         cv2.imshow("new",roi_image)
#     elif event == cv2.EVENT_RBUTTONDOWN:
#         pass
#
# if __name__ == "__main__":
#     im = cv2.imread("1.jpg")
#     # cv2.namedWindow("image")
#     # cv2.setMouseCallback("image",on_mouse)
#     # cv2.imshow("image",img)
#     # cv2.waitKey(0)
#     # Select ROI
#     rects =[]
#     r = cv2.selectROIs("1",im,showCrosshair = False,fromCenter = False)
#     print(r)
#
#     # Crop image
#     imCrop = im[int(r[1]):int(r[1] + r[3]), int(r[0]):int(r[0] + r[2])]
#
#     # Display cropped image
#     cv2.imshow("Image", imCrop)
#     cv2.waitKey(0)

from PyQt5.QtWidgets import QWidget, QApplication, QLabel
from PyQt5.QtCore import QRect, Qt
from PyQt5.QtGui import QImage, QPixmap, QPainter, QPen, QGuiApplication
import cv2
import sys
class MyLabel(QLabel):
    x0 = 0
    y0 = 0
    x1 = 0
    y1 = 0
    flag = False
    #鼠标点击事件
    def mousePressEvent(self,event):
        self.flag = True
        self.x0 = event.x()
        self.y0 = event.y()
    #鼠标释放事件
    def mouseReleaseEvent(self,event):
        self.flag = False
    #鼠标移动事件
    def mouseMoveEvent(self,event):
        if self.flag:
            self.x1 = event.x()
            self.y1 = event.y()
            self.update()
    #绘制事件
    def paintEvent(self, event):
        super().paintEvent(event)
        rect =QRect(self.x0, self.y0, abs(self.x1-self.x0), abs(self.y1-self.y0))
        print(self.x0, self.y0, abs(self.x1-self.x0), abs(self.y1-self.y0))
        painter = QPainter(self)
        painter.setPen(QPen(Qt.red,2,Qt.SolidLine))
        painter.drawRect(rect)

class Example(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.resize(675, 300)
        self.setWindowTitle('在label中绘制矩形')
        self.lb = MyLabel(self)  #重定义的label
        self.lb.setGeometry(QRect(30, 30, 511, 541))
        img = cv2.imread('1.jpg')
        height, width, bytesPerComponent = img.shape
        bytesPerLine = 3 * width
        cv2.cvtColor(img, cv2.COLOR_BGR2RGB, img)
        QImg = QImage(img.data, width, height, bytesPerLine,QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(QImg)
        self.lb.setPixmap(pixmap)
        self.lb.setCursor(Qt.CrossCursor)
        self.show()
        print(self.lb.y0,abs(self.lb.y1-self.lb.y0),self.lb.x0,abs(self.lb.x1-self.lb.x0))
        cv2.imwrite("2.jpg",img[self.lb.y0:self.lb.yo_abs(self.lb.y1-self.lb.y0),self.lb.x0:abs(self.lb.x1+self.lb.x0)])

if __name__ == '__main__':
    app = QApplication(sys.argv)
    x = Example()
    sys.exit(app.exec_())