import cv2
import numpy as np


class WhiteScreen(object):
    def __init__(self,original_image,pixel_width,pixel_height):
        self.image = cv2.imread(original_image)
        self.gray = cv2.cvtColor(self.image,cv2.COLOR_BGR2GRAY) #get gray image
        self.ret, self.thresh = cv2.threshold(self.gray, 128, 255, cv2.THRESH_BINARY) # image only includes white and black ,二值化图，只有黑白
        self.pixel_width = pixel_width
        self.pixel_height = pixel_height

    def get_four_white_point(self,h1,h2,w1,w2):
        """
        :param h1: if not draw rectangle , h1 =0;otherwise it depends on user draws
        :param h2: if not draw rectangle , h2=pixel_height,otherwise it depends on user draws
        :param w1: if not draw rectangle , w1 =0;otherwise it depends on user draws
        :param w2: if not draw rectangle , w2 =pixel_width;otherwise it depends on user draws
        :return:  the for orignal white point
        """
        frame = self.thresh
        pts =[]
        left_up=()
        left_down=()
        right_up=()
        right_down=()
        for row in range(h1, h2):  # 遍历高
            for col in range(w1, w2):  # 遍历宽
                if (row > h1 and row < h2 - 1 and col > w1 and col < w2 - 1):
                    if (frame[row, col - 1] == 0 and frame[row, col + 1] == 255 and frame[row - 1, col] == 0 and frame[row + 1, col] == 255\
                        and frame[row - 1, col - 1] == 0 and frame[row - 1, col + 1] == 0 and frame[row + 1, col - 1] == 0 and frame[row + 1, col + 1] == 255):
                        left_up = (col, row)
                        print(left_up)
                    elif (frame[row, col - 1] == 255 and frame[row, col + 1] == 0 and frame[row - 1, col] == 0 and frame[
                        row + 1, col] == 255
                          and frame[row - 1, col - 1] == 0 and frame[row - 1, col + 1] == 0 and frame[
                              row + 1, col - 1] == 255 and frame[row + 1, col + 1] == 0):
                        right_up = (col, row)
                        print(right_up)
                    elif (frame[row, col - 1] == 0 and frame[row, col + 1] == 255 and frame[row - 1, col] == 255 and frame[
                        row + 1, col] == 0
                          and frame[row - 1, col - 1] == 0 and frame[row - 1, col + 1] == 255 and frame[
                              row + 1, col - 1] == 0 and frame[row + 1, col + 1] == 0):
                        left_down= (col, row)
                        print(left_down)
                    elif (frame[row, col - 1] == 255 and frame[row, col + 1] == 0 and frame[row - 1, col] == 255 and frame[
                        row + 1, col] == 0
                          and frame[row - 1, col - 1] == 255 and frame[row - 1, col + 1] == 0 and frame[
                              row + 1, col - 1] == 0 and frame[row + 1, col + 1] == 0):
                        right_down= (col, row)
                        print(right_down)
        try:
            pts.append(left_up)
            pts.append(right_up)
            pts.append(left_down)
            pts.append(right_down)
        except:
            print("not find all points")
        print("orignal point is %s"%pts)
        return pts

    def cal_pts2(self,total_width,target_width,target_height):
        """
        :param total_width: the ration to total screen width: white screen width :white screen height
        :param target_width:
        :param target_height:
        :return:
        """
        x1=(c_width-c_width*target_width/total_width)/2
        x2=x1+c_width*target_width/total_width
        y1=(c_height-c_width*target_width/total_width*target_height/target_width)/2
        y2=y1+c_width*target_width/total_width*target_height/target_width
        return [(x1,y1),(x2,y1),(x1,y2),(x2,y2)]

    def calibaration(self,pts1,pts2):
        m = cv2.getPerspectiveTransform(pts1, pts2)
        dst = cv2.warpPerspective(self.image, m, (self.pixel_width, self.pixel_height))
        cv2.imwrite("calculate.png", dst)



if __name__ =="__main__":
    c_width = 1920
    c_height = 1080
    cal = WhiteScreen(r"1567671459.57951.jpeg",c_width,c_height)
    pts1 =cal.get_four_white_point(0,1080,0,1920)
    pts1 = np.float32(pts1)
    print("pst1 is %s", pts1)
    # pts1 =np.float32([(75, 332), (1684, 345), (36, 956), (1715, 953)])
    pts2 = cal.cal_pts2(294,294,111) # total width:target width:target_height
    pts2 = np.float32(pts2)
    print("pst2 is %s",pts2)
    # pts2=np.float32([(0.0, 177.55102040816325), (1920.0, 177.55102040816325), (0.0, 902.4489795918367), (1920.0, 902.4489795918367)])
    cal.calibaration(pts1,pts2)

