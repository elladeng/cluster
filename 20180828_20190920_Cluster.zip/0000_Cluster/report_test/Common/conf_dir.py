#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Created by Sam Wu on 2019-04-04

import os

cur_dir = os.path.split(os.path.abspath(__file__))[0]

htmlreports_dir = cur_dir.replace("Common", "HtmlTestReports")