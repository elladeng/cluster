# -*- coding: UTF-8 -*-

import re
from abc import ABCMeta
import cv2
import time
import numpy as np
import os
import datetime
import logging
logger = logging.getLogger(__name__)


class WebCamFactory(object):
    @classmethod
    def new_webcam(cls, **kwargs):
        if kwargs:
            return WebCam(**kwargs)
        else:
            return NullWebCam()


class BaseWebCam(object):
    __metaclass__ = ABCMeta

    def capture_image(self, *args, **kwargs):
        pass

    def capture_video(self, *args, **kwargs):
        pass


class NullWebCam(BaseWebCam):
    """
    See <Null Object> design pattern for detail: http://www.oodesign.com/null-object-pattern.html
    """


class WhiteScreen(object):
    def __init__(self,original_image,pixel_width,pixel_height):
        self.image = cv2.imread(original_image)
        print(self.image)
        self.gray = cv2.cvtColor(self.image,cv2.COLOR_BGR2GRAY) #get gray image
        self.ret, self.thresh = cv2.threshold(self.gray, 128, 255, cv2.THRESH_BINARY) # image only includes white and black ,二值化图，只有黑白
        self.pixel_width = pixel_width
        self.pixel_height = pixel_height

    def get_four_white_point(self,h1,h2,w1,w2):
        """
        :param h1: if not draw rectangle , h1 =0;otherwise it depends on user draws
        :param h2: if not draw rectangle , h2=pixel_height,otherwise it depends on user draws
        :param w1: if not draw rectangle , w1 =0;otherwise it depends on user draws
        :param w2: if not draw rectangle , w2 =pixel_width;otherwise it depends on user draws
        :return:  the for orignal white point
        """
        frame = self.thresh
        pts =[]
        left_up=()
        left_down=()
        right_up=()
        right_down=()
        for row in range(h1, h2):  # 遍历高
            for col in range(w1, w2):  # 遍历宽
                if (row > h1 and row < h2 - 1 and col > w1 and col < w2 - 1):
                    if (frame[row, col - 1] == 0 and frame[row, col + 1] == 255 and frame[row - 1, col] == 0 and frame[row + 1, col] == 255\
                        and frame[row - 1, col - 1] == 0 and frame[row - 1, col + 1] == 0 and frame[row + 1, col - 1] == 0 and frame[row + 1, col + 1] == 255):
                        left_up = (col, row)
                        print(left_up)
                    elif (frame[row, col - 1] == 255 and frame[row, col + 1] == 0 and frame[row - 1, col] == 0 and frame[
                        row + 1, col] == 255
                          and frame[row - 1, col - 1] == 0 and frame[row - 1, col + 1] == 0 and frame[
                              row + 1, col - 1] == 255 and frame[row + 1, col + 1] == 0):
                        right_up = (col, row)
                        print(right_up)
                    elif (frame[row, col - 1] == 0 and frame[row, col + 1] == 255 and frame[row - 1, col] == 255 and frame[
                        row + 1, col] == 0
                          and frame[row - 1, col - 1] == 0 and frame[row - 1, col + 1] == 255 and frame[
                              row + 1, col - 1] == 0 and frame[row + 1, col + 1] == 0):
                        left_down= (col, row)
                        print(left_down)
                    elif (frame[row, col - 1] == 255 and frame[row, col + 1] == 0 and frame[row - 1, col] == 255 and frame[
                        row + 1, col] == 0
                          and frame[row - 1, col - 1] == 255 and frame[row - 1, col + 1] == 0 and frame[
                              row + 1, col - 1] == 0 and frame[row + 1, col + 1] == 0):
                        right_down= (col, row)
                        print(right_down)
        try:
            pts.append(left_up)
            pts.append(right_up)
            pts.append(left_down)
            pts.append(right_down)
        except:
            print("not find all points")
        print("orignal point is %s"%pts)
        return pts

    def cal_pts2(self,total_width,target_width,target_height):
        """
        :param total_width: the ration to total screen width: white screen width :white screen height
        :param target_width:
        :param target_height:
        :return:
        """
        x1=(c_width-c_width*target_width/total_width)/2
        x2=x1+c_width*target_width/total_width
        y1=(c_height-c_width*target_width/total_width*target_height/target_width)/2
        y2=y1+c_width*target_width/total_width*target_height/target_width
        return [(x1,y1),(x2,y1),(x1,y2),(x2,y2)]

    def calibaration(self,pts1,pts2):
        m = cv2.getPerspectiveTransform(pts1, pts2)
        dst = cv2.warpPerspective(self.image, m, (self.pixel_width, self.pixel_height))
        cv2.imwrite("calculate.png", dst)

class OpenCVWebCam(BaseWebCam):
    def __init__(self, devnum):
        self.__devnum = int(devnum)

    def capture_image(self,name,scale=False):
        cap = cv2.VideoCapture(self.__devnum)
        cap.set(3, 1920.0)
        cap.set(4, 1080.0)
        try:
            ret, frame = cap.read()
            # Display the resulting frame+
            # cv2.imshow('frame', frame)
            cv2.imwrite(name, frame)
        finally:
            cap.release()
            if scale:
                pic = cv2.imread(name)
                res=cv2.resize(pic, (160, 90))
                cv2.imwrite(name,res)
            time.sleep(3)
    def capture_one_image(self,cycle_time):
        cap = cv2.VideoCapture(self.__devnum)
        start_time = end_time = time.time()
        temp_path = os.path.dirname(__file__)

        while end_time - start_time < cycle_time:
            ret, frame = cap.read()
            time.sleep(60)
            cv2.imwrite(os.path.join(temp_path + str(datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S-%f'))) + ".png", frame)
            end_time = time.time()
            print(end_time)

        cap.release()

    """
    can record 21 pictures per 1s.
    """
    def capture_continued_image(self,cycle_time=1,image_dir=r"E:\husky_new\lib\simg\equipment\temp_image\\"):
        images_frame =[]
        cap = cv2.VideoCapture(self.__devnum)
        fourcc = cv2.VideoWriter_fourcc(*'MJPG')  # mjpg can support 50 pics /s 'xvid'only support 30 pics/s
        print(fourcc)
        cap.set(3,640.0)
        cap.set(4,480.0)
        cap.set(5,120.101)
        cap.set(6,1196444237.0)# should add set fourcc to MJPG which can supports
        time.sleep(1)
        start_time = time.time()
        count=0
        while time.time() - start_time < cycle_time:
            ret, frame = cap.read()
            images_frame.append(frame)
            count+=1
            cv2.imwrite(os.path.join(image_dir,str(time.time()))+".jpeg",frame)

        print(count)
        print("------------------------------")
        print(images_frame)
        cap.release()


    def get_pixel_values(self,name):
        image = cv2.imread(name)
        (b, g, r) = image[100, 100]
        logger.info("blue is %s green is %s red is %s" % (b, g, r))
        return r, g, b

    def capture_video(self, duration_time=60,interval=60):

        mins  = int(duration_time /int(interval)) # capture image per 10 mins
        for i in range(0,mins):
            cap = cv2.VideoCapture(self.__devnum)
            print('output_%s_%s.avi'%(i,self.__devnum))
            # Define the codec and create VideoWriter object
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
            out = cv2.VideoWriter('output_%s_%s.avi'%(i,self.__devnum), fourcc, 20.0, (640, 480))
            start_time = end_time = time.time()
            font = cv2.FONT_HERSHEY_SIMPLEX
            while (cap.isOpened()):
                ret, frame = cap.read()
                if ret == True:
                    frame = cv2.resize(frame, (640, 480)) # this for 2 webcamers
                    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
                    cv2.putText(frame, str(timestamp), (400, 460), \
                                font, 0.5, (0, 0, 255), 1)
                    # write the flipped frame
                    out.write(frame)

                    end_time = time.time()
                    if end_time - start_time >= int(interval):
                        break
                else:
                    break

            # Release everything if job is finished
            cap.release()
            out.release()

            cap.release()

    def get_images_from_video(self,video_files,image_dir=r"E:\husky_new\lib\simg\equipment\temp_image\\"):
        cap = cv2.VideoCapture(video_files)
        flash_rate = 0

        while True:
            ret, frame = cap.read()
            if ret:
                cv2.imwrite(os.path.join(image_dir, str(time.time())) + ".png", frame)
            else:
                break

        print(flash_rate)


    def __str__(self):
        return "web_num_%s" % self.__devnum

    def match_picture(self,source, golden):
        target = cv2.imread(source)
        target_w, target_h = target.shape[:2]
        basenames = os.path.basename(golden).partition(".")[0].split(",")
        x1 = int(basenames[0])
        y1 = int(basenames[1])
        w = int(basenames[2])
        h = int(basenames[3])
        if x1 < 10 or y1 < 10 or x1 + w + 20 > target_w and h + y1 + 20 > target_h:
            real_pic = target[y1:y1 + h, x1:x1 + w]
        else:
            real_pic = target[y1 - 10:y1 + h + 20, x1 - 10:x1 + w + 20]  # y1:y2,x1:x2
        golden_pic = cv2.imread(golden)
        res = cv2.matchTemplate(real_pic, golden_pic, cv2.TM_CCORR_NORMED)
        confidence = cv2.minMaxLoc(res)[1]  #
        print(int(confidence * 100))
        return int(confidence * 100)

    def match_folder_pictures(self,dest):
        basename = os.path.dirname(__file__)
        picture_name = os.path.join(basename,str(time.time())+".jpeg")
        print(repr(picture_name))
        self.capture_image(picture_name)
        pictures = os.listdir(dest)
        expected_result = []
        for picture in pictures:
            expected_result.append(self.match_picture(picture_name, os.path.join(dest, picture)))

        # os.remove(picture_name)
        return expected_result


WebCam = OpenCVWebCam


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)-15s [%(levelname)-8s] - %(message)s'
    )

    c_width = 1920
    c_height = 1080
    # cal = WhiteScreen(r"white.jpg", c_width, c_height)
    # pts1 = cal.get_four_white_point(0, 1080, 0, 1920)
    # pts1 = np.float32(pts1)
    # print("pst1 is %s", pts1)
    # # pts1 =np.float32([(75, 332), (1684, 345), (36, 956), (1715, 953)])
    # pts2 = cal.cal_pts2(294, 294, 111)  # total width:target width:target_height
    # pts2 = np.float32(pts2)
    # print("pst2 is %s", pts2)
    # # pts2=np.float32([(0.0, 177.55102040816325), (1920.0, 177.55102040816325), (0.0, 902.4489795918367), (1920.0, 902.4489795918367)])
    # cal.calibaration(pts1, pts2)
    import threading
    import argparse
    import sys

    web_1 = WebCam(0)
    web_1.match_folder_pictures(r"E:\000_CSharp_Project\dcy11_temp\TT_Left_Right_ON")
    # parser = argparse.ArgumentParser(description="please input web num")
    # parser.add_argument('--web1', help="please input the web num 1",type=str)
    # parser.add_argument('--duration', help="please input durationt time",type=int)
    # parser.add_argument('--interval', help="please input durationt time", type=int)
    # #
    # args = parser.parse_args()
    # #
    # web_1 = WebCam(args.web1)
    # print("Start to record the video")
    # try:
    #     web_1.capture_video(args.duration,args.interval)
    # except KeyboardInterrupt:
    #     sys.exit()
    # web_2 = WebCam("0")
    # web_2.capture_continued_image(60)
    # web_2.capture_video()
    # a = threading.Thread(target=web_1.capture_video, args=(args.duration,))
    # print(a)
    # b = threading.Thread(target=web_2.capture_one_image, args=(args.duration,))
    # print(b)
    # a.start()
    # b.start()
    # a.join()
    # b.join()

    # # web_1.capture_continued_iamge()
    # web_1.capture_image(name_test)
    # web_1.capture_one__image()
    # web_1.capture_image(name_golden)

