import cv2
import pymysql
import numpy as np
import os.path
import os

def match_picture(source,golden):
    target = cv2.imread(source)
    target_w, target_h = target.shape[:2]
    basenames = os.path.basename(golden).partition(".")[0].split(",")
    x1 = int(basenames[0])
    y1 = int(basenames[1])
    w = int(basenames[2])
    h = int(basenames[3])
    if x1 <10 or y1 <10 or x1+w+20 >target_w and h+y1+20>target_h:
        real_pic = target[y1:y1+h, x1:x1+w]
    else:
        real_pic = target[y1-10:y1+h+20,x1-10:x1+w+20] #y1:y2,x1:x2
    golden_pic = cv2.imread(golden)
    res = cv2.matchTemplate(real_pic, golden_pic, cv2.TM_CCORR_NORMED)
    confidence= cv2.minMaxLoc(res)[1]#
    print(int(confidence*100))
    return int(confidence*100)

def match_folder_pictures(source,dest):
    pictures = os.listdir(dest)
    expected_result = []
    for picture in pictures:
        expected_result.append(match_picture(source,os.path.join(dest,picture)))

    print(expected_result)





if __name__ == "__main__":
    # match_pictures("target.jpg","1551,381,84,54.bmp")
    match_folder_pictures("left_right.jpg",r"E:\000_CSharp_Project\dcy11_temp\TT_Left_Right_ON")
