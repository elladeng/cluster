import ea_psu_controller

class PSUEA():
    def __init__(self,comport):
        self.psu = ea_psu_controller.PsuEA(comport=comport)

    def connect(self):
        self.psu.remote_on()

    def disconnect(self):
        self.psu.remote_off()

    def power_on(self):
        self.psu.output_on()

    def power_off(self):
        self.psu.output_off()

    def set_voltate(self,value):
        self.psu.set_voltage(int(value))

    def get_voltage(self):
        value = self.psu.get_voltage()
        print("current value is %s"%value)

    def set_current(self):
        self.psu.set_current(1.3)

    def get_current(self):
        value = self.psu.get_current()
        print("current value is %s" % value)


if __name__ == "__main__":
    p = PSUEA("COM9")
    try:
        p.connect()
        p.power_on()
        while True:
            p.get_current()
    finally:
        p.disconnect()
