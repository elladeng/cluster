from msl.loadlib import LoadLibrary
import os
path = os.path.dirname(__file__)


class CANalyzer(object):
    def __init__(self):
        net = LoadLibrary(os.path.join(path,"CANalyzer.dll"),"net")
        self.app = net.lib.MTE.CAN()

    def start(self):
        self.app.StartSimulation()

    def stop(self):
        self.app.StopSimulation()

    def send_diag_msg(self, value):
        self.app.SendRawDiagnosticString(value)

    def send_sysvar(self,namespace, sysvar, value):  #string nameSpace, string sysVar, int value)
        self.app.SendSysVar(namespace, sysvar, value)

    def get_sysvar(self,namespace,sysvar): #(string nameSpace, string sysVar)
        return self.app.GetSysVar(namespace, sysvar)

    def get_diag_response(self):
        diag_datas = self.get_sysvar("test_uds","Diag_Response")
        new_diag_datas = []
        data_len = len(diag_datas)
        for i in range(0, data_len):
            if diag_datas[i] != -1 and diag_datas[i] != 0:
                value = hex(diag_datas[i])[2:].upper()
                if len(value) == 1:
                    value = "0" + value
                new_diag_datas.append(value + " ")
        s = "".join(new_diag_datas)
        return s


if __name__ == "__main__":
    import time
    can_obj = CANalyzer()
    try:
        can_obj.start()
        time.sleep(20)
        can_obj.send_sysvar("_AdditionalOutputs::CEM","IndcrDisp1WdSts_UpdateBitControl",1)
        time.sleep(0.5)
        can_obj.send_sysvar("_AdditionalOutputs::CEM","IndcrDisp1WdSts",1)
        can_obj.send_diag_msg("40 03 00 03 22 DA 09")
        time.sleep(0.5)
        value = can_obj.get_diag_response()
        print(value)

    finally:
        pass
        # can_obj.stop()
